function test(tr){
debugger;
var cells=tr.cells
var len=cells.length;
  for(var j = 0; j < len; j++){

              // get your cell info here

              var cellVal = cells.item(j).innerHTML;
              alert(cellVal);
           }
}


function showdialog(){

}