package com.ssc.osawt.helloworld.server;

import org.apache.log4j.Logger;

import com.ssc.faw.intref2.Request;
import com.ssc.faw.intref2.Tabular;
import com.ssc.faw.intref2.TabularListener;
import com.ssc.faw.util.GenException;
//import com.ssc.util.Controller;

public class IDF_2591277 implements Tabular
{
    private static final Logger log = Logger.getLogger(IDF_2591277.class);
    private static Object[][] output = new Object[][]{
    };
    
    @Override
    public void process(Request request, TabularListener listener) throws GenException
    {
	try
	{
	    log.info("Start IDF_2591277 (Getting DataPath)");
	    
	    listener.open();
	    for (Object[] row : output) {
	    	listener.addRow(row);
	    }

	    
	}
	catch (Exception e)
	{
	    log.error(e, e);
	}
	finally
	{
	    listener.close();
	    log.info("IDF_2591277 is FINISHED!");
	}
    }
}
