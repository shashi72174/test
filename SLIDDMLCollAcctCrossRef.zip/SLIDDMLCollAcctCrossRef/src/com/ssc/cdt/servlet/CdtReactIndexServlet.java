package com.ssc.cdt.servlet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.ssc.faw.controller.session.ThreadData;
import com.ssc.faw.intref2.Caller;
import com.ssc.faw.intref2.CallerResultSet;
import com.ssc.faw.intref2.ServiceRequest;

public class CdtReactIndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger log = Logger.getLogger(CdtReactIndexServlet.class);
	private static Charset utf8 = Charset.forName("UTF-8");
	private final static String appCode = System.getProperty("OEC.APP", "CDT");
	private final static String enableMetadataParam = "enableJsonMetaData";
	private static boolean enableMetadata = true;
	
	@Override
	public void init() throws ServletException {
		super.init();
		String strEnable = getServletConfig().getInitParameter(enableMetadataParam);
		enableMetadata = !"false".equals(strEnable);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("came here 1");
		String context = request.getContextPath().substring(1);
		String requestURI = request.getRequestURI().replace("/", "");
		String servletPath = request.getServletPath().replace("/", "");
		
		if (context.endsWith(requestURI)) {
			String newURL = "/" + context + "/" + servletPath + "/";
			log.info("**** redirecting to " + newURL);
			System.out.println("**** redirecting to " + newURL);
			String src = request.getParameter("src");
			if ("express".equals(src)) {
				log.info("**** using javascript redirect for Express dev mode: " + newURL);
				response.setContentType("text/html;charset=UTF-8");
				
				response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
				response.setHeader("Pragma", "no-cache");
				response.setHeader("Expires", "0");
				
				OutputStream out = response.getOutputStream();
				write("<!doctype html>", out);
				write("  <body>", out);
				write("    <script>location.href='/" + context + "/" + servletPath + "/';</script>", out);
				write("  </body>", out);
				write("</html>", out);
				out.flush();
				out.close();
			} else {
				log.info("**** using servlet redirect for production: " + newURL);
				response.sendRedirect(newURL);
			}
			return;
		}
		
		String lang = request.getHeader("Accept-Language");
		if (lang != null) {
			int idx = lang.indexOf(',');
			if (idx > 0) {
				lang = lang.substring(0, idx);
			}
		}
		response.setContentType("text/html;charset=UTF-8");
		
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		
		OutputStream out = response.getOutputStream();
		
		write("<!doctype html>", out);
		write("<html lang='" + lang + "'>", out);
		write("  <head>", out);
		write("    <meta charset='utf-8'>", out);
		write("    <base href='/" + context + "/" + servletPath +"'>", out);
		write("    <meta http-equiv='X-UA-Compatible' content='IE=edge'>", out);
		write("    <meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no'>", out);
		write("    <title>State Street Corporation</title>", out);
		
		write("    <!--[if lt IE 11]>", out);
		write("      <script>window.alert('This page requires IE 11, Chrome, Firefox, Edge, or Safari');</script>", out);
		write("    <![endif]-->", out);
		
		write("    <script type='text/javascript'>", out);
		write("      var CDT_VERSION = 2;", out);
		write("      var CDT_SERVLETPATH = '" + servletPath + "';", out);
		write("      var CDT_CONTEXT = '" + context + "';", out);
		write("      var CDT_USER = '" + ThreadData.getUser() + "';", out);
		write("      var CDT_SERVER_DATA = {};", out);
		write("      CDT_SERVER_DATA.context = \"" + context + "\";", out);
		write("      CDT_SERVER_DATA.servletPath = \"" + servletPath + "\";", out);
        write("      CDT_SERVER_DATA.authsession = { ", out);
        write("        \"userId\" : \"" + ThreadData.getUser() + "\",", out);
        write("        \"displayName\" : \"" + ThreadData.getFullName() + "\",", out);
        write("        \"email\" : \"" + ThreadData.getEmail() + "\",", out);
        write("        \"lang\" : \"" + lang + "\",", out);
        write("        \"appCode\" : \"" + appCode + "\"", out);
        write("      };", out);
        write("      function parseCloudData(id) {", out);
        write("        var el = document.getElementById(id);", out);
        write("        var strJson = el.innerText || el.textContent;", out);
        write("        var data = JSON.parse(strJson);", out);
        write("        return data;", out);
        write("      };", out);
        write("      function reduceRegistryData(regData) {", out);
        write("        let obj = {};", out);
        write("        if (!regData || regData.length === 0) { return obj; } ", out);
        write("        for (let i = 0; i < regData.length; i++) {", out);
        write("          let row = regData[i];", out);
        write("          let id = row.componentId;", out);
        write("          obj[id] = obj[id] || {data: []};", out);
        write("          obj[id].data.push(row);", out);
        write("        }", out);
        write("        console.log(obj);", out);
        write("        return obj;", out);
        write("      };", out);
		write("    </script>", out);

		if (enableMetadata) {
			write("    <script id='IDF_METADATA' type='application/json'>", out);
			RequestDispatcher rd = request.getRequestDispatcher("/metadata");
			rd.include(request, response);
			write("    </script>", out);
			write("    <script type='text/javascript'>", out);
			write("      CDT_SERVER_DATA.idfMetadata={};", out); 
			write("      CDT_SERVER_DATA.idfMetadata." + context.replaceAll("[/-]", "_") + " = parseCloudData('IDF_METADATA');", out); 
			write("    </script>", out);
		}
		
		
		ServletConfig config = getServletConfig();
		Enumeration<String> initParamNames = config.getInitParameterNames();
		
		while (initParamNames.hasMoreElements()) {
			String paramName = initParamNames.nextElement();
			
			if (enableMetadataParam.equals(paramName)) {
				continue;
			}
			
			String paramString = config.getInitParameter(paramName);
			write("    <script id='" + paramName + "' type='application/json'>", out);
			
			String[] paramPairs = paramString.split("&");
			String strReqNumber = null;
			for (String pair : paramPairs) {
				if (pair.startsWith("__request=")) {
					strReqNumber = pair.split("=")[1];
					break;
				}
			}
			
			if (strReqNumber == null) {
				log.error("No request number for param " + paramName + "in CdtReactIndexServlet config");
				continue;
			}
			
			int requestNumber = Integer.valueOf(strReqNumber);
			
			ServiceRequest serviceRequest = new ServiceRequest(ThreadData.getSMToken(), requestNumber);
			Caller call = new Caller(serviceRequest);
			
			CallerResultSet res;
			try {
				res = call.execute(paramString);
				ByteArrayOutputStream bao = new ByteArrayOutputStream();
				res.toJSON(bao);
				bao.writeTo(out);
			} catch (Exception e) {
				log.error("Exception executing IDF " + requestNumber, e);
			}
			
			write("    </script>", out);

			write("    <script type='text/javascript'>", out);
			if (paramName.endsWith("_Registry")) {
				String registryParamName = paramName.replace("_Registry", "");
				write("      var regData = parseCloudData('" + paramName + "').xdata.rows;", out); 
				write("      console.table(regData);", out); 
				write("      CDT_SERVER_DATA." + registryParamName + "=reduceRegistryData(regData);", out); 
			} else {
				write("      CDT_SERVER_DATA." + paramName + "=parseCloudData('" + paramName + "').xdata.rows;", out); 
			}
			write("    </script>", out);
		}
		
		write("  </head>", out);
		write("  <body>", out);
		write("    <div id='app' class='wrapper'></div>", out);
		write("    <script src='/" + context + "/dist/bundle.js'></script>", out);
		write("  </body>", out);
		write("</html>", out);
		out.flush();
		out.close();
		return;
		}

	private void write(String str, OutputStream out) throws IOException {
		String html = str + '\n';
		out.write(html.getBytes(utf8));
	}
	
}
