package com.ssc.cdt.servlet;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.AndFileFilter;
import org.apache.commons.io.filefilter.PrefixFileFilter;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ssc.faw.common.PropertyManager;
import com.ssc.faw.intref2.IDF_Data;
import com.ssc.faw.intref2.IDF_DataTypes;
import com.ssc.faw.intref2.IDF_Input;
import com.ssc.faw.intref2.IDF_Output;
import com.ssc.faw.intref2.IntrefException;

public class JsonMetaDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger log = Logger.getLogger(JsonMetaDataServlet.class);
	private static Charset utf8 = Charset.forName("UTF-8");
	private final static String appCode = System.getProperty("OEC.APP", "CDT");
	private static MetaDataJson metaDataJson;
	private static PrefixFileFilter pFilter = new PrefixFileFilter("IDF_");
	private static SuffixFileFilter sFilter = new SuffixFileFilter(".xml");
	private static AndFileFilter filter = new AndFileFilter(pFilter, sFilter);
	private static Type mapType = new TypeToken<MetaDataJson>(){}.getType();

	private static final String IDF_PATH[] =
	{
		PropertyManager.getStringProperty("intref.idfPath", "./"),
		PropertyManager.getStringProperty("intref.idfPath2", "./"),
		PropertyManager.getStringProperty("intref.idfPath3", "./"),
		PropertyManager.getStringProperty("intref.idfPath4", "./"),
		PropertyManager.getStringProperty("intref.idfPath5", "./"),
		PropertyManager.getStringProperty("intref.idfPath6", "./"),
		PropertyManager.getStringProperty("intref.idfPath7", "./"),
		PropertyManager.getStringProperty("intref.idfPath8", "./"),
		PropertyManager.getStringProperty("intref.idfPath9", "./"),
		PropertyManager.getStringProperty("fileCache.cacheDir", "./")
	};

	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		response.setContentType("application/json;charset=UTF-8");
		
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		
		if (metaDataJson.url == null) {
			String context = request.getContextPath();
			if (context != null) {
				context = context.replace("/", "");
			}
				
			metaDataJson.context = context;
			metaDataJson.url = request.getContextPath() + "/json";
		}
		
		OutputStream out = response.getOutputStream();
		Gson gson = new Gson();
		write(gson.toJson(metaDataJson, mapType), out);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doGet(req, resp);
	}

	@Override
	public void init() throws ServletException {
		super.init();
		
		metaDataJson = new MetaDataJson();
		metaDataJson.appCode = appCode;
		
		List<Integer> idfs = getIdfNumbers();
		
		for (Integer idfNumber : idfs) {
			try {
				IDF_Data data = IDF_Data.get(idfNumber);
				metaDataJson.metaMap.put(idfNumber, getIdfMetadata(data));
			} catch (IntrefException e) {
				log.error(e);
			}
		}
	}
	
	private IdfMetadata getIdfMetadata(IDF_Data data) {
		IdfMetadata idf = new IdfMetadata();
		idf.setName(data.name());
		idf.setNumber(data.number());
		idf.setAppCode(appCode);

		List<String> dateFields = new ArrayList<String>();
		List<String> dateTimeFields = new ArrayList<String>();
		List<IdfValue> inputValues = new ArrayList<IdfValue>();
		List<IdfValue> outputValues = new ArrayList<IdfValue>();
		
		IDF_Input[] inputs = data.getInputs(); 
		IDF_Output[] outputs = data.getOutputs(); 
		
		if (inputs != null) {
			for (IDF_Input input : inputs) {
				IdfValue in = new IdfValue();
				in.dataKey = input.name();
				in.dataType = getDataType(input.type());
				inputValues.add(in);
				if ("date".equals(in.dataType)) {
					List<String> addList = isDateTime(input.type()) ? dateTimeFields : dateFields;
					if (!addList.contains(in.dataKey)) {
						addList.add(in.dataKey);
					}
				}
			}
		}
		

		if (outputs != null) {
			for (IDF_Output output : outputs) {
				IdfValue out = new IdfValue();
				out.dataKey = output.name();
				out.dataType = getDataType(output.type());
				outputValues.add(out);
				if ("date".equals(out.dataType)) {
					List<String> addList = isDateTime(output.type()) ? dateTimeFields : dateFields;
					if (!addList.contains(out.dataKey)) {
						addList.add(out.dataKey);
					}
				}
			}
		}

		idf.dateFields = dateFields.toArray(new String[dateFields.size()]);
		idf.dateTimeFields = dateTimeFields.toArray(new String[dateTimeFields.size()]);
		idf.inputs = inputValues.toArray(new IdfValue[inputValues.size()]);
		idf.outputs = outputValues.toArray(new IdfValue[outputValues.size()]);
		
		return idf;
	}
	
	private boolean isDateTime(int idfDataType) {
		return idfDataType == IDF_DataTypes.IDF_DATETIME;
	}
	
	private String getDataType(int idfDataType) {
		if (idfDataType == IDF_DataTypes.IDF_DATE ||
				idfDataType == IDF_DataTypes.IDF_DATETIME) {
			return "date";
		}

		if (idfDataType == IDF_DataTypes.IDF_BIGDECIMAL ||
				idfDataType == IDF_DataTypes.IDF_INT ||
				idfDataType == IDF_DataTypes.IDF_FLOAT ||
				idfDataType == IDF_DataTypes.IDF_LONG ||
				idfDataType == IDF_DataTypes.IDF_DOUBLE
				) {
			return "number";
		}

		return "string";
	}
	
	@SuppressWarnings("unchecked")
	private List<Integer>getIdfNumbers() {
		List<Integer> idfs = new ArrayList<Integer>();
		for (String path : IDF_PATH) {
			File f = new File(path);
			Collection<File> files = (Collection<File>)FileUtils.listFiles(f, filter, null);
			for (File file : files) {
				String fileName = file.getName();
				int index = fileName.indexOf(".xml");
				String strIdf = fileName.substring(4, index);
				try {
					int idfNumber = Integer.parseInt(strIdf);
					idfs.add(idfNumber);
				} catch (NumberFormatException e) {
					log.error(e);
				}
			}
		}
		return idfs;
	}
	
	private void write(String str, OutputStream out) throws IOException {
		String html = str + '\n';
		out.write(html.getBytes(utf8));
	}

	
	public class IdfValue {
		String dataKey;
		String dataType;
		public String getDataKey() {
			return dataKey;
		}
		public void setDataKey(String dataKey) {
			this.dataKey = dataKey;
		}
		public String getDataType() {
			return dataType;
		}
		public void setDataType(String dataType) {
			this.dataType = dataType;
		}
	}
	
	
	public class IdfMetadata {
		String name;
		String appCode;
		int number;
		String[] dateFields;
		String[] dateTimeFields;
		IdfValue[] inputs;
		IdfValue[] outputs;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getAppCode() {
			return appCode;
		}
		public void setAppCode(String appCode) {
			this.appCode = appCode;
		}
		public int getNumber() {
			return number;
		}
		public void setNumber(int number) {
			this.number = number;
		}
		public String[] getDateFields() {
			return dateFields;
		}
		public void setDateFields(String[] dateFields) {
			this.dateFields = dateFields;
		}
		public String[] getDateTimeFields() {
			return dateTimeFields;
		}
		public void setDateTimeFields(String[] dateTimeFields) {
			this.dateTimeFields = dateTimeFields;
		}
		public IdfValue[] getInputs() {
			return inputs;
		}
		public void setInputs(IdfValue[] inputs) {
			this.inputs = inputs;
		}
		public IdfValue[] getOutputs() {
			return outputs;
		}
		public void setOutputs(IdfValue[] outputs) {
			this.outputs = outputs;
		}
	}
	
	public class MetaDataJson {
		Map<Integer, IdfMetadata> metaMap = new HashMap<Integer, IdfMetadata>();
		String appCode;
		String context;
		String url;
		public Map<Integer, IdfMetadata> getMetaMap() {
			return metaMap;
		}
		public void setMetaMap(Map<Integer, IdfMetadata> metaMap) {
			this.metaMap = metaMap;
		}
		public String getAppCode() {
			return appCode;
		}
		public void setAppCode(String appCode) {
			this.appCode = appCode;
		}
		public String getContext() {
			return context;
		}
		public void setContext(String context) {
			this.context = context;
		}
		public String getUrl() {
			return url;
		}
		public void setUrl(String url) {
			this.url = url;
		}
	}
}
