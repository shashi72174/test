package com.ssc.cdt.data;

import java.util.List;
import java.util.HashMap;
import com.ssc.cloud.jbio.Col;
import com.ssc.cloud.jbio.IdfColType;
import com.ssc.cloud.jbio.IdfInOut;

@IdfInOut(
{
    @Col(beanProp="price", idfColName=SampleData.PRICE, idfColType=IdfColType.DOUBLE),
    @Col(beanProp="manager", idfColName=SampleData.MANAGER, idfColType=IdfColType.STRING),
    @Col(beanProp="value", idfColName=SampleData.VALUE, idfColType=IdfColType.DOUBLE),
    @Col(beanProp="symbol", idfColName=SampleData.SYMBOL, idfColType=IdfColType.STRING),
    @Col(beanProp="date", idfColName=SampleData.DATE, idfColType=IdfColType.DATE),
    @Col(beanProp="id", idfColName=SampleData.ID, idfColType=IdfColType.LONG),
    @Col(beanProp="fund", idfColName=SampleData.FUND, idfColType=IdfColType.STRING),
    @Col(beanProp="months", idfColName=SampleData.MONTHS, idfColType=IdfColType.INT),
    @Col(beanProp="quantity", idfColName=SampleData.QUANTITY, idfColType=IdfColType.DOUBLE),
}
)

public class SampleData
{
    public static final String PRICE = "PRICE";
    public static final String MANAGER = "MANAGER";
    public static final String VALUE = "VALUE";
    public static final String SYMBOL = "SYMBOL";
    public static final String DATE = "DATE";
    public static final String ID = "ID";
    public static final String FUND = "FUND";
    public static final String MONTHS = "MONTHS";
    public static final String QUANTITY = "QUANTITY";

    private java.lang.Double price;
    private java.lang.String manager;
    private java.lang.Double value;
    private java.lang.String symbol;
    private java.util.Date date;
    private java.lang.Long id;
    private java.lang.String fund;
    private java.lang.Integer months;
    private java.lang.Double quantity;

    public java.lang.Double getPrice()
    {
        return price;
    }

    public void setPrice(java.lang.Double price)
    {
        this.price = price;
    }

    public java.lang.String getManager()
    {
        return manager;
    }

    public void setManager(java.lang.String manager)
    {
        this.manager = manager;
    }

    public java.lang.Double getValue()
    {
        return value;
    }

    public void setValue(java.lang.Double value)
    {
        this.value = value;
    }

    public java.lang.String getSymbol()
    {
        return symbol;
    }

    public void setSymbol(java.lang.String symbol)
    {
        this.symbol = symbol;
    }

    public java.util.Date getDate()
    {
        return date;
    }

    public void setDate(java.util.Date date)
    {
        this.date = date;
    }

    public java.lang.Long getId()
    {
        return id;
    }

    public void setId(java.lang.Long id)
    {
        this.id = id;
    }

    public java.lang.String getFund()
    {
        return fund;
    }

    public void setFund(java.lang.String fund)
    {
        this.fund = fund;
    }

    public java.lang.Integer getMonths()
    {
        return months;
    }

    public void setMonths(java.lang.Integer months)
    {
        this.months = months;
    }

    public java.lang.Double getQuantity()
    {
        return quantity;
    }

    public void setQuantity(java.lang.Double quantity)
    {
        this.quantity = quantity;
    }

}
