package com.ssc.cdt.data;

import com.ssc.cloud.jbio.Col;
import com.ssc.cloud.jbio.IdfColType;
import com.ssc.cloud.jbio.IdfInOut;
import com.ssc.cloud.jbio.RSColType;

@IdfInOut(
{
    @Col(beanProp="linkId", idfColName="linkId", idfColType=IdfColType.LONG, rsColName="LINKID", rsColType=RSColType.LONG),
    @Col(beanProp="userId", idfColName="userId", idfColType=IdfColType.STRING, rsColName="USERID", rsColType=RSColType.STRING),
    @Col(beanProp="order", idfColName="order", idfColType=IdfColType.INT, rsColName="ORDER", rsColType=RSColType.INT)
}
)

public class Favorite extends AbstractCdtUiBean
{

    private Long linkId;
    private java.lang.String userId;
    private Integer order;
    
	public Integer getOrder() {
		return order;
	}
	public void setOrder(Integer order) {
		this.order = order;
	}
	public Long getLinkId() {
		return linkId;
	}
	public void setLinkId(Long linkId) {
		this.linkId = linkId;
	}
	public java.lang.String getUserId() {
		return userId;
	}
	public void setUserId(java.lang.String userId) {
		this.userId = userId;
	}
    
}
