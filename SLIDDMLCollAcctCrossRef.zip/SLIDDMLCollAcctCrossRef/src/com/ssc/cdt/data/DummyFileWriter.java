package com.ssc.cdt.data;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

public class DummyFileWriter {
	static Logger log = Logger.getLogger(DummyFileWriter.class);
	private static String path = System.getProperty("CDT.configJson");

	public String getJSONString(String fileName) {
		String str = "";
		try {
			File f = new File(path, fileName);
			if (f.exists()) {
				str = FileUtils.readFileToString(f, "UTF-8");
				log.info("loading data from file: " + f.getCanonicalPath());
			} else {
				log.info("file not found: " + path + "/" + fileName);
			}

		} catch (IOException e) {
			log.error(e);
		}

		return str;
	}

	public boolean fileExists(String fileName) {
		File f = new File(path, fileName);
		return f.exists();
	}

	public void writeJSONString(String fileName, String json) {
		try {
			File f = new File(path, fileName);
			FileUtils.writeStringToFile(f, json, "UTF-8");
			log.info("wrote file: " + f.getCanonicalPath());
		} catch (IOException e) {
			log.error(e);
		}
	}

}
