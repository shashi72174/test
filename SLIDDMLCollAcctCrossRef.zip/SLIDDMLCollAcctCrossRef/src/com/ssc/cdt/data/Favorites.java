package com.ssc.cdt.data;

import java.lang.reflect.Type;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.google.gson.reflect.TypeToken;
import com.ssc.cloud.jbio.JBIOMappingException;
import com.ssc.cloud.jbio.JBIOUnderlyingDataSourceException;
import com.ssc.faw.util.GenException;

public class Favorites extends AbstractCdtUiService<Favorite> {
	private static Type mapType = new TypeToken<Map<Long, Favorite>>(){}.getType();
	static Map<Long, Object> objectMap = null;

	Type getMapType() {
		return 	mapType;
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public void addNew(Favorite inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		String user = getUser();
		Date dt = new Date();
		
		// remove all existing favorites for this user
		// only do this for dummy json implementation,
		// not for dB, where we need to just set active flag
		
		Iterator it = objectMap.entrySet().iterator();
		
		while(it.hasNext()) {
			Map.Entry kv = (Map.Entry) it.next();
			Favorite f = (Favorite) kv.getValue();
			if (user.equals(f.getUserId())) {
				it.remove();
			}
		}
		
		// now add the new ones
		
		List<Favorite> items = listParams();
		
		for (Favorite item : items) {
			if (item.getLinkId() == null) {
				continue;
			}
			item.setId(getNextId());
			item.setCreatedAt(dt);
			item.setUserId(user);
			item.setCreatedBy(user);
			item.setLastUpdated(dt);
			item.setLastUpdatedBy(user);
			item.setAppcode(appcode);
			item.setActive(ACTIVE);
			objectMap.put(item.getId(), item);
		}
		
		writeMap();
		outputResults(items);
	}

	@Override
	Map<Long, Object> getObjectMap() {
		return Favorites.objectMap;
	}

	@Override
	void setObjectMap(Map<Long, Object> objectMap) {
		Favorites.objectMap = objectMap;
	}

	@Override
	public void loadList(Favorite inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		String user = getUser();
		
		Collection<Object> favorites = objectMap.values();

		for (Object fav : favorites) {
			Favorite favorite = (Favorite)fav;
			if (user.equals(favorite.getUserId()) && ACTIVE.equals(favorite.getActive())) {
				outputResults(favorite);
			}
		}
	}
	
	
}
