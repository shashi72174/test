package com.ssc.cdt.data;

import java.lang.reflect.Type;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.google.gson.reflect.TypeToken;
import com.ssc.cloud.jbio.JBIOMappingException;
import com.ssc.cloud.jbio.JBIOUnderlyingDataSourceException;
import com.ssc.faw.util.GenException;

public class ColumnFavorites extends AbstractCdtUiService<ColumnFavorite> {
	private static Type mapType = new TypeToken<Map<Long, ColumnFavorite>>(){}.getType();
	static Map<Long, Object> objectMap = null;
	
	Type getMapType() {
		return 	mapType;
	}

	@Override
	Map<Long, Object> getObjectMap() {
		return ColumnFavorites.objectMap;
	}

	@Override
	void setObjectMap(Map<Long, Object> objectMap) {
		ColumnFavorites.objectMap = objectMap;
	}

	@Override
	public void loadList(ColumnFavorite inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		
		String componentId = inputParams.getComponentId();
		String user = getUser();
		
		if (componentId == null) {
			super.loadList(inputParams);
		} else {
			Collection<Object> columnFavorites = objectMap.values();
			
			for (Object item : columnFavorites) {
				ColumnFavorite col = (ColumnFavorite)item;
				if (componentId.equals(col.getComponentId()) && user.equals(col.getUserId())) {
					outputResults(col);
				}
			}
		}
	}

	@Override
	public void update(ColumnFavorite inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		String user = getUser();
		Map<Long, Object> objectMap = getObjectMap();
		List<ColumnFavorite> addedItems = listParams();
		
		for (ColumnFavorite item : addedItems) {
			ColumnFavorite original = (ColumnFavorite)objectMap.get(item.getId());
			Date dt = new Date();
			original.setLastUpdated(dt);
			original.setLastUpdatedBy(user);
			original.setActive(ACTIVE);
			original.setTag(item.getTag());
			outputResults(original);
		}
		
		writeMap();
	}

	@Override
	public void addNew(ColumnFavorite inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		String user = getUser();
		Map<Long, Object> objectMap = getObjectMap();
		List<ColumnFavorite> addedItems = listParams();
		
		for (ColumnFavorite item : addedItems) {
			item.setId(getNextId());
			Date dt = new Date();
			item.setCreatedAt(dt);
			item.setCreatedBy(getUser());
			item.setLastUpdated(dt);
			item.setLastUpdatedBy(getUser());
			item.setAppcode(appcode);
			item.setActive(ACTIVE);
			item.setUserId(user);
			objectMap.put(item.getId(), item);
			outputResults(item);
		}
		
		writeMap();
	}

	@Override
	public void delete(ColumnFavorite inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		Map<Long, Object> objectMap = getObjectMap();

		List<ColumnFavorite> deletedItems = listParams();
		for (ColumnFavorite item : deletedItems) {
			objectMap.remove(item.getId());
			outputResults(item);
		}
		writeMap();
	}
	
	

}
