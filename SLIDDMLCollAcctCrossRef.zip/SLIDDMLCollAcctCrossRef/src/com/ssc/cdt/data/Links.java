package com.ssc.cdt.data;

import java.lang.reflect.Type;
import java.util.Map;

import com.google.gson.reflect.TypeToken;

public class Links extends AbstractCdtUiService<Link> {
	private static Type mapType = new TypeToken<Map<Long, Link>>(){}.getType();
	static Map<Long, Object> objectMap = null;
	
	Type getMapType() {
		return 	mapType;
	}

	@Override
	Map<Long, Object> getObjectMap() {
		return Links.objectMap;
	}

	@Override
	void setObjectMap(Map<Long, Object> objectMap) {
		Links.objectMap = objectMap;
	}
}
