package com.ssc.cdt.data;

import java.io.File;

import org.apache.log4j.Logger;

import com.ssc.faw.intref2.Request;
import com.ssc.faw.intref2.Tabular;
import com.ssc.faw.intref2.TabularListener;
import com.ssc.faw.util.CloudException;
import com.ssc.faw.util.GenException;


public class IDF_25990008 implements Tabular {
	static Logger log = Logger.getLogger(IDF_25990008.class);

	@Override
	public void process(Request req, TabularListener listener) throws GenException {
		try {
			Object[][] inputs = req.getInputs();
			String firstName = null;
			String lastName = null;
			String email = null;
			String fileName = null;

			if (inputs.length == 1 && inputs[0].length == 4) {
				firstName = (String) inputs[0][0];
				lastName  = (String) inputs[0][1];
				email     = (String) inputs[0][2];
				fileName  = (String) inputs[0][3];
			}

			File f = new File(fileName);

			if (!f.exists()) {
				throw new CloudException(25990008, "file does not exist");
			} else {
				log.info("check successful for file: " + f.getAbsolutePath());
			}


			Object[] outputs = new Object[] { "File processed for " + firstName + " " + lastName};

			listener.addRow(outputs);
		} finally {
			listener.close();
		}
	}
}
