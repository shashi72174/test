package com.ssc.cdt.data;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.ssc.faw.intref2.Request;
import com.ssc.faw.intref2.Tabular;
import com.ssc.faw.intref2.TabularListener;
import com.ssc.faw.util.GenException;


public class IDF_25990013 implements Tabular{

	private static final int ID = 0;
	private static final int SYMBOL = 1;
	private static final int MANAGER = 2;
	private static final int FUND = 3;
	private static final int PRICE = 4;
	private static final int QUANTITY = 5;
	private static final int VALUE = 6;
	private static final int DATE = 7;
	private DataUtil dataUtil = new DataUtil();
	
	
	@Override
	public void process(Request req, TabularListener listener) throws GenException {

		try {
			listener.open();
			Integer months = 1;

			Object[][] inputs = req.getInputs();
			if (inputs != null && inputs.length > 0 && inputs[0].length > 0 && inputs[0][0] != null) {
				months = (Integer) inputs[0][0];
			}
			
			int id = 0;
			List<Date> dates = dataUtil.getDates(months);
			
			for (Date dt : dates) {
				dataUtil.simulateActivity();
				for (String fund : DataUtil.FUNDS) {
					HashMap<String, Integer> symbols = dataUtil.getSymbols(fund);
					for (String symbol : symbols.keySet()) {
						Object[] row = new Object[8];
						row[ID] = id++;
						row[SYMBOL] = symbol;
						row[MANAGER] = dataUtil.getManager(fund);
						row[FUND] = fund;
						int price = dataUtil.getCurrentPrice(symbol);
						int qty = symbols.get(symbol);
						row[PRICE] = price;
						row[QUANTITY] = qty;
						row[VALUE] = price * qty;
						row[DATE] = dt;
						listener.addRow(row);
					}
				}
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			listener.close();
		}
	}}
