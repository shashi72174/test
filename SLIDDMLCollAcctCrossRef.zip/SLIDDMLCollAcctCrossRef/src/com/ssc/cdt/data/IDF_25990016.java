package com.ssc.cdt.data;

import java.util.Calendar;
import java.util.Random;

import org.apache.log4j.Logger;

import com.ssc.faw.intref2.IDF_Data;
import com.ssc.faw.intref2.IDF_Output;
import com.ssc.faw.intref2.Request;
import com.ssc.faw.intref2.ServiceTabularData;
import com.ssc.faw.intref2.Tabular;
import com.ssc.faw.intref2.TabularListener;
import com.ssc.faw.util.GenException;


public class IDF_25990016 implements Tabular{

	static Logger log = Logger.getLogger(IDF_25990016.class);
	
	private static final String GET_COLUMNS = "GET_COLUMNS";
	private static Random random = new Random();

	private static String[] COLS = { "STRING_COL", "DOUBLE_COL", "DATE_COL", "DATE_TIME_COL" };
	private static String[] LABELS = { "String Column", "Double Column", "Date Column", "Datetime Column"};
	private static String[] DATA_TYPES = { "string", "double", "date", "datetime" };
	
	@Override
	public void process(Request req, TabularListener listener) throws GenException {

		Object[][] inputs = req.getInputs();

		try {
			if (inputs.length > 0 && inputs[0].length > 0) {
				String action = (String) inputs[0][0];

				if (GET_COLUMNS.equals(action)) {

					for (int i = 0; i < COLS.length; i++) {
						listener.addRow(new Object[] { COLS[i], LABELS[i], DATA_TYPES[i] });
					}

				} else {
					IDF_Data idfData = (IDF_Data) IDF_Data.get(req.getRequestId()).clone();
					int len = COLS.length;
					IDF_Output[] outputs = new IDF_Output[COLS.length];
					
					for (int i = 0; i < COLS.length; i++) {
						outputs[i] = new IDF_Output(COLS[i], "", DATA_TYPES[i], "");
					}

					idfData.setOutputs(outputs);
					((ServiceTabularData) listener).setIdfData(idfData);

			        Calendar cal = Calendar.getInstance();
					
					for (int i = 0; i < 50; i++) {
						Object[] outputRow = new Object[len];
						cal.add(Calendar.DATE, -random.nextInt(20));
						outputRow[0] = "Item " + i;
						outputRow[1] = random.nextDouble() * 1000;
						outputRow[2] = cal.getTime();
						outputRow[3] = cal.getTime();
						listener.addRow(outputRow);
					}
				}
			}

		} catch (Exception e) {

		} finally {
			listener.close();
		}
	}
}