package com.ssc.cdt.data;

import java.util.Date;

import com.ssc.cloud.jbio.Col;
import com.ssc.cloud.jbio.IdfColType;
import com.ssc.cloud.jbio.IdfInOut;

@IdfInOut(
{
	@Col(beanProp="itemType", idfColName="itemType", idfColType=IdfColType.INT),
	@Col(beanProp="name", idfColName="name", idfColType=IdfColType.STRING),
	@Col(beanProp="description", idfColName="description", idfColType=IdfColType.STRING),
	@Col(beanProp="inception", idfColName="inception", idfColType=IdfColType.DATE)
}
)
public class FundClass extends AbstractCdtUiBean {

	private String name;
	private String description;
	private Integer itemType;
	private Date inception;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getInception() {
		return inception;
	}
	public void setInception(Date inception) {
		this.inception = inception;
	}
	public Integer getItemType() {
		return itemType;
	}
	public void setItemType(Integer itemType) {
		this.itemType = itemType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
