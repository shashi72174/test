package com.ssc.cdt.data;

import java.sql.SQLException;
import com.ssc.cloud.jbio.JBIOAbstractService;
import com.ssc.cloud.jbio.JBIOMappingException;
import com.ssc.cloud.jbio.JBIOUnderlyingDataSourceException;
import com.ssc.faw.util.GenException;

public class IDF_25990002 extends JBIOAbstractService<Department, Department> {
	private static final String[] departments = new String[] {
			"Human Resources", "Finance", "Sales EU", "Internal Tech Support",
			"PM Development", "PM Offshore", "Sales US", "Sales APAC",
			"Financial Development", "Human Resources APAC" };

	@Override
	public void loadList(Department inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		for (int i = 0; i < departments.length; i++) {
			Department d = new Department();
			d.setDepartmentId(i);
			d.setDepartmentName(departments[i]);
			mapForReturn(d);
			outputRow();
		}
	}
}
