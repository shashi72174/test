package com.ssc.cdt.data;

import org.apache.log4j.Logger;

import com.ssc.faw.intref2.Request;
import com.ssc.faw.intref2.Tabular;
import com.ssc.faw.intref2.TabularListener;
import com.ssc.faw.util.GenException;

/**
 * In this IDF you would use eSFProxy to perform logic to get GUI function
 * entitlements from ESF.
 * 
 */
public class IDF_25990012 implements Tabular {
	private static Logger log = Logger.getLogger(IDF_25990012.class);
	private static String[] entitledFunctions = new String[] { 
		"READ_ACCOUNT",
		"UPDATE_ACCOUNT", 
		"CREATE_ACCOUNT", 
		"DELETE_ACCOUNT",
		"UPDATE_USER", 
		"CREATE_USER"
		};

	@Override
	public void process(Request req, TabularListener listener)
			throws GenException {

		try {
			for (String ent : entitledFunctions) {

				listener.addRow(new Object[] { ent });
			}

		} catch (Exception e) {
			log.error("Exception getting entitled functions", e);
		} finally {
			listener.close();
		}
	}

}
