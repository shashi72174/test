package com.ssc.cdt.data;

import java.sql.SQLException;
import java.util.Date;
import java.util.Random;

import org.apache.log4j.Logger;

import com.ssc.cloud.jbio.JBIOAbstractService;
import com.ssc.cloud.jbio.JBIOMappingException;
import com.ssc.cloud.jbio.JBIOUnderlyingDataSourceException;
import com.ssc.faw.util.GenException;

public class IDF_25990015 extends
		JBIOAbstractService<GridDemoBean, GridDemoBean> {

	static Logger log = Logger.getLogger(IDF_25990015.class);
	private static Random rand = new Random();

	@Override
	public void loadList(GridDemoBean inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		for (int i = 0; i < 500; i++) {
			GridDemoBean b = new GridDemoBean();

			b.setClock(rand.nextInt(4));
			b.setExclaim(rand.nextInt(3));
			b.setJump(rand.nextInt(2));
			
			b.setTimestamp(new Date(new Date().getTime() - rand.nextInt(200000)));
			b.setColumn1("T3B1");
			b.setCol2("A");
			b.setColumn3(rand.nextInt(300) * rand.nextDouble());
			b.setColumn4(rand.nextInt(100000) * rand.nextDouble());
			b.setColumn5(rand.nextInt(10) * rand.nextDouble());
			b.setColumn6(rand.nextInt(10) * rand.nextDouble());
			b.setColumn7(rand.nextInt(10) * rand.nextDouble());
			b.setColumn8(rand.nextInt(10) * rand.nextDouble());
			b.setColumn9(rand.nextInt(10) * rand.nextDouble());
			b.setColumn10(rand.nextInt(10) * rand.nextDouble());
			b.setColumn11(rand.nextInt(10) * rand.nextDouble());
			mapForReturn(b);
			outputRow();
		}
	}

}
