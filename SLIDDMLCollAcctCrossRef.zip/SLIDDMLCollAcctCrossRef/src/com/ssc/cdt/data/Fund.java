package com.ssc.cdt.data;

import java.util.List;
import com.ssc.cloud.jbio.Col;
import com.ssc.cloud.jbio.IdfColType;
import com.ssc.cloud.jbio.IdfInOut;

@IdfInOut(
{
    @Col(beanProp="pagesize", idfColName=Fund.PAGESIZE, idfColType=IdfColType.INT),
    @Col(beanProp="start", idfColName=Fund.START, idfColType=IdfColType.INT),
    @Col(beanProp="fundName", idfColName=Fund.FUND_NAME, idfColType=IdfColType.STRING),
    @Col(beanProp="stop", idfColName=Fund.STOP, idfColType=IdfColType.INT),
    @Col(beanProp="totalrows", idfColName=Fund.TOTALROWS, idfColType=IdfColType.INT),
    @Col(beanProp="fundId", idfColName=Fund.FUND_ID, idfColType=IdfColType.INT),
}
)

public class Fund
{
    public static final String PAGESIZE = "PAGESIZE";
    public static final String START = "START";
    public static final String FUND_NAME = "FUND_NAME";
    public static final String STOP = "STOP";
    public static final String TOTALROWS = "TOTALROWS";
    public static final String FUND_ID = "FUND_ID";

    private java.lang.Integer pagesize;
    private java.lang.Integer start;
    private java.lang.String fundName;
    private java.lang.Integer stop;
    private java.lang.Integer totalrows;
    private java.lang.Integer fundId;

    public java.lang.Integer getPagesize()
    {
        return pagesize;
    }

    public void setPagesize(java.lang.Integer pagesize)
    {
        this.pagesize = pagesize;
    }

    public java.lang.Integer getStart()
    {
        return start;
    }

    public void setStart(java.lang.Integer start)
    {
        this.start = start;
    }

    public java.lang.String getFundName()
    {
        return fundName;
    }

    public void setFundName(java.lang.String fundName)
    {
        this.fundName = fundName;
    }

    public java.lang.Integer getStop()
    {
        return stop;
    }

    public void setStop(java.lang.Integer stop)
    {
        this.stop = stop;
    }

    public java.lang.Integer getTotalrows()
    {
        return totalrows;
    }

    public void setTotalrows(java.lang.Integer totalrows)
    {
        this.totalrows = totalrows;
    }

    public java.lang.Integer getFundId()
    {
        return fundId;
    }

    public void setFundId(java.lang.Integer fundId)
    {
        this.fundId = fundId;
    }

}
