package com.ssc.cdt.data;

import com.ssc.cloud.jbio.Col;
import com.ssc.cloud.jbio.IdfColType;
import com.ssc.cloud.jbio.IdfInOut;
import com.ssc.cloud.jbio.RSColType;

@IdfInOut(
{
	@Col(beanProp="componentId", idfColName="componentId", idfColType=IdfColType.STRING, rsColName="componentId", rsColType=RSColType.STRING),
	@Col(beanProp="label", idfColName="label", idfColType=IdfColType.STRING, rsColName="label", rsColType=RSColType.STRING),
	@Col(beanProp="dataIdf", idfColName="dataIdf", idfColType=IdfColType.INT, rsColName="dataIdf", rsColType=RSColType.INT),
	@Col(beanProp="pageSize", idfColName="pageSize", idfColType=IdfColType.INT, rsColName="pageSize", rsColType=RSColType.INT),
	@Col(beanProp="url", idfColName="url", idfColType=IdfColType.STRING, rsColName="url", rsColType=RSColType.STRING),
	@Col(beanProp="keyFieldName", idfColName="keyFieldName", idfColType=IdfColType.STRING, rsColName="keyFieldName", rsColType=RSColType.STRING),
	@Col(beanProp="parentFieldName", idfColName="parentFieldName", idfColType=IdfColType.STRING, rsColName="parentFieldName", rsColType=RSColType.STRING),
	@Col(beanProp="excelExport", idfColName="excelExport", idfColType=IdfColType.INT, rsColName="excelExport", rsColType=RSColType.INT),
	@Col(beanProp="csvExport", idfColName="csvExport", idfColType=IdfColType.INT, rsColName="csvExport", rsColType=RSColType.INT)
}
)

public class GridConfig extends AbstractCdtUiBean
{
	private String componentId;
	private String label;
	private Integer dataIdf;
	private Integer pageSize;
	private String url;
	private String keyFieldName;
	private String parentFieldName;
	private Integer excelExport;
	private Integer csvExport;
	
	public String getComponentId() {
		return componentId;
	}
	public void setComponentId(String componentId) {
		this.componentId = componentId;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public Integer getDataIdf() {
		return dataIdf;
	}
	public void setDataIdf(Integer dataIdf) {
		this.dataIdf = dataIdf;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getKeyFieldName() {
		return keyFieldName;
	}
	public void setKeyFieldName(String keyFieldName) {
		this.keyFieldName = keyFieldName;
	}
	public String getParentFieldName() {
		return parentFieldName;
	}
	public void setParentFieldName(String parentFieldName) {
		this.parentFieldName = parentFieldName;
	}
	public Integer getExcelExport() {
		return excelExport;
	}
	public void setExcelExport(Integer excelExport) {
		this.excelExport = excelExport;
	}
	public Integer getCsvExport() {
		return csvExport;
	}
	public void setCsvExport(Integer csvExport) {
		this.csvExport = csvExport;
	}
    
}
