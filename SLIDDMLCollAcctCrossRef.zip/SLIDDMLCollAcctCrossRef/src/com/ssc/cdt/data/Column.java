package com.ssc.cdt.data;

import com.ssc.cloud.jbio.Col;
import com.ssc.cloud.jbio.IdfColType;
import com.ssc.cloud.jbio.IdfInOut;
import com.ssc.cloud.jbio.RSColType;

@IdfInOut(
{
	@Col(beanProp="componentId", idfColName="componentId", idfColType=IdfColType.STRING, rsColName="componentId", rsColType=RSColType.STRING),
	@Col(beanProp="tag", idfColName="tag", idfColType=IdfColType.STRING, rsColName="tag", rsColType=RSColType.STRING),
	@Col(beanProp="dataKey", idfColName="dataKey", idfColType=IdfColType.STRING, rsColName="dataKey", rsColType=RSColType.STRING),
	@Col(beanProp="label", idfColName="label", idfColType=IdfColType.STRING, rsColName="label", rsColType=RSColType.STRING),
	@Col(beanProp="width", idfColName="width", idfColType=IdfColType.STRING, rsColName="width", rsColType=RSColType.STRING),
	@Col(beanProp="align", idfColName="align", idfColType=IdfColType.STRING, rsColName="align", rsColType=RSColType.STRING),
	@Col(beanProp="dataType", idfColName="dataType", idfColType=IdfColType.STRING, rsColName="dataType", rsColType=RSColType.STRING),
	@Col(beanProp="dateFormat", idfColName="dateFormat", idfColType=IdfColType.STRING, rsColName="dateFormat", rsColType=RSColType.STRING),
	@Col(beanProp="numberFormat", idfColName="numberFormat", idfColType=IdfColType.STRING, rsColName="numberFormat", rsColType=RSColType.STRING),
	@Col(beanProp="cell", idfColName="cell", idfColType=IdfColType.STRING, rsColName="cell", rsColType=RSColType.STRING),
	@Col(beanProp="header", idfColName="header", idfColType=IdfColType.STRING, rsColName="header", rsColType=RSColType.STRING),
	@Col(beanProp="editor", idfColName="editor", idfColType=IdfColType.STRING, rsColName="editor", rsColType=RSColType.STRING),
	@Col(beanProp="index", idfColName="index", idfColType=IdfColType.INT, rsColName="index", rsColType=RSColType.INT),
	@Col(beanProp="menu", idfColName="menu", idfColType=IdfColType.INT, rsColName="menu", rsColType=RSColType.INT),
	@Col(beanProp="isKey", idfColName="isKey", idfColType=IdfColType.INT, rsColName="isKey", rsColType=RSColType.INT),
	@Col(beanProp="isParentKey", idfColName="isParentKey", idfColType=IdfColType.INT, rsColName="isParentKey", rsColType=RSColType.INT),
	@Col(beanProp="sort", idfColName="sort", idfColType=IdfColType.INT, rsColName="sort", rsColType=RSColType.INT),
	@Col(beanProp="edit", idfColName="edit", idfColType=IdfColType.INT, rsColName="edit", rsColType=RSColType.INT),
	@Col(beanProp="hidden", idfColName="hidden", idfColType=IdfColType.INT, rsColName="hidden", rsColType=RSColType.INT),
	@Col(beanProp="fixed", idfColName="fixed", idfColType=IdfColType.INT, rsColName="fixed", rsColType=RSColType.INT),
	@Col(beanProp="group", idfColName="group", idfColType=IdfColType.INT, rsColName="group", rsColType=RSColType.INT),
	@Col(beanProp="hideForExport", idfColName="hideForExport", idfColType=IdfColType.INT, rsColName="hideForExport", rsColType=RSColType.INT)
}
)

public class Column extends AbstractCdtUiBean
{
	private String componentId;
	private String tag;
	private String dataKey;
	private String label;
	private String width;
	private String align;
	private String dataType;
	private String dateFormat;
	private String numberFormat;
	private String cell;
	private String header;
	private String editor;
	private Integer index;
	private Integer menu;
	private Integer isKey;
	private Integer isParentKey;
	private Integer sort;
	private Integer edit;
	private Integer hidden;
	private Integer fixed;
	private Integer group;
	private Integer hideForExport;
	
	public String getDataKey() {
		return dataKey;
	}
	public void setDataKey(String dataKey) {
		this.dataKey = dataKey;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getWidth() {
		return width;
	}
	public void setWidth(String width) {
		this.width = width;
	}
	public String getAlign() {
		return align;
	}
	public void setAlign(String align) {
		this.align = align;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getDateFormat() {
		return dateFormat;
	}
	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}
	public String getNumberFormat() {
		return numberFormat;
	}
	public void setNumberFormat(String numberFormat) {
		this.numberFormat = numberFormat;
	}
	public String getCell() {
		return cell;
	}
	public void setCell(String cell) {
		this.cell = cell;
	}
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public String getEditor() {
		return editor;
	}
	public void setEditor(String editor) {
		this.editor = editor;
	}
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
	public Integer getMenu() {
		return menu;
	}
	public void setMenu(Integer menu) {
		this.menu = menu;
	}
	public Integer getIsKey() {
		return isKey;
	}
	public void setIsKey(Integer isKey) {
		this.isKey = isKey;
	}
	public Integer getIsParentKey() {
		return isParentKey;
	}
	public void setIsParentKey(Integer isParentKey) {
		this.isParentKey = isParentKey;
	}
	public Integer getSort() {
		return sort;
	}
	public void setSort(Integer sort) {
		this.sort = sort;
	}
	public Integer getEdit() {
		return edit;
	}
	public void setEdit(Integer edit) {
		this.edit = edit;
	}
	public Integer getHidden() {
		return hidden;
	}
	public void setHidden(Integer hidden) {
		this.hidden = hidden;
	}
	public Integer getFixed() {
		return fixed;
	}
	public void setFixed(Integer fixed) {
		this.fixed = fixed;
	}
	public Integer getGroup() {
		return group;
	}
	public void setGroup(Integer group) {
		this.group = group;
	}
	public Integer getHideForExport() {
		return hideForExport;
	}
	public void setHideForExport(Integer hideForExport) {
		this.hideForExport = hideForExport;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getComponentId() {
		return componentId;
	}
	public void setComponentId(String componentId) {
		this.componentId = componentId;
	}
    
    
}
