package com.ssc.cdt.data;

import com.ssc.cloud.jbio.Col;
import com.ssc.cloud.jbio.IdfColType;
import com.ssc.cloud.jbio.IdfInOut;

@IdfInOut(
{
    @Col(beanProp="departmentId", idfColName=Department.DEPARTMENT_ID, idfColType=IdfColType.INT),
    @Col(beanProp="departmentName", idfColName=Department.DEPARTMENT_NAME, idfColType=IdfColType.STRING),
}
)

public class Department
{
    public static final String DEPARTMENT_ID = "DEPARTMENT_ID";
    public static final String DEPARTMENT_NAME = "DEPARTMENT_NAME";

    private java.lang.Integer departmentId;
    private java.lang.String departmentName;

    public java.lang.Integer getDepartmentId()
    {
        return departmentId;
    }

    public void setDepartmentId(java.lang.Integer departmentId)
    {
        this.departmentId = departmentId;
    }

    public java.lang.String getDepartmentName()
    {
        return departmentName;
    }

    public void setDepartmentName(java.lang.String departmentName)
    {
        this.departmentName = departmentName;
    }

}
