package com.ssc.cdt.data;

import java.util.HashMap;
import java.util.Map;

public class CdtCellMetadata
{
    public static String OUTPUT_NAME = "__cellMetadata";
    private HashMap<String, HashMap<String, String>> cellProperties = new HashMap<String, HashMap<String, String>>();
    
    private HashMap<String, String> getPropertyMap(String cellName) 
    {
	HashMap<String, String> props = cellProperties.get(cellName);
	if (props == null)
	{
	    props = new HashMap<String, String>();
	    cellProperties.put(cellName, props);
	}
	return props;
    }
    
    public void putCellProperties (String cellName, Map<String, String> properties)
    {
	HashMap<String, String> props = getPropertyMap(cellName);
	for (String key : properties.keySet())
	{
	    props.put(key, properties.get(key));
	}
    }
    
    public void putCellProperty(String cellName, String propName, String propValue)
    {
	getPropertyMap(cellName).put(propName, propValue);
    }

    @Override
    public String toString()
    {
	StringBuilder sb = new StringBuilder("{ \n");
	String sep = "";
	for (String key : cellProperties.keySet())
	{
	    sb.append(sep);
	    sb.append(getObjectString(key));
	    appendProperties(sb, cellProperties.get(key));
	    sb.append("}");
	    sep = ",\n";
	}
	
	sb.append("\n}");
	return sb.toString();
    }
    
    private void appendProperties(StringBuilder sb, HashMap<String, String> props)
    {
	String sep = "";
	for (String key : props.keySet())
	{
	    sb.append(sep);
	    sb.append(getPropertyString(key, props.get(key)));
	    sep = ",\n";
	}
    }
    
    private String getObjectString(String str)
    {
	return quote(str) + " : {  \n";
    }
    
    private String getPropertyString(String prop, String value)
    {
	return quote(prop) + " : " + quote(value);
    }
    
    private String quote(String str)
    {
	return "\"" + str + "\"";
    }
    
}
