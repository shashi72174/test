package com.ssc.cdt.data;

import java.util.List;
import java.util.HashMap;
import com.ssc.cloud.jbio.Col;
import com.ssc.cloud.jbio.IdfColType;
import com.ssc.cloud.jbio.IdfInOut;

@IdfInOut(
{
    @Col(beanProp="column4", idfColName=GridDemoBean.COLUMN_4, idfColType=IdfColType.DOUBLE),
    @Col(beanProp="column3", idfColName=GridDemoBean.COLUMN_3, idfColType=IdfColType.DOUBLE),
    @Col(beanProp="column1", idfColName=GridDemoBean.COLUMN_1, idfColType=IdfColType.STRING),
    @Col(beanProp="column8", idfColName=GridDemoBean.COLUMN_8, idfColType=IdfColType.DOUBLE),
    @Col(beanProp="column7", idfColName=GridDemoBean.COLUMN_7, idfColType=IdfColType.DOUBLE),
    @Col(beanProp="column6", idfColName=GridDemoBean.COLUMN_6, idfColType=IdfColType.DOUBLE),
    @Col(beanProp="column5", idfColName=GridDemoBean.COLUMN_5, idfColType=IdfColType.DOUBLE),
    @Col(beanProp="exclaim", idfColName=GridDemoBean.EXCLAIM, idfColType=IdfColType.INT),
    @Col(beanProp="col2", idfColName=GridDemoBean.COL_2, idfColType=IdfColType.STRING),
    @Col(beanProp="column10", idfColName=GridDemoBean.COLUMN_10, idfColType=IdfColType.DOUBLE),
    @Col(beanProp="column11", idfColName=GridDemoBean.COLUMN_11, idfColType=IdfColType.DOUBLE),
    @Col(beanProp="column9", idfColName=GridDemoBean.COLUMN_9, idfColType=IdfColType.DOUBLE),
    @Col(beanProp="timestamp", idfColName=GridDemoBean.TIMESTAMP, idfColType=IdfColType.DATETIME),
    @Col(beanProp="clock", idfColName=GridDemoBean.CLOCK, idfColType=IdfColType.INT),
    @Col(beanProp="jump", idfColName=GridDemoBean.JUMP, idfColType=IdfColType.INT),
}
)

public class GridDemoBean
{
    public static final String COLUMN_4 = "COLUMN_4";
    public static final String COLUMN_3 = "COLUMN_3";
    public static final String COLUMN_1 = "COLUMN_1";
    public static final String COLUMN_8 = "COLUMN_8";
    public static final String COLUMN_7 = "COLUMN_7";
    public static final String COLUMN_6 = "COLUMN_6";
    public static final String COLUMN_5 = "COLUMN_5";
    public static final String EXCLAIM = "EXCLAIM";
    public static final String COL_2 = "COL_2";
    public static final String COLUMN_10 = "COLUMN_10";
    public static final String COLUMN_11 = "COLUMN_11";
    public static final String COLUMN_9 = "COLUMN_9";
    public static final String TIMESTAMP = "TIMESTAMP";
    public static final String CLOCK = "CLOCK";
    public static final String JUMP = "JUMP";

    private java.lang.Double column4;
    private java.lang.Double column3;
    private java.lang.String column1;
    private java.lang.Double column8;
    private java.lang.Double column7;
    private java.lang.Double column6;
    private java.lang.Double column5;
    private java.lang.Integer exclaim;
    private java.lang.String col2;
    private java.lang.Double column10;
    private java.lang.Double column11;
    private java.lang.Double column9;
    private java.util.Date timestamp;
    private java.lang.Integer clock;
    private java.lang.Integer jump;

    public java.lang.Double getColumn4()
    {
        return column4;
    }

    public void setColumn4(java.lang.Double column4)
    {
        this.column4 = column4;
    }

    public java.lang.Double getColumn3()
    {
        return column3;
    }

    public void setColumn3(java.lang.Double column3)
    {
        this.column3 = column3;
    }

    public java.lang.String getColumn1()
    {
        return column1;
    }

    public void setColumn1(java.lang.String column1)
    {
        this.column1 = column1;
    }

    public java.lang.Double getColumn8()
    {
        return column8;
    }

    public void setColumn8(java.lang.Double column8)
    {
        this.column8 = column8;
    }

    public java.lang.Double getColumn7()
    {
        return column7;
    }

    public void setColumn7(java.lang.Double column7)
    {
        this.column7 = column7;
    }

    public java.lang.Double getColumn6()
    {
        return column6;
    }

    public void setColumn6(java.lang.Double column6)
    {
        this.column6 = column6;
    }

    public java.lang.Double getColumn5()
    {
        return column5;
    }

    public void setColumn5(java.lang.Double column5)
    {
        this.column5 = column5;
    }

    public java.lang.Integer getExclaim()
    {
        return exclaim;
    }

    public void setExclaim(java.lang.Integer exclaim)
    {
        this.exclaim = exclaim;
    }

    public java.lang.String getCol2()
    {
        return col2;
    }

    public void setCol2(java.lang.String col2)
    {
        this.col2 = col2;
    }

    public java.lang.Double getColumn10()
    {
        return column10;
    }

    public void setColumn10(java.lang.Double column10)
    {
        this.column10 = column10;
    }

    public java.lang.Double getColumn11()
    {
        return column11;
    }

    public void setColumn11(java.lang.Double column11)
    {
        this.column11 = column11;
    }

    public java.lang.Double getColumn9()
    {
        return column9;
    }

    public void setColumn9(java.lang.Double column9)
    {
        this.column9 = column9;
    }

    public java.util.Date getTimestamp()
    {
        return timestamp;
    }

    public void setTimestamp(java.util.Date timestamp)
    {
        this.timestamp = timestamp;
    }

    public java.lang.Integer getClock()
    {
        return clock;
    }

    public void setClock(java.lang.Integer clock)
    {
        this.clock = clock;
    }

    public java.lang.Integer getJump()
    {
        return jump;
    }

    public void setJump(java.lang.Integer jump)
    {
        this.jump = jump;
    }

}
