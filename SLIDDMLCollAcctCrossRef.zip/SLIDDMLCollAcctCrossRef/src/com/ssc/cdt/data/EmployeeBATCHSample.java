package com.ssc.cdt.data;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.ssc.cloud.jbio.JBIOAbstractService;
import com.ssc.cloud.jbio.JBIOMappingException;
import com.ssc.cloud.jbio.JBIOUnderlyingDataSourceException;
import com.ssc.faw.util.GenException;


public class EmployeeBATCHSample extends JBIOAbstractService<Employee, Employee> {
    public static final Logger log = Logger.getLogger(EmployeeCRUDSample.class);
    private static EmployeeData empData = new EmployeeData();

    @Override
    public void update(Employee inputParams) throws GenException, JBIOMappingException,
            JBIOUnderlyingDataSourceException, SQLException {

    	List<Employee> inputs = listParams();
    	for (Employee emp : inputs) {
    		switch(emp.getEditState()) {
    		case 0: //add
    	        Integer id = new Integer(empData.size() + 1);
    	        emp.setId(id);
    	        empData.put(id, emp);
    			break;
    		case 1: // update
    			empData.put(emp.getId(), emp);
    			break;
    		case 2: // delete
    			empData.remove(emp.getId());
    			break;
			default:
				break;
    		}
            mapForReturn(emp);
            outputRow();
    	}
    }

    @Override
    public void loadList(Employee inputParams) throws GenException, JBIOMappingException,
            JBIOUnderlyingDataSourceException, SQLException {
    	List<Employee> employees = new ArrayList<Employee>( empData.values());
    	int len = employees.size();
    	for (int i = 0; i < len; i++) {
    		mapForReturn(employees.get(i));
    		outputRow();
    	}
    		
    }

}
