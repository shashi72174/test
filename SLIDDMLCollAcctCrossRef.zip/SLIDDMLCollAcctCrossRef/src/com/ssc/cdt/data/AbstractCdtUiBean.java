package com.ssc.cdt.data;

import java.util.Date;

import com.ssc.cloud.jbio.Col;
import com.ssc.cloud.jbio.IdfColType;
import com.ssc.cloud.jbio.IdfInOut;
import com.ssc.cloud.jbio.RSColType;

@IdfInOut(
{
	@Col(beanProp="id", idfColName="id", idfColType=IdfColType.LONG, rsColName="ID", rsColType=RSColType.LONG),
	@Col(beanProp="parentId", idfColName="parentId", idfColType=IdfColType.LONG, rsColName="PARENTID", rsColType=RSColType.LONG),
	@Col(beanProp="appcode", idfColName="appcode", idfColType=IdfColType.STRING, rsColName="APPCODE", rsColType=RSColType.STRING),
	@Col(beanProp="active", idfColName="active", idfColType=IdfColType.INT, rsColName="ACTIVE", rsColType=RSColType.INT)
}
)

public abstract class AbstractCdtUiBean implements HasId
{
    private Long id;
    private Long parentId;
    private Date lastUpdated;
    private Date createdAt;
    private String lastUpdatedBy;
    private String createdBy;
    private String appcode;
    private Integer active;
    
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public java.lang.Long getParentId() {
		return parentId;
	}
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	public Date getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getAppcode() {
		return appcode;
	}
	public void setAppcode(String appcode) {
		this.appcode = appcode;
	}
	public Integer getActive() {
		return active;
	}
	public void setActive(Integer active) {
		this.active = active;
	}
    
}
