package com.ssc.cdt.data;

import java.util.Date;

public interface HasId {
	Long getId();

	void setId(Long id);

	Date getLastUpdated();

	void setLastUpdated(Date lastUpdated);

	Date getCreatedAt();

	void setCreatedAt(Date createdAt);

	String getLastUpdatedBy();

	void setLastUpdatedBy(String lastUpdatedBy);

	String getCreatedBy();

	void setCreatedBy(String createdBy);
	
	void setAppcode(String appcode);
	
	String getAppcode();
	
	Integer getActive();
	
	void setActive(Integer active);

}
