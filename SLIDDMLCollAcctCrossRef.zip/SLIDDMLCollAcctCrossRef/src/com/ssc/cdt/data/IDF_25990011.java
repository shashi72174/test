package com.ssc.cdt.data;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.ssc.faw.controller.session.ThreadData;
import com.ssc.faw.intref2.Request;
import com.ssc.faw.intref2.Tabular;
import com.ssc.faw.intref2.TabularListener;
import com.ssc.faw.util.GenException;

/**
 * In a real application you would write the json to you database.
 * 
 * Note that if deployed to the cloud, files in /WEB-INF/cache get cleaned up so
 * you will lose any saved prefs. Also, of course any prefs saved to the file
 * system would be available only on that VM.
 * 
 * Use a database!
 * 
 */
public class IDF_25990011 implements Tabular {
	static Logger log = Logger.getLogger(IDF_25990011.class);
	private static String path = System.getProperty("FAW.fileCache.cacheDir");
	private static final String PREFS = "preferences.json";

	@Override
	public void process(Request req, TabularListener listener)
			throws GenException {

		Object[][] inputs = req.getInputs();

		String json = "";
		try {
			if (inputs.length > 0 && inputs[0].length > 0) {
				json = (String) inputs[0][0];
				writeJsonString(json);
			} else {
				json = getJsonString();
				listener.addRow(new Object[] { json });
			}
		} catch (Exception e) {

		} finally {
			listener.close();
		}
	}

	private String getJsonString() {
		String str = "";
		try {
			File f = getFile();
			if (f.exists()) {
				str = FileUtils.readFileToString(f, "UTF-8");
			} else {
				log.info("file not found");
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return str;
	}

	private void writeJsonString(String json) {
		try {
			File f = getFile();
			if (f.exists()) {
				FileUtils.writeStringToFile(f, json, "UTF-8");
			} else {
				log.info("file not found");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private File getFile() {
//		String user = ThreadData.getUser();
//		String fileName = path + File.separator + user + ".xml";
		String fileName = path + File.separator + PREFS;
		log.info("file name: " + fileName);
		return new File(fileName);
	}
}
