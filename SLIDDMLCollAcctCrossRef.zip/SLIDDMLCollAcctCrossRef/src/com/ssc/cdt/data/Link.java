package com.ssc.cdt.data;

import com.ssc.cloud.jbio.Col;
import com.ssc.cloud.jbio.IdfColType;
import com.ssc.cloud.jbio.IdfInOut;
import com.ssc.cloud.jbio.RSColType;

@IdfInOut(
{
    @Col(beanProp="label", idfColName="label", idfColType=IdfColType.STRING, rsColName="LABEL", rsColType=RSColType.STRING),
    @Col(beanProp="type", idfColName="type", idfColType=IdfColType.STRING, rsColName="TYPE", rsColType=RSColType.STRING),
    @Col(beanProp="link", idfColName="link", idfColType=IdfColType.STRING, rsColName="LINK", rsColType=RSColType.STRING),
    @Col(beanProp="target", idfColName="target", idfColType=IdfColType.STRING, rsColName="TARGET", rsColType=RSColType.STRING),
    @Col(beanProp="description", idfColName="description", idfColType=IdfColType.STRING, rsColName="DESCRIPTION", rsColType=RSColType.STRING),
    @Col(beanProp="classname", idfColName="className", idfColType=IdfColType.STRING, rsColName="CLASSNAME", rsColType=RSColType.STRING),
    @Col(beanProp="tag", idfColName="tag", idfColType=IdfColType.STRING, rsColName="TAG", rsColType=RSColType.STRING),
    @Col(beanProp="icon", idfColName="icon", idfColType=IdfColType.STRING, rsColName="ICON", rsColType=RSColType.STRING),
    @Col(beanProp="mobile", idfColName="mobile", idfColType=IdfColType.INT, rsColName="MOBILE", rsColType=RSColType.INT),
    @Col(beanProp="order", idfColName="order", idfColType=IdfColType.INT, rsColName="ORDER", rsColType=RSColType.INT)
}
)

public class Link extends AbstractCdtUiBean
{
    private java.lang.String label;
    private java.lang.String type;
    private java.lang.String link;
    private java.lang.String target;
    private java.lang.String description;
    private java.lang.String classname;
    private java.lang.String tag;
    private java.lang.String icon;
    private Integer mobile;
    private Integer order;
    
	public java.lang.String getLabel() {
		return label;
	}
	public void setLabel(java.lang.String label) {
		this.label = label;
	}
	public java.lang.String getType() {
		return type;
	}
	public void setType(java.lang.String type) {
		this.type = type;
	}
	public java.lang.String getLink() {
		return link;
	}
	public void setLink(java.lang.String link) {
		this.link = link;
	}
	public java.lang.String getTarget() {
		return target;
	}
	public void setTarget(java.lang.String target) {
		this.target = target;
	}
	public java.lang.String getDescription() {
		return description;
	}
	public void setDescription(java.lang.String description) {
		this.description = description;
	}
	public java.lang.String getClassname() {
		return classname;
	}
	public void setClassname(java.lang.String classname) {
		this.classname = classname;
	}
	public java.lang.String getTag() {
		return tag;
	}
	public void setTag(java.lang.String tag) {
		this.tag = tag;
	}
	public java.lang.String getIcon() {
		return icon;
	}
	public void setIcon(java.lang.String icon) {
		this.icon = icon;
	}
	public Integer getMobile() {
		return mobile;
	}
	public void setMobile(Integer mobile) {
		this.mobile = mobile;
	}
	public Integer getOrder() {
		return order;
	}
	public void setOrder(Integer order) {
		this.order = order;
	}
    
}
