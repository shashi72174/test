package com.ssc.cdt.data;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.List;

import oracle.jdbc.OracleTypes;

import org.apache.log4j.Logger;

import com.ssc.cloud.jbio.JBIOAbstractService;
import com.ssc.cloud.jbio.JBIOMappingException;
import com.ssc.cloud.jbio.JBIOUnderlyingDataSourceException;
import com.ssc.faw.util.GenException;

public class FavoritesDB extends JBIOAbstractService<Favorite, Favorite> {
	static Logger log = Logger.getLogger(FavoritesDB.class);

	final static String appcode = System.getProperty("OEC.APP", "CDT");

	public static final String LOADLIST = "{call FAVORITE_PKG.LOADLIST_FAVORITE(?, ?)}";
	public static final String ADDNEW = "{call FAVORITE_PKG.ADD_FAVORITE(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";
	public static final String DELETE = "{call FAVORITE_PKG.DELETE_FAVORITE()}";


	/* 
	 *  The logic here is a bit odd. addNew is called with a list of selected
	 *  Favorite object. First we set all favorites active flag to 0 by calling
	 *  the delete_favorite proc. Then we loop through the items and call the
	 *  addnew proc, which checks if the favorite exists, and if so sets it to active.
	 *  if it doesnt exist then it adds the Favorite.
	 */
	@Override
	public void addNew(Favorite inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		CallableStatement cs = null;
		Long now = new Date().getTime();
		String user = getUser();
		try {
			cs = prepareCall(DELETE);
			cs.execute();
			cs.close();
			
			List<Favorite> params = listParams();
			
			for (Favorite favorite : params) {
				cs = prepareCall(ADDNEW);
				cs.registerOutParameter("p_ID", Types.NUMERIC);
				cs.setObject("p_PARENTID", favorite.getParentId());
				cs.setDate("p_CREATEDAT", new java.sql.Date(now));
				cs.setDate("p_LASTUPDATED", new java.sql.Date(now));
				cs.setString("p_LASTUPDATEDBY", user);
				cs.setString("p_CREATEDBY", user);
				cs.setString("p_APPCODE", appcode);
				cs.setInt("p_ACTIVE", 1); //active
				cs.setLong("p_LINKID", favorite.getLinkId());
				cs.setString("p_USERID", user);
				cs.setObject("p_ORDER", favorite.getOrder());
				cs.execute();
				outputResults(favorite);
			}
		} catch (Exception e) {
			log.error("Exception adding Favorite", e);
			setErrorMsg("Error adding Favorite.");
			outputRow();
		} finally {
			try {
				cs.close();
			} catch (Exception e) {}
		}
	}

	@Override
	public void loadList(Favorite inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		
		ResultSet rs = null;
		CallableStatement cs = null;
		try {
			cs = prepareCall(LOADLIST);
			cs.registerOutParameter("FAVORITE_CUR", OracleTypes.CURSOR);
			cs.setString("p_USERID", getUser());
			cs.execute();
			rs = (ResultSet) cs.getObject("FAVORITE_CUR");
			if (rs.next()) {
				outputResults(rs);
			}
		} catch (Exception e) {
			log.error("Exception loading Favorites", e);
			setErrorMsg("Error loading Favorites.");
			outputRow();
		} finally {
			try {
				cs.close();
				rs.close();
			} catch (Exception e) {}
		}
	}
}
