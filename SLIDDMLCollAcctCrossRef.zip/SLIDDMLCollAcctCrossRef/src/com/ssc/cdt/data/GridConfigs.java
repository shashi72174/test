package com.ssc.cdt.data;

import java.lang.reflect.Type;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Map;

import com.google.gson.reflect.TypeToken;
import com.ssc.cloud.jbio.JBIOMappingException;
import com.ssc.cloud.jbio.JBIOUnderlyingDataSourceException;
import com.ssc.faw.util.GenException;

public class GridConfigs extends AbstractCdtUiService<GridConfig> {
	private static Type mapType = new TypeToken<Map<Long, GridConfig>>(){}.getType();
	static Map<Long, Object> objectMap = null;
	
	Type getMapType() {
		return 	mapType;
	}

	@Override
	Map<Long, Object> getObjectMap() {
		return GridConfigs.objectMap;
	}

	@Override
	void setObjectMap(Map<Long, Object> objectMap) {
		GridConfigs.objectMap = objectMap;
	}
	
	@Override
	public void loadList(GridConfig inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		
		String componentId = inputParams.getComponentId();
		
		if (componentId == null) {
			super.loadList(inputParams);
		} else {
			Collection<Object> columns = objectMap.values();
			
			for (Object item : columns) {
				GridConfig config = (GridConfig)item;
				if (componentId.equals(config.getComponentId())) {
					outputResults(config);
				}
			}
		}
	}

}
