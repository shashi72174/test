package com.ssc.cdt.data;

import java.lang.reflect.Type;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import com.google.gson.reflect.TypeToken;
import com.ssc.cloud.jbio.JBIOMappingException;
import com.ssc.cloud.jbio.JBIOUnderlyingDataSourceException;
import com.ssc.faw.util.GenException;

public class LinkVisits extends AbstractCdtUiService<LinkVisit> {
	private static Type mapType = new TypeToken<Map<Long, LinkVisit>>(){}.getType();
	
	static Map<Long, Object> objectMap = null;
	
	Type getMapType() {
		return 	mapType;
	}

	@Override
	Map<Long, Object> getObjectMap() {
		return LinkVisits.objectMap;
	}

	@Override
	void setObjectMap(Map<Long, Object> objectMap) {
		LinkVisits.objectMap = objectMap;
	}

	@Override
	public void loadList(LinkVisit inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		
		Collection<Object> linkVisits = objectMap.values();
		String user = getUser();
		
		List<LinkVisit> filtered = new ArrayList<LinkVisit>();
		
		for (Object item : linkVisits) {
			LinkVisit linkVisit = (LinkVisit)item;
			if (user.equals(linkVisit.getUserId())) {
				filtered.add(linkVisit);
			}
		}
		
		Collections.sort(filtered, new Comparator<LinkVisit>() {

			@Override
			public int compare(LinkVisit o1, LinkVisit o2) {
				return o2.getVisitTime().compareTo(o1.getVisitTime());
			}});
		
		int limit = Math.min(5, filtered.size());
		
		for (int i = 0; i < limit; i++) {
			outputResults(filtered.get(i));
		}
	}

	@Override
	public void addNew(LinkVisit inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		//limit size of json stored recent links
		Collection<Object> linkVisits = objectMap.values();
		String user = getUser();
		
		List<LinkVisit> filtered = new ArrayList<LinkVisit>();
		
		for (Object item : linkVisits) {
			LinkVisit linkVisit = (LinkVisit)item;
			if (user.equals(linkVisit.getUserId())) {
				filtered.add(linkVisit);
			}
		}
		
		Collections.sort(filtered, new Comparator<LinkVisit>() {

			@Override
			public int compare(LinkVisit o1, LinkVisit o2) {
				return o2.getVisitTime().compareTo(o1.getVisitTime());
			}});
		
		int size = filtered.size();
		
		for (int i = 0; i < size; i++) {
			if (i > 5) {
				Long id = filtered.get(i).getId();
				objectMap.remove(id);
			}
		}
		
		inputParams.setUserId(user);
		super.addNew(inputParams);
	}
}
