package com.ssc.cdt.data;

import java.util.concurrent.CopyOnWriteArrayList;

import com.ssc.faw.intref2.IntrefException;
import com.ssc.faw.intref2.Request;
import com.ssc.faw.intref2.Tabular;
import com.ssc.faw.intref2.TabularListener;
import com.ssc.faw.util.GenException;

public class IDF_8050006 implements Tabular
{

	private static CopyOnWriteArrayList<Object[]> LIST = new CopyOnWriteArrayList<Object[]>();
	
	static {
		LIST.add(new Object[]{null, "WWW", "WWW", "WWW", "x12345", "EST", "p12345", "p12345"});
		LIST.add(new Object[]{null, "XXX", "XXX", "XXX", "x12345", "PST", "p12345", "p12345"});
		LIST.add(new Object[]{null, "YYY", "YYY", "YYY", "x12345", "EST", "p12345", "p12345"});
		LIST.add(new Object[]{null, "ZZZ", "ZZZ", "ZZZ", "x12345", "EST", "p12345", "p12345"});
	}
	
	@Override
	public void process(Request request, TabularListener listener) throws GenException {
		try {
		Object[][] inputs = request.getInputs();
		listener.open();
		
		if (inputs == null || inputs.length == 0) {
			loadList(listener);
			return;
		}
		
		String action = (String)inputs[0][0];
		
		if (action.equals("UPDATE")) 
		{
			update(inputs);
		}
		else
		{
			loadList(listener);
		}
		
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			listener.close();
		}
		
		
	}
	
	public void update(Object[][] inputs) {
		for (Object[] row : inputs) {
			LIST.add(row);
		}
	}
	
	
	public void loadList(TabularListener listener) throws IntrefException {
		for (Object[] row : LIST) {
			listener.addRow(row);
		}
	}
}
