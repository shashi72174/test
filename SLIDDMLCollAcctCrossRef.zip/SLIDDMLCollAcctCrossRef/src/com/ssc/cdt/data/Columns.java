package com.ssc.cdt.data;

import java.lang.reflect.Type;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Map;

import com.google.gson.reflect.TypeToken;
import com.ssc.cloud.jbio.JBIOMappingException;
import com.ssc.cloud.jbio.JBIOUnderlyingDataSourceException;
import com.ssc.faw.util.GenException;

public class Columns extends AbstractCdtUiService<Column> {
	private static Type mapType = new TypeToken<Map<Long, Column>>(){}.getType();
	static Map<Long, Object> objectMap = null;
	
	Type getMapType() {
		return 	mapType;
	}

	@Override
	Map<Long, Object> getObjectMap() {
		return Columns.objectMap;
	}

	@Override
	void setObjectMap(Map<Long, Object> objectMap) {
		Columns.objectMap = objectMap;
	}

	@Override
	public void loadList(Column inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		
		String componentId = inputParams.getComponentId();
		
		if (componentId == null) {
			super.loadList(inputParams);
		} else {
			Collection<Object> columns = objectMap.values();
			
			for (Object item : columns) {
				Column col = (Column)item;
				if (componentId.equals(col.getComponentId())) {
					outputResults(col);
				}
			}
		}
	}

}
