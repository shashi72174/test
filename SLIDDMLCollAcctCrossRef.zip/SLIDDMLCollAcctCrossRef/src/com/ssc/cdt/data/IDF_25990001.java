package com.ssc.cdt.data;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

import org.apache.log4j.Logger;

import com.ssc.cloud.jbio.JBIOAbstractService;
import com.ssc.cloud.jbio.JBIOMappingException;
import com.ssc.cloud.jbio.JBIOUnderlyingDataSourceException;
import com.ssc.faw.util.GenException;

public class IDF_25990001 extends JBIOAbstractService<Fund, Fund> {
    static Logger log = Logger.getLogger(IDF_25990001.class);
    private static Random rand = new Random();
    private static ArrayList<Fund> FUNDS;
    private int initialRowCount = 10000;

    {
        FUNDS = new ArrayList<Fund>(10000);
        for (int i = 0; i < initialRowCount; i++) {
            Fund f = new Fund();
            f.setFundId(i);
            f.setFundName(getFundName(i));
            FUNDS.add(f);
        }
    }

    @Override
    public void loadList(Fund inputParams) throws GenException, JBIOMappingException,
            JBIOUnderlyingDataSourceException, SQLException {
        ArrayList<Fund> retFunds = FUNDS;
        String filter = inputParams.getFundName();
        if (filter != null && filter.trim().length() > 0) {
            log.info("Filter: " + filter);
            retFunds = new ArrayList<Fund>();
            filter = filter.toUpperCase();
            for (Fund f : FUNDS) {
                if (f.getFundName().toUpperCase().startsWith(filter)) {
                    retFunds.add(f);
                }
            }
        }
        
        int rowCount = retFunds.size();
        Integer start = inputParams.getStart() == null ? 0 : inputParams.getStart();
        Integer stop = inputParams.getStop();
		if (stop == null) {
			if (inputParams.getPagesize() != null) {
				stop = start + inputParams.getPagesize();
			} else {
				stop = rowCount;
			}
		}
        
        stop = Math.min(rowCount - 1, stop);
        
        log.info("start: " + start);
        log.info("stop: " + stop);
        boolean set = false;
        for (int i = start; i < stop; i++) {
            Fund f = retFunds.get(i);
            if (!set) {
                f.setTotalrows(rowCount);
            }
            set = true;
            mapForReturn(f);
            outputRow();
        }
    }

    private static String getFundName(int i) {

        int cnt1 = (i % 26);
        int cnt2 = Math.min(++cnt1, 25);
        int cnt3 = Math.min(++cnt2, 25);

        char char1 = (char) (cnt1 + 64);
        char char2 = (char) (cnt2 + 64);
        char char3 = (char) (cnt3 + 64);

        String fund = "" + char1 + char2 + char3 + "i" + rand.nextInt(100);

        return fund;
    }

}
