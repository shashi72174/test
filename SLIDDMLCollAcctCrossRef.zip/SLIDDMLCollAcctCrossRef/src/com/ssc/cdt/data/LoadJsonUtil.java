package com.ssc.cdt.data;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ssc.faw.util.GenConnectionPool;

public class LoadJsonUtil {
	static Logger log = Logger.getLogger(LoadJsonUtil.class);

	private static final String updateSQL = "UPDATE LINKS SET PARENTID = ? WHERE ID = ?";
	
	public static void main(String[] args) {
		initOSAFramework();
		String appcode = System.getProperty("OEC.APP", "CLOTRG00259");
		Gson gson = new Gson();
		DummyFileWriter fw = new DummyFileWriter();
		Map<Long, Link> linkMap = null;
		Map<Long, Long> idMap = new HashMap<Long, Long>();
		Connection conn = null;
		
	    try {
			String json = fw.getJSONString("Link.json");
			linkMap = gson.fromJson(json, new TypeToken<Map<Long, Link>>(){}.getType());
			conn = GenConnectionPool.getConnection("CDTUI_DS");
			
			// insert links
			for (Link link : linkMap.values()) {
				if (link.getAppcode() == null) {
					link.setAppcode(appcode);
				}
				if (link.getMobile() == null) {
					link.setMobile(0);
				}
				if (link.getCreatedAt() == null) {
					link.setCreatedAt(new Date());
				}
				if (link.getCreatedBy() == null || "".equals(link.getCreatedBy())) {
					link.setCreatedBy("JSONIMPORT");
				}
				if (link.getLastUpdated() == null) {
					link.setLastUpdated(new Date());
				}
				if (link.getLastUpdatedBy() == null || "".equals(link.getLastUpdatedBy())) {
					link.setLastUpdatedBy("JSONIMPORT");
				}
				Long id = insertLink(link, conn);
				idMap.put(link.getId(), id);
				log.info("added link " + link.getLabel() + " (" + id + ")");
			}
			
			// update parent id references
			for (Link link : linkMap.values()) {
				Long parentId = link.getParentId();
				if (parentId != null) {
					Long newParentId = idMap.get(parentId);
					Long newId = idMap.get(link.getId());
					updateLink(newId, newParentId, conn);
					log.info("updated link parent of " + link.getLabel() + " to " + linkMap.get(parentId).getLabel());
				}
			}
			
		} catch (Exception e) {
			log.error("error loading data", e);
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {}
			System.exit(1);
		}

	}
	
	static void updateLink(Long id, Long newParentId, Connection conn) throws SQLException {
		PreparedStatement ps = conn.prepareStatement(updateSQL);
		ps.setLong(1, newParentId);
		ps.setLong(2, id);
		ps.executeUpdate();
		ps.close();
	}
	
	static Long insertLink(Link link, Connection conn) throws SQLException {
		CallableStatement cs = conn.prepareCall(LinksDB.ADDNEW);
		cs.registerOutParameter(1, Types.NUMERIC);
		cs.setObject(2, link.getParentId());
		cs.setDate(3, new java.sql.Date(link.getLastUpdated().getTime()));
		cs.setDate(4, new java.sql.Date(link.getLastUpdated().getTime()));
		cs.setString(5, link.getLastUpdatedBy());
		cs.setString(6, link.getLastUpdatedBy());
		cs.setString(7, link.getAppcode());
		cs.setInt(8, 1); //active
		cs.setString(9, link.getLabel());
		cs.setString(10, link.getType());
		cs.setString(11, link.getLink());
		cs.setString(12, link.getTarget());
		cs.setString(13, link.getDescription());
		cs.setString(14, link.getClassname());
		cs.setString(15, link.getTag());
		cs.setString(16, link.getIcon());
		cs.setObject(17, link.getMobile());
		cs.setObject(18, link.getOrder());
		
		cs.execute();
		Long id = cs.getLong(1);
		
		return id;
	}

	private static void initOSAFramework() {
		try {
			if (System.getProperty("PropertyXMLFile") == null) {
				System.setProperty("PropertyXMLFile",
						"war/WEB-INF/cfg/settings.xml");
			}
			Class.forName("com.ssc.faw.common.PropertyManager");

			Properties systemProperties = System.getProperties();
			@SuppressWarnings("rawtypes")
			Enumeration sysPropEnum = systemProperties.propertyNames();
			while (sysPropEnum.hasMoreElements()) {

				String tempSysPropertyName = (String) sysPropEnum.nextElement();
				String tempSysPropertyValue = systemProperties
						.getProperty(tempSysPropertyName);
				if (tempSysPropertyValue.indexOf("${CONTEXT_ROOT}") != -1) {
					String newTempPropertyValue = tempSysPropertyValue
							.replaceAll("\\$\\{CONTEXT_ROOT\\}", "./war");
					System.setProperty(tempSysPropertyName,
							newTempPropertyValue);
				}
			}

			Class.forName("com.ssc.faw.common.LogManager");

		} catch (ClassNotFoundException e) {
			log.error("Error initializing framework", e);
		}
	}

	
}
