package com.ssc.cdt.data;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.ssc.cloud.jbio.JBIOAbstractService;
import com.ssc.cloud.jbio.JBIOMappingException;
import com.ssc.cloud.jbio.JBIOUnderlyingDataSourceException;
import com.ssc.faw.util.GenException;

public abstract class AbstractCdtUiService<T extends HasId> extends JBIOAbstractService<T, T> {
	static Logger log = Logger.getLogger(AbstractCdtUiService.class);

	final static String appcode = System.getProperty("OEC.APP", "CDT");
	final static Integer ACTIVE = 1;
	
	protected DummyFileWriter fileWriter = new DummyFileWriter();
	protected Gson gson = new Gson();
	protected String className;
	protected String fileName;

	@SuppressWarnings("unchecked")
	public AbstractCdtUiService() {
		super();
		Class<T> typeClass = (Class<T>) ((ParameterizedType)getClass()
				.getGenericSuperclass()).getActualTypeArguments()[0];
		className = typeClass.getSimpleName();
		log.debug("Generic class name: " + className);
		fileName = className + ".json";
		
		Map<Long, Object> objectMap = getObjectMap();
		if (objectMap == null) {
			initData();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void loadList(T inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		Map<Long, Object> objectMap = getObjectMap();
		Collection<Object> items = (Collection<Object>)objectMap.values();

		for (Object obj : items) {
			T item = (T) obj;
			if (ACTIVE.equals(item.getActive())) {
				outputResults(item);
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void update(T inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		Map<Long, Object> objectMap = getObjectMap();
		
		T original = (T) objectMap.get(inputParams.getId());
		inputParams.setCreatedAt(original.getCreatedAt());
		inputParams.setCreatedBy(original.getCreatedBy());
		inputParams.setLastUpdated(new Date());
		inputParams.setLastUpdatedBy(getUser());
		inputParams.setAppcode(appcode);
		if (inputParams.getActive() == null) {
			inputParams.setActive(ACTIVE);
		}
		objectMap.put(inputParams.getId(), inputParams);
		writeMap();
		outputResults(inputParams);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void addNew(T inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		Map<Long, Object> objectMap = getObjectMap();
		List<T> addedItems = listParams();
		
		for (T item : addedItems) {
			item.setId(getNextId());
			Date dt = new Date();
			item.setCreatedAt(dt);
			item.setCreatedBy(getUser());
			item.setLastUpdated(dt);
			item.setLastUpdatedBy(getUser());
			item.setAppcode(appcode);
			item.setActive(ACTIVE);
			objectMap.put(item.getId(), item);
			outputResults(item);
		}
		
		writeMap();
	}

	@SuppressWarnings("unchecked")
	@Override
	public void delete(T inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		Map<Long, Object> objectMap = getObjectMap();

		List<T> deletedItems = listParams();
		for (T item : deletedItems) {
			T removed = (T)objectMap.get(item.getId());
			removed.setActive(0);
			outputResults(item);
		}
		writeMap();
	}

	protected Long getNextId() {
		Long id = 1L;
		Map<Long, Object> objectMap = getObjectMap();
		if (objectMap == null || objectMap.isEmpty()) {
			return id;
		}

		for (Long x : objectMap.keySet()) {
			id = Math.max(id, x);
		}
		return id + 1;
	}
	
	protected void writeMap() {
		Map<Long, Object> objectMap = getObjectMap();
		String json = gson.toJson(objectMap, getMapType());
		fileWriter.writeJSONString(fileName, json);
	}
	
	@SuppressWarnings("unchecked")
	void initData() {
		Object objectMap = new HashMap<Long, Object>();
		if (fileWriter.fileExists(fileName)) {
			String json = fileWriter.getJSONString(fileName);
			objectMap = gson.fromJson(json, getMapType());
		} 
		setObjectMap((Map<Long, Object>)objectMap);
	}
	
	protected boolean hasConnection() {
		try {
			return getConnection() != null;
		} catch (Exception e) {
			return false;
		}
	}
	
	abstract Type getMapType(); 
	abstract Map<Long, Object> getObjectMap();
	abstract void setObjectMap(Map<Long, Object> objectMap);
	
}
