package com.ssc.cdt.data;

import com.ssc.cloud.jbio.Col;
import com.ssc.cloud.jbio.IdfColType;
import com.ssc.cloud.jbio.IdfInOut;
import com.ssc.cloud.jbio.RSColType;

@IdfInOut(
{
	@Col(beanProp="componentId", idfColName="componentId", idfColType=IdfColType.STRING, rsColName="componentId", rsColType=RSColType.STRING),
	@Col(beanProp="tag", idfColName="tag", idfColType=IdfColType.STRING, rsColName="tag", rsColType=RSColType.STRING),
	@Col(beanProp="dataKey", idfColName="dataKey", idfColType=IdfColType.STRING, rsColName="dataKey", rsColType=RSColType.STRING),
	@Col(beanProp="userId", idfColName="userId", idfColType=IdfColType.STRING, rsColName="userId", rsColType=RSColType.STRING),
	@Col(beanProp="width", idfColName="width", idfColType=IdfColType.STRING, rsColName="width", rsColType=RSColType.STRING),
	@Col(beanProp="index", idfColName="index", idfColType=IdfColType.INT, rsColName="index", rsColType=RSColType.INT),
	@Col(beanProp="hidden", idfColName="hidden", idfColType=IdfColType.INT, rsColName="hidden", rsColType=RSColType.INT),
	@Col(beanProp="fixed", idfColName="fixed", idfColType=IdfColType.INT, rsColName="fixed", rsColType=RSColType.INT),
	@Col(beanProp="defaultFavorite", idfColName="defaultFavorite", idfColType=IdfColType.INT, rsColName="defaultFavorite", rsColType=RSColType.INT)
}
)

public class ColumnFavorite extends AbstractCdtUiBean
{
	private String componentId;
	private String tag;
	private String dataKey;
	private String userId;
	private String width;
	private Integer index;
	private Integer hidden;
	private Integer fixed;
	private Integer defaultFavorite;
	
	public String getComponentId() {
		return componentId;
	}
	public void setComponentId(String componentId) {
		this.componentId = componentId;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getDataKey() {
		return dataKey;
	}
	public void setDataKey(String dataKey) {
		this.dataKey = dataKey;
	}
	public String getWidth() {
		return width;
	}
	public void setWidth(String width) {
		this.width = width;
	}
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
	public Integer getHidden() {
		return hidden;
	}
	public void setHidden(Integer hidden) {
		this.hidden = hidden;
	}
	public Integer getFixed() {
		return fixed;
	}
	public void setFixed(Integer fixed) {
		this.fixed = fixed;
	}
	public Integer getDefaultFavorite() {
		return defaultFavorite;
	}
	public void setDefaultFavorite(Integer defaultFavorite) {
		this.defaultFavorite = defaultFavorite;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
    
}
