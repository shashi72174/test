package com.ssc.cdt.data;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;

import oracle.jdbc.OracleTypes;

import org.apache.log4j.Logger;

import com.ssc.cloud.jbio.JBIOAbstractService;
import com.ssc.cloud.jbio.JBIOMappingException;
import com.ssc.cloud.jbio.JBIOUnderlyingDataSourceException;
import com.ssc.faw.util.GenException;

public class LinkVisitsDB extends JBIOAbstractService<LinkVisit, LinkVisit> {
	static Logger log = Logger.getLogger(LinkVisitsDB.class);

	final static String appcode = System.getProperty("OEC.APP", "CDT");

	public static final String LOADLIST = "{call LINKVISIT_PKG.LOADLIST_LINKVISIT(?, ?)}";
	public static final String ADDNEW = "{call LINKVISIT_PKG.ADD_LINKVISIT(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";
	
	@Override
	public void addNew(LinkVisit inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		CallableStatement cs = null;
		java.sql.Date now = new java.sql.Date(new Date().getTime());
		String user = getUser();
		try {
			cs = prepareCall(ADDNEW);
			cs.registerOutParameter("p_ID", Types.NUMERIC);
			cs.setObject("p_PARENTID", inputParams.getParentId());
			cs.setDate("p_CREATEDAT", now);
			cs.setDate("p_LASTUPDATED", now);
			cs.setString("p_LASTUPDATEDBY", user);
			cs.setString("p_CREATEDBY", user);
			cs.setString("p_APPCODE", appcode);
			cs.setInt("p_ACTIVE", 1); //active
			cs.setLong("p_LINKID", inputParams.getLinkId());
			cs.setString("p_USERID", user);
			cs.setObject("p_VISITTIME", now);
			cs.execute();
			inputParams.setId(cs.getLong("p_ID"));
			outputResults(inputParams);
		} catch (Exception e) {
			log.error("Exception adding LinkVisit", e);
			setErrorMsg("Error adding LinkVisit.");
			outputRow();
		} finally {
			try {
				cs.close();
			} catch (Exception e) {}
		}
	}

	@Override
	public void loadList(LinkVisit inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		
		ResultSet rs = null;
		CallableStatement cs = null;
		try {
			cs = prepareCall(LOADLIST);
			cs.registerOutParameter("LINKVISIT_CUR", OracleTypes.CURSOR);
			cs.setString("p_USERID", getUser());
			cs.execute();
			rs = (ResultSet) cs.getObject("LINKVISIT_CUR");
			if (rs.next()) {
				outputResults(rs);
			}
		} catch (Exception e) {
			log.error("Exception loading LinkVisits", e);
			setErrorMsg("Error loading LinkVisits.");
			outputRow();
		} finally {
			try {
				cs.close();
				rs.close();
			} catch (Exception e) {}
		}
	}
}
