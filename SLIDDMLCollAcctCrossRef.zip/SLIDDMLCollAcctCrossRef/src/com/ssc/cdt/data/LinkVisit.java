package com.ssc.cdt.data;

import java.util.Date;

import com.ssc.cloud.jbio.Col;
import com.ssc.cloud.jbio.IdfColType;
import com.ssc.cloud.jbio.IdfInOut;
import com.ssc.cloud.jbio.RSColType;

@IdfInOut(
{
    @Col(beanProp="linkId", idfColName="linkId", idfColType=IdfColType.LONG, rsColName="LINKID", rsColType=RSColType.LONG),
    @Col(beanProp="userId", idfColName="userId", idfColType=IdfColType.STRING, rsColName="USERID", rsColType=RSColType.STRING),
    @Col(beanProp="visitTime", idfColName="visitTime", idfColType=IdfColType.DATETIME, rsColName="VISITTIME", rsColType=RSColType.DATE)
}
)

public class LinkVisit extends AbstractCdtUiBean
{
    private Long linkId;
    private java.lang.String userId;
    private Date visitTime;
    
	public Long getLinkId() {
		return linkId;
	}
	public void setLinkId(Long linkId) {
		this.linkId = linkId;
	}
	public java.lang.String getUserId() {
		return userId;
	}
	public void setUserId(java.lang.String userId) {
		this.userId = userId;
	}
	public Date getVisitTime() {
		return visitTime;
	}
	public void setVisitTime(Date visitTime) {
		this.visitTime = visitTime;
	}
    
}
