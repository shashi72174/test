package com.ssc.cdt.data;

import java.lang.reflect.Type;
import java.util.Map;

import org.apache.log4j.Logger;

import com.google.gson.reflect.TypeToken;

public class FundClasses extends AbstractCdtUiService<FundClass> {
	private static Type mapType = new TypeToken<Map<Long, FundClass>>(){}.getType();
	static Map<Long, Object> objectMap = null;
	static Logger log = Logger.getLogger(FundClasses.class);

	Type getMapType() {
		return 	mapType;
	}

	@Override
	Map<Long, Object> getObjectMap() {
		return FundClasses.objectMap;
	}

	@Override
	void setObjectMap(Map<Long, Object> objectMap) {
		FundClasses.objectMap = objectMap;
	}
}
