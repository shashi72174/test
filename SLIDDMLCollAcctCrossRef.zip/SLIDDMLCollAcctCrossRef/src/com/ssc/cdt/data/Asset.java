package com.ssc.cdt.data;

import java.util.ArrayList;
import java.util.List;

import com.ssc.cloud.jbio.Col;
import com.ssc.cloud.jbio.IdfColType;
import com.ssc.cloud.jbio.IdfInOut;

@IdfInOut(
{
    @Col(beanProp="units", idfColName=Asset.UNITS, idfColType=IdfColType.DOUBLE),
    @Col(beanProp="price", idfColName=Asset.PRICE, idfColType=IdfColType.DOUBLE),
    @Col(beanProp="asset", idfColName=Asset.ASSET, idfColType=IdfColType.STRING),
    @Col(beanProp="name", idfColName=Asset.NAME, idfColType=IdfColType.STRING),
    @Col(beanProp="manager", idfColName=Asset.MANAGER, idfColType=IdfColType.STRING),
    @Col(beanProp="id", idfColName=Asset.ID, idfColType=IdfColType.LONG),
    @Col(beanProp="cost", idfColName=Asset.COST, idfColType=IdfColType.DOUBLE),
    @Col(beanProp="fund", idfColName=Asset.FUND, idfColType=IdfColType.STRING),
    @Col(beanProp="percentage", idfColName=Asset.PERCENTAGE, idfColType=IdfColType.DOUBLE),
    @Col(beanProp="parentId", idfColName=Asset.PARENT_ID, idfColType=IdfColType.LONG),
    @Col(beanProp="date", idfColName=Asset.DATE, idfColType=IdfColType.DATE),
    @Col(beanProp="dateTime", idfColName=Asset.DATE_TIME, idfColType=IdfColType.DATETIME),
    @Col(beanProp="hasChildren", idfColName=Asset.HAS_CHILDREN, idfColType=IdfColType.INT),
}
)

public class Asset
{
    public static final String UNITS = "UNITS";
    public static final String PRICE = "PRICE";
    public static final String ASSET = "ASSET";
    public static final String NAME = "NAME";
    public static final String MANAGER = "MANAGER";
    public static final String ID = "ID";
    public static final String COST = "COST";
    public static final String FUND = "FUND";
    public static final String PERCENTAGE = "PERCENTAGE";
    public static final String PARENT_ID = "PARENT_ID";
    public static final String DATE = "DATE";
    public static final String DATE_TIME = "DATE_TIME";
    public static final String HAS_CHILDREN = "HAS_CHILDREN";

    private java.lang.Double units;
    private java.lang.Double price;
    private java.lang.String asset;
    private java.lang.String name;
    private java.lang.String manager;
    private java.lang.Long id;
    private java.lang.Double cost;
    private java.lang.String fund;
    private java.lang.Double percentage;
    private java.lang.Long parentId;
    private java.util.Date date;
    private java.util.Date dateTime;
    private java.lang.Integer hasChildren;
    
    private List<Asset> children;

    public java.lang.Double getUnits()
    {
        return units;
    }

    public void setUnits(java.lang.Double units)
    {
        this.units = units;
    }

    public java.lang.Double getPrice()
    {
        return price;
    }

    public void setPrice(java.lang.Double price)
    {
        this.price = price;
    }

    public java.lang.String getAsset()
    {
        return asset;
    }

    public void setAsset(java.lang.String asset)
    {
        this.asset = asset;
    }

    public java.lang.String getName()
    {
        return name;
    }

    public void setName(java.lang.String name)
    {
        this.name = name;
    }

    public java.lang.String getManager()
    {
        return manager;
    }

    public void setManager(java.lang.String manager)
    {
        this.manager = manager;
    }

    public java.lang.Long getId()
    {
        return id;
    }

    public void setId(java.lang.Long id)
    {
        this.id = id;
    }

    public java.lang.Double getCost()
    {
        return cost;
    }

    public void setCost(java.lang.Double cost)
    {
        this.cost = cost;
    }

    public java.lang.String getFund()
    {
        return fund;
    }

    public void setFund(java.lang.String fund)
    {
        this.fund = fund;
    }

    public java.lang.Double getPercentage()
    {
        return percentage;
    }

    public void setPercentage(java.lang.Double percentage)
    {
        this.percentage = percentage;
    }

    public java.lang.Long getParentId()
    {
        return parentId;
    }

    public void setParentId(java.lang.Long parentId)
    {
        this.parentId = parentId;
    }

    public void addChild(Asset child) {
    	if (children == null) {
    		children = new ArrayList<Asset>();
    	}
    	child.setParentId(this.getId());
    	if (this.getCost() == null) {
    		this.setCost(0.0);
    	}
    	this.setCost(this.getCost() + child.getCost());
    	children.add(child);
    }
    
    public List<Asset> getChildren() {
    	return children;
    }

	public java.util.Date getDate() {
		return date;
	}

	public void setDate(java.util.Date date) {
		this.date = date;
	}

	public java.util.Date getDateTime() {
		return dateTime;
	}

	public void setDateTime(java.util.Date dateTime) {
		this.dateTime = dateTime;
	}

	public java.lang.Integer getHasChildren() {
		return hasChildren;
	}

	public void setHasChildren(java.lang.Integer hasChildren) {
		this.hasChildren = hasChildren;
	}
    
}
