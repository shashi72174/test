package com.ssc.cdt.data;

import com.ssc.cloud.jbio.Col;
import com.ssc.cloud.jbio.IdfColType;
import com.ssc.cloud.jbio.IdfInOut;
import com.ssc.cloud.jbio.RSColType;

@IdfInOut(
{
	@Col(beanProp="componentId", idfColName="componentId", idfColType=IdfColType.STRING, rsColName="componentId", rsColType=RSColType.STRING),
	@Col(beanProp="tag", idfColName="tag", idfColType=IdfColType.STRING, rsColName="tag", rsColType=RSColType.STRING),	
	@Col(beanProp="columns", idfColName="columns", idfColType=IdfColType.STRING, rsColName="columns", rsColType=RSColType.STRING),
	@Col(beanProp="conjunction", idfColName="conjunction", idfColType=IdfColType.STRING, rsColName="conjunction", rsColType=RSColType.STRING),
	@Col(beanProp="filter", idfColName="filter", idfColType=IdfColType.STRING, rsColName="filter", rsColType=RSColType.STRING),
	@Col(beanProp="option", idfColName="option", idfColType=IdfColType.INT, rsColName="option", rsColType=RSColType.INT),
	@Col(beanProp="pageSize", idfColName="pageSize", idfColType=IdfColType.INT, rsColName="pageSize", rsColType=RSColType.INT),
	@Col(beanProp="rowCount", idfColName="rowCount", idfColType=IdfColType.INT, rsColName="rowCount", rsColType=RSColType.INT),
	@Col(beanProp="showOptions", idfColName="showOptions", idfColType=IdfColType.INT, rsColName="showOptions", rsColType=RSColType.INT),
	@Col(beanProp="sort", idfColName="sort", idfColType=IdfColType.STRING, rsColName="sort", rsColType=RSColType.STRING),
	@Col(beanProp="defaultFavorite", idfColName="defaultFavorite", idfColType=IdfColType.INT, rsColName="defaultFavorite", rsColType=RSColType.INT),
	@Col(beanProp="userId", idfColName="userId", idfColType=IdfColType.STRING, rsColName="userId", rsColType=RSColType.STRING)
}
)

public class GridFavorite extends AbstractCdtUiBean
{
	private String componentId;
	private String tag;
	private String columns;
	private String conjunction;
	private String filter;
	private Integer option;
	private Integer pageSize;
	private Integer rowCount;
	private Integer showOptions;
	private String sort;
	private Integer defaultFavorite;
	private String userId;
	
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getComponentId() {
		return componentId;
	}
	public void setComponentId(String componentId) {
		this.componentId = componentId;
	}
	public String getColumns() {
		return columns;
	}
	public void setColumns(String columns) {
		this.columns = columns;
	}
	public String getConjunction() {
		return conjunction;
	}
	public void setConjunction(String conjunction) {
		this.conjunction = conjunction;
	}
	public String getFilter() {
		return filter;
	}
	public void setFilter(String filter) {
		this.filter = filter;
	}
	public Integer getOption() {
		return option;
	}
	public void setOption(Integer option) {
		this.option = option;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public Integer getRowCount() {
		return rowCount;
	}
	public void setRowCount(Integer rowCount) {
		this.rowCount = rowCount;
	}
	public Integer getShowOptions() {
		return showOptions;
	}
	public void setShowOptions(Integer showOptions) {
		this.showOptions = showOptions;
	}
	public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public Integer getDefaultFavorite() {
		return defaultFavorite;
	}
	public void setDefaultFavorite(Integer defaultFavorite) {
		this.defaultFavorite = defaultFavorite;
	}
	

	
    
}
