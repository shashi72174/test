package com.ssc.cdt.data;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import oracle.jdbc.OracleTypes;

import com.ssc.cloud.jbio.JBIOAbstractService;
import com.ssc.cloud.jbio.JBIOMappingException;
import com.ssc.cloud.jbio.JBIOUnderlyingDataSourceException;
import com.ssc.faw.util.GenException;

public class LinksDB extends JBIOAbstractService<Link, Link> {
	static Logger log = Logger.getLogger(LinksDB.class);

	final static String appcode = System.getProperty("OEC.APP", "CDT");

	public static final String LOAD = "{call LINK_PKG.LOAD_LINK(?, ?)}";
	public static final String LOADLIST = "{call LINK_PKG.LOADLIST_LINK(?, ?)}";
	public static final String ADDNEW = "{call LINK_PKG.ADD_LINK(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";
	public static final String UPDATE = "{call LINK_PKG.UPDATE_LINK(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";
	public static final String DELETE = "{call LINK_PKG.DELETE_LINK(?)}";

	@Override
	public void load(Link inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		
		ResultSet rs = null;
		CallableStatement cs = null;
		try {
			cs = prepareCall(LOAD);
			cs.registerOutParameter("LINK_CUR", OracleTypes.CURSOR);
			cs.setLong("p_ID", inputParams.getId());
			cs.execute();
			rs = (ResultSet) cs.getObject("LINK_CUR");
			if (rs.next()) {
				outputResults(rs);
			}
		} catch (Exception e) {
			log.error("Exception loading Link", e);
			setErrorMsg("Error loading Link.");
			outputRow();
		} finally {
			try {
				cs.close();
				rs.close();
			} catch (Exception e) {}
		}
	}

	@Override
	public void update(Link inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		CallableStatement cs = null;
		Long now = new Date().getTime();
		String user = getUser();
		Integer mobile = inputParams.getMobile();
		if (mobile == null) {
			mobile = 0;
		}
		try {
			cs = prepareCall(UPDATE);
			cs.setLong("p_ID", inputParams.getId());
			cs.setObject("p_PARENTID", inputParams.getParentId());
			cs.setDate("p_LASTUPDATED", new java.sql.Date(now));
			cs.setString("p_LASTUPDATEDBY", user);
			cs.setString("p_APPCODE", appcode);
			cs.setInt("p_ACTIVE", 1); //active
			cs.setString("p_LABEL", inputParams.getLabel());
			cs.setString("p_TYPE", inputParams.getType());
			cs.setString("p_LINK", inputParams.getLink());
			cs.setString("p_TARGET", inputParams.getTarget());
			cs.setString("p_DESCRIPTION", inputParams.getDescription());
			cs.setString("p_CLASSNAME", inputParams.getClassname());
			cs.setString("p_TAG", inputParams.getTag());
			cs.setString("p_ICON", inputParams.getIcon());
			cs.setObject("p_MOBILE", mobile);
			cs.setObject("p_ORDER", inputParams.getOrder());
			cs.execute();
			outputResults(inputParams);
		} catch (Exception e) {
			log.error("Exception updating Link", e);
			setErrorMsg("Error updating Link.");
			outputRow();
		} finally {
			try {
				cs.close();
			} catch (Exception e) {}
		}
	}

	@Override
	public void addNew(Link inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		CallableStatement cs = null;
		Long now = new Date().getTime();
		String user = getUser();
		Integer mobile = inputParams.getMobile();
		if (mobile == null) {
			mobile = 0;
		}
		try {
			cs = prepareCall(ADDNEW);
			cs.registerOutParameter("p_ID", Types.NUMERIC);
			cs.setObject("p_PARENTID", inputParams.getParentId());
			cs.setDate("p_CREATEDAT", new java.sql.Date(now));
			cs.setDate("p_LASTUPDATED", new java.sql.Date(now));
			cs.setString("p_LASTUPDATEDBY", user);
			cs.setString("p_CREATEDBY", user);
			cs.setString("p_APPCODE", appcode);
			cs.setInt("p_ACTIVE", 1); //active
			cs.setString("p_LABEL", inputParams.getLabel());
			cs.setString("p_TYPE", inputParams.getType());
			cs.setString("p_LINK", inputParams.getLink());
			cs.setString("p_TARGET", inputParams.getTarget());
			cs.setString("p_DESCRIPTION", inputParams.getDescription());
			cs.setString("p_CLASSNAME", inputParams.getClassname());
			cs.setString("p_TAG", inputParams.getTag());
			cs.setString("p_ICON", inputParams.getIcon());
			cs.setObject("p_MOBILE", mobile);
			cs.setObject("p_ORDER", inputParams.getOrder());
			cs.execute();
			inputParams.setId(cs.getLong("p_ID"));
			outputResults(inputParams);
		} catch (Exception e) {
			log.error("Exception adding Link", e);
			setErrorMsg("Error adding Link.");
			outputRow();
		} finally {
			try {
				cs.close();
			} catch (Exception e) {}
		}
	}

	@Override
	public void delete(Link inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		CallableStatement cs = null;
		
		try {
			cs = prepareCall(DELETE);
			List<Link> params = listParams();
			for (Link link : params) {
				cs.setLong("p_ID", link.getId());
				cs.execute();
				link.setActive(0);
				outputResults(link);
			}
		} catch (Exception e) {
			log.error("Exception deleting Links", e);
			setErrorMsg("Error deleting Links.");
			outputRow();
		} finally {
			try {
				cs.close();
			} catch (Exception e) {}
		}
	}

	@Override
	public void loadList(Link inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		
		ResultSet rs = null;
		CallableStatement cs = null;
		try {
			cs = prepareCall(LOADLIST);
			cs.registerOutParameter("LINK_CUR", OracleTypes.CURSOR);
			cs.setString("p_appcode", appcode);
			cs.execute();
			rs = (ResultSet) cs.getObject("LINK_CUR");
			if (rs.next()) {
				outputResults(rs);
			}
		} catch (Exception e) {
			log.error("Exception loading Links", e);
			setErrorMsg("Error loading Links.");
			outputRow();
		} finally {
			try {
				cs.close();
				rs.close();
			} catch (Exception e) {}
		}
	}
}
