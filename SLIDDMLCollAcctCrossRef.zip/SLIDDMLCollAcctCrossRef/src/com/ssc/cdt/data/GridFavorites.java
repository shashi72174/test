package com.ssc.cdt.data;

import java.lang.reflect.Type;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.google.gson.reflect.TypeToken;
import com.ssc.cloud.jbio.JBIOMappingException;
import com.ssc.cloud.jbio.JBIOUnderlyingDataSourceException;
import com.ssc.faw.util.GenException;

public class GridFavorites extends AbstractCdtUiService<GridFavorite> {
	private static Type mapType = new TypeToken<Map<Long, GridFavorite>>(){}.getType();
	static Map<Long, Object> objectMap = null;
	
	Type getMapType() {
		return 	mapType;
	}

	@Override
	Map<Long, Object> getObjectMap() {
		return GridFavorites.objectMap;
	}

	@Override
	void setObjectMap(Map<Long, Object> objectMap) {
		GridFavorites.objectMap = objectMap;
	}

	@Override
	public void loadList(GridFavorite inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		
		String componentId = inputParams.getComponentId();
		String user = getUser();
		
		if (componentId == null) {
			super.loadList(inputParams);
		} else {
			Collection<Object> GridFavorites = objectMap.values();
			
			for (Object item : GridFavorites) {
				GridFavorite col = (GridFavorite)item;
				if (componentId.equals(col.getComponentId()) && user.equals(col.getUserId())) {
					outputResults(col);
				}
			}
		}
	}

	@Override
	public void update(GridFavorite inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		Long Id = inputParams.getId();
		String user = getUser();
		String componentId = inputParams.getComponentId();
		
		Collection<Object> GridFavorites = objectMap.values();
		
		for (Object item : GridFavorites) {
			GridFavorite col = (GridFavorite)item;
			if (componentId.equals(col.getComponentId()) && user.equals(col.getUserId())) {
				if(Id.equals(col.getId())) {
					col.setDefaultFavorite(1);
				} else {
					col.setDefaultFavorite(0);
				}
			}
		}		
		
		writeMap();
	}

	@Override
	public void addNew(GridFavorite inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		String user = getUser();
		Map<Long, Object> objectMap = getObjectMap();
		List<GridFavorite> addedItems = listParams();
		Long Id = null;
		
		for (GridFavorite item : addedItems) {
			item.setId(getNextId());
			Date dt = new Date();
			item.setCreatedAt(dt);
			item.setCreatedBy(getUser());
			item.setLastUpdated(dt);
			item.setLastUpdatedBy(getUser());
			item.setAppcode(appcode);
			item.setActive(ACTIVE);
			item.setUserId(user);
			Id = item.getId();
			objectMap.put(item.getId(), item);
			outputResults(item);
		}
		
		writeMap();
		
		Integer isFavorite = inputParams.getDefaultFavorite();
		
		if(isFavorite == 1) {
			String componentId = inputParams.getComponentId();
			
			Collection<Object> GridFavorites = objectMap.values();
			
			for (Object item : GridFavorites) {
				GridFavorite col = (GridFavorite)item;
				if (componentId.equals(col.getComponentId()) && user.equals(col.getUserId())) {
					if(Id.equals(col.getId())) {
						col.setDefaultFavorite(1);
					} else {
						col.setDefaultFavorite(0);
					}
				}
			}
		}
				
		writeMap();
		

	}

	@Override
	public void delete(GridFavorite inputParams) throws GenException,
			JBIOMappingException, JBIOUnderlyingDataSourceException,
			SQLException {
		Map<Long, Object> objectMap = getObjectMap();

		List<GridFavorite> deletedItems = listParams();
		for (GridFavorite item : deletedItems) {
			objectMap.remove(item.getId());
			outputResults(item);
		}
		writeMap();
	}
	
	

}
