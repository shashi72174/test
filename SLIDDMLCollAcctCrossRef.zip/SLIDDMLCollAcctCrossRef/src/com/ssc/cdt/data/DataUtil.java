package com.ssc.cdt.data;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;

public class DataUtil {
    private static Logger log = Logger.getLogger(DataUtil.class);
	private HashMap<String, Integer> currentPrice = new HashMap<String, Integer>();
	private HashMap<String, Integer> increment = new HashMap<String, Integer>();
	private HashMap<String, String> managers = new HashMap<String, String>();
	private HashMap<String, HashMap<String, Integer>> fundSymbols= new HashMap<String, HashMap<String, Integer>>();

	public DataUtil() {
		for (int i = 0; i < SYMBOLS.length; i++ ) {
			Random rand = new Random();
			currentPrice.put(SYMBOLS[i], rand.nextInt(200));
			increment.put(SYMBOLS[i], DELTAS[rand.nextInt(DELTAS.length)]);
		}
		
		for (int i = 0; i < FUNDS.length; i++) {
			managers.put(FUNDS[i], MANAGERS[i % 5]);
			HashMap<String, Integer> quantityMap = new HashMap<String, Integer>();
			List<String> symbols = getSymbols();
			for (String symbol : symbols) {
				Random rand = new Random();
				quantityMap.put(symbol, rand.nextInt(500));
			}
			fundSymbols.put(FUNDS[i], quantityMap);
		}
	}
	
	public int getQuantity() {
		return new Random().nextInt(200);
	}
	
	public String getManager(String fund) {
		return managers.get(fund);
	}

	public HashMap<String, Integer> getSymbols(String fund) {
		return fundSymbols.get(fund);
	}
	
	private List<String> getSymbols() {
		int seed = new Random().nextInt(20) + 5;
		List<String> list = new ArrayList<String>();

		for (int i = 0; i < SYMBOLS.length; i++) {
//			if (i % seed == 0) {
				list.add(SYMBOLS[i]);
//			}
		}
		return list;
	}

	public List<Date> getDates(int months) {
		Calendar cal = Calendar.getInstance();
		List<Date> list = new ArrayList<Date>();

		while(months > 0) {
			cal.add(Calendar.MONTH, -1);
			cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
			list.add(cal.getTime());
			months--;
		}
		
		return list;
	}
	
	public void simulateActivity() {
		for (String symbol : SYMBOLS) {
			int price = currentPrice.get(symbol) + DELTAS[new Random().nextInt(DELTAS.length)];
			price = Math.max(0, price);
			currentPrice.put(symbol, price);
		}
		
		for (String fund : FUNDS) {
			HashMap<String, Integer> qMap = fundSymbols.get(fund);
			for (String symbol : qMap.keySet()) {
				int qty = Math.max(0, qMap.get(symbol) + DELTAS[new Random().nextInt(DELTAS.length)]);
				qMap.put(symbol, qty);
			}
		}
	}
	
	public int getCurrentPrice(String symbol) {
		return currentPrice.get(symbol);
	}
	
	
	public static int[] DELTAS = new int[] {0, 0, 0, 0, 0, -3, -3, -4, -1, -1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 6};
	
	public static String[] MANAGERS = new String[] { "p234593", "p983764",
			"p098384", "p339229", "p887023" };

	public static String[] FUNDS = new String[] { "F123A", "F456A", "FAA43", 
			"F98AA", "R987S", "R983F", "R8833", "R9999", "D9876", "D5568"};

	public static String[] SYMBOLS = new String[] { "AACC", "EXLP" };
//	, "AAON", "AAPL",
//			"AATI", "AAWW", "AAXJ", "ABAT", "ABAX", "ABBC", "ABCB", "ABCO",
//			"ABFS", "ABMD", "ACAD", "ACAS", "ACAT", "ACET", "ACGL", "ACHN",
//			"AMAC", "AMAG", "AMAP", "AMAT", "AMCC", "AMCF", "AMCN", "AMCXV",
//			"AMED", "AMGN", "AMKR", "AMLN", "AMNB", "AMPE", "AMRI", "AMRN",
//			"AMRS", "AMSC", "AMSF", "AMSG", "AMSWA", "AMTD", "AMWD", "AMZN",
//			"ANAC", "ANAD", "ANAT", "ANDE", "ANDS", "ANEN", "ANSS", "ANTH",
//			"AONE", "AOSL", "APAC", "APEI", "APKT", "APOG", "APOL", "APRI",
//			"APWR", "ARAY", "ARBA", "ARCC", "ARDNA", "AREX", "ARGN", "ARIA",
//			"ARII", "ARKR", "ARLP", "ARMH", "ARNA", "ARQL", "ARRS", "ARRY",
//			"ARTC", "ARTX", "ARUN", "ARWR", "ASBC", "ASCA", "ASFI", "ASGN",
//			"BLTI", "BLUD", "BMC", "BMRN", "BMTC", "BMTI", "BNCL", "BNHNA",
//			"BNVI", "BOBE", "BODY", "BOKF", "BONT", "BOOM", "BPAX", "BPFH",
//			"BPOP", "BRCD", "BRCM", "BRID", "BRKL", "BRKR", "BRKS", "BRLI",
//			"CLDX", "CLFC", "CLFD", "CLMS", "CLMT", "CLNE", "CLUB", "CLWR",
//			"CMCO", "CMCSA", "CMCSK", "CME", "CMED", "CMTL", "CNBC", "CNIT",
//			"CNQR", "CNSL", "CNTF", "CNVO", "COCO", "COGO", "COHR", "COHU",
//			"COIN", "COLB", "COLM", "COMV", "CONN", "COOL", "CORE", "COST",
//			"COWN", "CPHD", "CPIX", "CPKI", "CPLA", "CPLP", "CPNO", "CPRT",
//			"CPSI", "CPST", "CPTS", "CPWM", "CPWR", "CRAY", "CRBC", "CRDC",
//			"CRDN", "CREE", "CRESY", "CRIC", "CRIS", "CRME", "CRMT", "CRNT",
//			"CROX", "CRUS", "CRWN", "CRZO", "CSBC", "CSCO", "CSFL", "CSGP",
//			"CSGS", "CSII", "CSIQ", "CSKI", "CSOD", "CSTR", "CSUN", "CSWC",
//			"CTAS", "CTBI", "CTCH", "CTCM", "CTCT", "CTDC", "CTE", "CTFO",
//			"CTIC", "CTRN", "CTRP", "CTSH", "CTXS", "CU", "CUTR", "CVBF",
//			"CVGI", "CVGW", "CVLT", "CVV", "CVVT", "CWCO", "CWEI", "CWST",
//			"CWTR", "CXDC", "CXPO", "CY", "CYBI", "CYBX", "CYCC", "CYMI",
//			"EXAR", "EXAS", "EXEL", "EXFO", "EXLP", "EXLS", "EXPD", "EXPE",
//			"EXTR", "EXXI", "EZCH", "EZPW", "FALC", "FARM", "FARO", "FAST",
//			"FBCM", "FCBC", "FCEL", "FCFS", "FCNCA", "FDML", "FDUS", "FEED",
//			"FEIC", "FELE", "FFBC", "FFIC", "FFIV", "FFN", "FIBK", "FINL",
//			"FIRE", "FISI", "FISV", "FITB", "FLEX", "FLIC", "FLIR", "FLOW",
//			"FLWS", "FMBI", "FMCN", "FMER", "FNFG", "FNGN", "FNSR", "FOLD",
//			"FORM", "FORR", "FORTY", "FOSL", "FPIC", "FPTB", "FRED", "FRNK",
//			"HBHC", "HBIO", "HCBK", "HCKT", "HCSG", "HDNG", "HEAT", "HELE",
//			"HERO", "HEV", "HGIC", "HGSI", "HHGP", "HIBB", "HILL", "HIMX",
//			"HITK", "HITT", "HLIT", "HMIN", "HMPR", "HMSY", "HNH", "HNSN",
//			"HOGS", "HOKU", "HOLI", "HOLX", "HOMB", "HOME", "HOOK", "HOTT",
//			"HPJ", "HRBN", "HRZN", "HSFT", "HSIC", "HSII", "HSNI", "HSOL",
//			"MBND", "MCGC", "MCHP", "MCHX", "MCRL", "MCRS", "MDAS", "MDCA",
//			"MDCO", "MDMD", "MDRX", "MDSO", "MDTH", "MDVN", "MEAS", "MEDH",
//			"MELA", "MELI", "MENT", "MEOH", "MERC", "MERU", "MFLX", "MGAM",
//			"MGEE", "MGIC", "MGLN", "MGPI", "MHGC", "MHLD", "MIDD", "MIND",
//			"MINI", "MIPS", "MITI", "MKSI", "MKTG", "MKTX", "MLHR", "MLNK",
//			"MLNX", "MMLP", "MMSI", "MMYT", "MNDO", "MNKD", "MNRO", "MNTA",
//			"MNTG", "MOBI", "MOFG", "MOLX", "MOLXA", "MORN", "MOTR", "MOVE",
//			"MPAA", "MPAC", "MPEL", "MPET", "MPWR", "MRCY", "MRGE", "MRNA",
//			"OTTR", "OVRL", "OVTI", "OXBT", "OXGN", "OXPS", "OYOG", "OZRK",
//			"PAAS", "PACB", "PACR", "PACW", "PAET", "PANL", "PARD", "PATH",
//			"PAYX", "PBCT", "PBIB", "PBNY", "PCAR", "PCBC", "PCH", "PCLN",
//			"PCRX", "PCTI", "PCYC", "PDCO", "PDII", "PDLI", "PEET", "PEGA",
//			"PEIXD", "PENN", "PERY", "PETD", "PETM", "PETS", "PFCB", "PGC",
//			"PGNX", "PHMD", "PICO", "PKOH", "PLAB", "PLCE", "PLCM", "PLFE",
//			"PLTM", "PLUG", "PLXS", "PLXT", "PMCS", "PMFG", "PMIC", "PMTC",
//			"PMTI", "PNCL", "PNFP", "PNNT", "PNRA", "PNSN", "PNTR", "PODD",
//			"POOL", "POWI", "POWR", "POZN", "PPBI", "PPDI", "PRAA", "PRFT",
//			"PRFZ", "PRGO", "PRGS", "PRGX", "PRIM", "PRMW", "PROV", "PRSC",
//			"PWRD", "PXLW", "PZZA", "QCOM", "QCOR", "QDEL", "QGEN", "QKLS",
//			"QLGC", "QLIK", "QLTY", "QNST", "QQQ", "QQQX", "QSFT", "QSII",
//			"QTEC", "QTWW", "QUIK", "RADS", "RAM", "RBCN", "RCII", "RCON",
//			"RDA", "RDCM", "RDEA", "RDEN", "RDNT", "RDWR", "RECN", "REDF",
//			"REFR", "REGN", "REIS", "RENT", "REVU", "REXX", "RFMD", "RGEN",
//			"TIER", "TINY", "TISA", "TISI", "TITN", "TIVO", "TKLC", "TLAB",
//			"TLEO", "TLVT", "TNAV", "TNCC", "TNDM", "TOBC", "TOWN", "TPCG",
//			"TPGI", "TQNT", "TQQQ", "TRAK", "TRCR", "TREE", "TRGL", "TRGT",
//			"TRID", "TRIT", "TRLG", "TRMB", "TRMK", "TROW", "TRS", "TRST",
//			"TSCO", "TSEM", "TSLA", "TSON", "TSRA", "TSRX", "TSTC", "TSYS",
//			"TTEC", "TTEK", "TTGT", "TTMI", "TTWO", "TUES", "TWER", "TWGP",
//			"TWTC", "TXCC", "TXRH", "TYPE", "TZOO", "UBNK", "UBSH", "UBSI",
//			"UCBID", "UCTT", "UDRL", "UEIC", "UEPS", "UFCS", "UFPI", "UFPT",
//			"UHAL", "ULTA", "ULTI", "UMBF", "UMPQ", "UNFI", "UNIS", "UNTD",
//			"UNTK", "UPI", "URBN", "URRE", "USAK", "USAP", "USAT", "USEG",
//			"USMO", "USPH", "USTR", "UTEK", "UTHR", "UTIW", "UTSI", "VASC",
//			"VCIT", "VCLK", "VCLT", "VCSH", "VDSI", "VECO", "VELT", "VGIT",
//			"ZIOP", "ZIP", "ZIXI", "ZLCS", "ZN", "ZOLL", "ZOLT", "ZRAN", "ZUMZ" };

}
