package com.statestreet.dao;

import java.util.List;

import com.statestreet.entities.DMLCollateralAccountCrossReference;


public interface CollateralDAO
{

    public List<DMLCollateralAccountCrossReference> getCollateralInfo(Integer pageNum, Integer recordsPerPage);

}
