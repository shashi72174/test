package com.statestreet.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.statestreet.entities.DMLCollateralAccountCrossReference;

public class CollateralDAOImpl implements CollateralDAO
{
    private Connection con = null;
    private PreparedStatement pstmt = null;
    String sql = "SELECT * FROM (SELECT"+
    	       "UPPER(dmlCollA.ACTIVE_FLG) as p_activeInactive,"+
    	       "dmlCollA.source_sq as p_triPartyAgentId,"+
    	       "dmlCollA.COLL_TYPE_SQ as p_collateralTypCode,"+
    	       "dmlCollA.HOUSE_ACCT_ID as p_houseId,"+
    	       "dmlCollA.CTPY_ID AS p_dmlctpyid,"+
    	       "UPPER(dmlCollA.COLL_ACCT_ID) AS p_collateralAccount,"+
    	       "dmlCollA.VALID_FROM_DT AS p_validfrom,"+
    	       "dmlCollA.VALID_TO_DT AS p_validto,"+
    	       "UPPER(dmlCollA.LAST_MOD_SIGNON_ID) AS userID,"+
    	       "dmlCollA.LAST_MOD_DATE_TIME AS lastModified,"+
    	       "dmlCollA.curr_rec_flg as p_currRec,"+
    	       "dmlCollA.CODELONGDESCRIPTION as p_collateralCode, ROWNUM rn FROM"+
			   "(SELECT "+
    	       "UPPER(dmlColl.ACTIVE_FLG) as p_activeInactive,"+
    	       "smap.source_sq as p_triPartyAgentId,"+
    	       "dmlColl.COLL_TYPE_SQ as p_collateralTypCode,"+
    	       "dmlColl.HOUSE_ACCT_ID as p_houseId,"+
    	       "dmlColl.CTPY_ID AS p_dmlctpyid,"+
    	       "UPPER(dmlColl.COLL_ACCT_ID) AS p_collateralAccount,"+
    	       "dmlColl.VALID_FROM_DT AS p_validfrom,"+
    	       "dmlColl.VALID_TO_DT AS p_validto,"+
    	       "UPPER(dmlColl.LAST_MOD_SIGNON_ID) AS userID,"+
    	       "dmlColl.LAST_MOD_DATE_TIME AS lastModified,"+
    	       "dmlColl.curr_rec_flg as p_currRec,"+
    	       "colAcct.CODELONGDESCRIPTION as p_collateralCode "+
    	       "FROM OIR.NON_CASH_COLL_ACCT_XREF dmlColl, OIR.SOURCE_MAP smap, SLID.REFCODE_ACTVCOLLATERALCD_V colAcct) dmlCollA"+
			   "WHERE ROWNUM <=?) WHERE ROWNUM >=?";
    
	@Override
	public List<DMLCollateralAccountCrossReference> getCollateralInfo(Integer pageNum, Integer recordsPerPage) {
		List<DMLCollateralAccountCrossReference> collateralList = null;
		try {
		    Class.forName("oracle.jdbc.driver.OracleDriver");
		    //AGSOS226.IT.STATESTR.com:1521/o05SLD0
		    con = DriverManager.getConnection("jdbc:oracle:thin:@dsldd5.it.statestr.com:1521:o05SLD0","SLDDEVELOPER","SLDDEVELOPER");
		    pstmt = con.prepareStatement(sql);
		    pstmt.setInt(1, pageNum);
			pstmt.setInt(2, recordsPerPage);
		    ResultSet rs = pstmt.executeQuery();
		    if(rs!=null){
				collateralList = new ArrayList<DMLCollateralAccountCrossReference>();
				while(rs.next()) {
					DMLCollateralAccountCrossReference dmlCollateralAccountCrossReference = new DMLCollateralAccountCrossReference();
					dmlCollateralAccountCrossReference.setActiveFlg(rs.getString(1));
					dmlCollateralAccountCrossReference.setTripartyAgntId(rs.getString(2));
					dmlCollateralAccountCrossReference.setColTypeSeq(rs.getInt(3));
					dmlCollateralAccountCrossReference.setHouseAcctId(rs.getString(4));
				    dmlCollateralAccountCrossReference.setCtpyId(rs.getString(5));
					dmlCollateralAccountCrossReference.setCollAcctId(rs.getString(6));
					dmlCollateralAccountCrossReference.setValidFromDt(rs.getDate(7));
					dmlCollateralAccountCrossReference.setValidToDt(rs.getDate(8));
					dmlCollateralAccountCrossReference.setLastModSignOnId(rs.getString(9));
					dmlCollateralAccountCrossReference.setLastModifiedDate(rs.getDate(10));
					dmlCollateralAccountCrossReference.setCurrRecFlg(rs.getString(11));
					dmlCollateralAccountCrossReference.setCollateralCode(rs.getString(12));
				    System.out.println(dmlCollateralAccountCrossReference);
				    collateralList.add(dmlCollateralAccountCrossReference);
				    dmlCollateralAccountCrossReference = null;
				}
		    }
		}catch (Exception e) {
		    // TODO: handle exception
			e.printStackTrace();
		}
		return collateralList;
	}

}
