package com.statestreet.service;

import java.util.List;

import com.statestreet.dao.CollateralDAO;
import com.statestreet.dao.CollateralDAOImpl;
import com.statestreet.entities.DMLCollateralAccountCrossReference;


public class CollateralServiceImpl implements CollateralService
{
    
    private CollateralDAO collateralDAO = new CollateralDAOImpl(); 
    
   /* public List<CollateralType> getCollateralInfo()
    {
	// TODO Auto-generated method stub
	return collateralDAO.getCollateralInfo();
    }*/

	@Override
	public List<DMLCollateralAccountCrossReference> getCollateralInfo(Integer pageNum, Integer recordsPerPage) {
		// TODO Auto-generated method stub
		return collateralDAO.getCollateralInfo(pageNum, recordsPerPage);
	}
}
