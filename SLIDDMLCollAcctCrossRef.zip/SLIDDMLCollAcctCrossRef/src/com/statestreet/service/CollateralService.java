package com.statestreet.service;


import java.util.List;

import com.statestreet.entities.DMLCollateralAccountCrossReference;

public interface CollateralService
{

    public List<DMLCollateralAccountCrossReference> getCollateralInfo(Integer pageNum,Integer recordsPerPage);
    
}
