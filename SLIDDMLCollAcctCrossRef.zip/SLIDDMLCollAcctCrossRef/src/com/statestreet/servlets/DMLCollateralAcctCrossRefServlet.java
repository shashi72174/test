package com.statestreet.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;

import com.statestreet.entities.DMLCollateralAccountCrossReference;
import com.statestreet.service.CollateralService;
import com.statestreet.service.CollateralServiceImpl;

public class DMLCollateralAcctCrossRefServlet extends HttpServlet
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
	private CollateralService collateralService = new CollateralServiceImpl();
	private final Integer recordsPerPage = 5;
	private Integer pageNum = 1;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
    			boolean findAllFlag = true;
    			List<DMLCollateralAccountCrossReference> dmlCollAcctXRefList = null;
    			JSONObject mainObj = new JSONObject();
    			System.out.println("came here");
    			System.out.println(request.getParameter("action"));
    			HttpSession httpSession = request.getSession();
    			if (httpSession.getAttribute("pageNum") == null)
    				httpSession.setAttribute("pageNum", pageNum);
    			if ("next".equals(request.getParameter("action"))) {
    				pageNum = (Integer) httpSession.getAttribute("pageNum");
    				pageNum++;
    				httpSession.setAttribute("pageNum", pageNum);
    			} else if ("prev".equals(request.getParameter("action"))) {
    				pageNum = (Integer) httpSession.getAttribute("pageNum");
    				pageNum--;
    				if (pageNum <= 0)
    					pageNum = 1;
    				httpSession.setAttribute("pageNum", pageNum);
    			} else if ("search".equals(request.getParameter("action"))) {
    				findAllFlag = false;
    			}
    			try {
    				if (findAllFlag)
    					dmlCollAcctXRefList = collateralService.getCollateralInfo(pageNum, recordsPerPage);
    				/*else
    					dmlCollAcctXRefList = bookService.findByISBNAndBookName(Integer.parseInt(request.getParameter("isbn")),
    							request.getParameter("bookName"), pageNum, recordsPerPage);*/

    				System.out.println("obtained booksize =======>   " + dmlCollAcctXRefList.size());

    				JSONArray jsonArray = new JSONArray();
    				for (DMLCollateralAccountCrossReference crossReference : dmlCollAcctXRefList) {
    					JSONObject jsonObj = new JSONObject();
    					//jsonObj.put("COLTYPEID", crossReference.getColTypeSeq());
    					jsonObj.put("COLLATERALCODE", crossReference.getCollateralCode());
    					jsonObj.put("HOUSEACCTID", crossReference.getHouseAcctId());
    					jsonObj.put("CTPYID", crossReference.getCtpyId());
    					jsonObj.put("TRIPARTYAGNTID", crossReference.getTripartyAgntId());
    					jsonObj.put("COLLATERALACCT", crossReference.getCollAcctId());
    					jsonObj.put("VALIDFROMDT", crossReference.getValidFromDt());
    					jsonObj.put("VALIDTODT", crossReference.getValidToDt());
    					jsonObj.put("ACTIVEFLG", crossReference.getActiveFlg());
    					jsonObj.put("LASTMODSIGNONID", crossReference.getLastModSignOnId());
    					jsonObj.put("LASTMODSIGNONDATE", crossReference.getLastModifiedDate());
    					//jsonObj.put("COLLATERALCODE", crossReference.getLastModifiedDate());
    					jsonArray.put(jsonObj);
    				}
    				mainObj.put("books", jsonArray);
    			} catch (Exception e) {
    				e.printStackTrace();
    			}
    			response.getWriter().write(mainObj.toString());
	
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	
    }
}
