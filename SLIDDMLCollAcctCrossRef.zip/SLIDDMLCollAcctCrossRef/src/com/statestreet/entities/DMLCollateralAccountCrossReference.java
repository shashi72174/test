package com.statestreet.entities;

import java.io.Serializable;
import java.util.Date;

public class DMLCollateralAccountCrossReference implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer colTypeSeq;
	private String collateralCode;
	private String houseAcctId;
	private String ctpyId;
	private String collAcctId;
	private String lastModSignOnId;
	private Date lastModifiedDate;
	private String tripartyAgntId;
	private Date validFromDt;
	private Date validToDt;
	private String currRecFlg;
	private String activeFlg;

	public Integer getColTypeSeq() {
		return colTypeSeq;
	}

	public void setColTypeSeq(Integer colTypeSeq) {
		this.colTypeSeq = colTypeSeq;
	}

	public String getHouseAcctId() {
		return houseAcctId;
	}

	public void setHouseAcctId(String houseAcctId) {
		this.houseAcctId = houseAcctId;
	}

	public String getCtpyId() {
		return ctpyId;
	}

	public void setCtpyId(String ctpyId) {
		this.ctpyId = ctpyId;
	}

	public String getCollAcctId() {
		return collAcctId;
	}

	public void setCollAcctId(String collAcctId) {
		this.collAcctId = collAcctId;
	}

	public String getLastModSignOnId() {
		return lastModSignOnId;
	}

	public void setLastModSignOnId(String lastModSignOnId) {
		this.lastModSignOnId = lastModSignOnId;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getTripartyAgntId() {
		return tripartyAgntId;
	}

	public void setTripartyAgntId(String tripartyAgntId) {
		this.tripartyAgntId = tripartyAgntId;
	}

	public Date getValidFromDt() {
		return validFromDt;
	}

	public void setValidFromDt(Date validFromDt) {
		this.validFromDt = validFromDt;
	}

	public Date getValidToDt() {
		return validToDt;
	}

	public void setValidToDt(Date validToDt) {
		this.validToDt = validToDt;
	}

	public String getCurrRecFlg() {
		return currRecFlg;
	}

	public void setCurrRecFlg(String currRecFlg) {
		this.currRecFlg = currRecFlg;
	}

	public String getActiveFlg() {
		return activeFlg;
	}

	public void setActiveFlg(String activeFlg) {
		this.activeFlg = activeFlg;
	}

	public String getCollateralCode() {
		return collateralCode;
	}

	public void setCollateralCode(String collateralCode) {
		this.collateralCode = collateralCode;
	}

	@Override
	public String toString() {
		return "DMLCollateralAccountCrossReference [colTypeSeq=" + colTypeSeq + ", collateralCode=" + collateralCode
				+ ", houseAcctId=" + houseAcctId + ", ctpyId=" + ctpyId + ", collAcctId=" + collAcctId
				+ ", lastModSignOnId=" + lastModSignOnId + ", lastModifiedDate=" + lastModifiedDate
				+ ", tripartyAgntId=" + tripartyAgntId + ", validFromDt=" + validFromDt + ", validToDt=" + validToDt
				+ ", currRecFlg=" + currRecFlg + ", activeFlg=" + activeFlg + "]";
	}
}
