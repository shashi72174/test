package main;

import java.util.ArrayList;
import java.util.List;

import beans.Car;
import beans.Person;
import lectures.Lecture1;
import lectures.Lecture2;
import lectures.Lecture3;
import lectures.Lecture4;
import lectures.Lecture5;

public class Java8MainTest {
	
	static List<Person> personList = new ArrayList<Person>();
	static List<Car> carList = new ArrayList<Car>();
	
	static {
		personList.add(new Person(1, "Dixie", "O'Finan", "dofinan0@huffingtonpost.com", "Female", 91));
		personList.add(new Person(2, "Harmon", "Marling", "hmarling1@huffingtonpost.com", "Male", 38));
		personList.add(new Person(3, "Dallas", "Beynon", "dbeynon2@huffingtonpost.com", "Male", 61));
		personList.add(new Person(4, "Carlyle", "Lachaize", "clachaize3@huffingtonpost.com", "Male", 12));
		personList.add(new Person(5, "Eula", "Pimm", "epimm4@huffingtonpost.com", "Female", 54));
	}
	
	
	static {
		carList.add(new Car(1,"Toyota","Highlander","Mauv",2008,23736.62));
		carList.add(new Car(1,"Toyota","Solara","Fuscia",2002,66403.47));
		carList.add(new Car(1,"Ford","Expedition EL","Pink",2010,68973.04));
		carList.add(new Car(1,"Lexus","SC","Indigo",1997,20900.33));
		carList.add(new Car(1,"Hummer","H1","Red",1998,14187.98));
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("using streams to display elements in list based upon some filter(predicate) && limit functions");
		Lecture1 lecture1 = new Lecture1();
		lecture1.imperativeApproach(personList);
		lecture1.declarativeApproachUsingStreams(personList);
		
		System.out.println("range && rangeclosed and iterate in intstream");
		Lecture2 lecture2 = new Lecture2();
		lecture2.range();
		lecture2.rangeIteratingLists(personList);
		lecture2.intStreamIterate();
		
		System.out.println("min && max in stream and intstream");
		Lecture3 lecture3 = new Lecture3();
		lecture3.min();
		lecture3.max();
		
		System.out.println("distinct in stream");
		Lecture4 lecture4 = new Lecture4();
		lecture4.distinct();
		lecture4.distinctWithSet();
		
		Lecture5 lecture5 = new Lecture5();
		lecture5.averageCarPrice(carList);
		lecture5.understandingFilter(carList);
		lecture5.ourFirstMapping(personList);
		lecture5.averageCarYear(carList);
		
	}

}
