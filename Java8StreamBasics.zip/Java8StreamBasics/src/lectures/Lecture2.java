package lectures;

import java.util.List;
import java.util.stream.IntStream;

import beans.Person;

public class Lecture2 {

	  public void range() {
	    System.out.println("for i");
	    for (int i = 0; i <= 10; i++) {
	      System.out.println(i);
	    }
	    IntStream.range(0, 10).forEach(i -> System.out.println(i));
	    IntStream.rangeClosed(0, 10).forEach(i -> System.out.println(i));
	  }

	  public void rangeIteratingLists(List<Person> people) {
		  IntStream.range(0, people.size()).forEach(index -> System.out.println(people.get(index)));
	  }

	  public void intStreamIterate() {
	      IntStream.range(0, 10).filter(i -> i%2==0).forEach(System.out::println);
	      IntStream.iterate(0, i->i+2).limit(5).forEach(System.out::println);
	  }
}
