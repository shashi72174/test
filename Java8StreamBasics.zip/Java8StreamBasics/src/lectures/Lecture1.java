package lectures;

import beans.Person;
import java.util.List;
import java.util.stream.Collectors;


public class Lecture1 {

  public void imperativeApproach(List<Person> personList) {
	  for(Person person : personList) {
		  if(person.getAge()<=18)
			  System.out.println(person);
	  }
	  int counter=0;
	  while(counter<2) {
		  System.out.println(personList.get(counter));
		  counter++;
	  }
  }

  public void declarativeApproachUsingStreams(List<Person> personList) {
	  personList.stream().filter(p -> p.getAge()<=18).collect(Collectors.toList()).forEach(System.out::println);
	  personList.stream().limit(2).collect(Collectors.toList()).forEach(System.out::println);
  }
}