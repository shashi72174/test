package lectures;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Lecture4 {
	  public void distinct()  {
	    Stream<Integer> numbers = Stream.of(1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 9, 9, 9);
	    numbers.distinct().forEach(System.out::println);
	    numbers = Stream.of(1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 9, 9, 9);
	    System.out.println("count "+numbers.distinct().count());
	  }

	  public void distinctWithSet()  {
	    Stream<Integer> numbers = Stream.of(1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 9, 9, 9);
	    numbers.collect(Collectors.toSet()).forEach(System.out::println);
	    numbers = Stream.of(1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 9, 9, 9);
	    System.out.println("count "+numbers.distinct().count());
	  }
}
