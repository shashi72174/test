package lectures;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import beans.Car;
import beans.Person;
import beans.PersonDTO;

public class Lecture5 {
	  public void understandingFilter(List<Car> cars)  {
		cars.stream().filter(car -> car.getPrice() < 20000).forEach(System.out::println);  
	  }


	  public void ourFirstMapping(List<Person> people) {
	    // transform from one data type to another

	    List<PersonDTO> dtos = people.stream()
	        .map(PersonDTO::map)
	        .collect(Collectors.toList());

	    dtos.forEach(System.out::println);

	    //System.out.println(dtos.size());

	  }

	  public void averageCarPrice(List<Car> cars) {
		  System.out.println(cars.stream().mapToDouble(Car::getPrice).average().getAsDouble());
		  Stream<Double> totalSum = cars.stream().map(Lecture5::sumCarPrice).skip(cars.size()-1);
		  System.out.println(totalSum.findFirst().get()/cars.size());
	  }
	  
	  public void averageCarYear(List<Car> cars) {
		  System.out.println(cars.stream().mapToInt(Car::getYear).average().orElse(0));
		  //result.cars.size();
	  }
	  
	  static double sum = 0;
	  public static double sumCarPrice(Car car) {
		  return sum = sum+car.getPrice();
	  }
	  
}
