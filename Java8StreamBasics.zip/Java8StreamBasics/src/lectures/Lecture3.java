package lectures;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Lecture3 {

	  public void min() {
	   IntStream intStream = IntStream.of(1,5,3,8,6,9,0,2);
	   
	   int min=879899889;
	   
	   int[] numbers = intStream.toArray();
	   for(int i : numbers) {
		   if(i<min)
			   min=i;
	   }
	   System.out.println(min);
	   
	   intStream = IntStream.of(1,5,3,8,6,9,0,2);
	   
	   System.out.println(intStream.min().getAsInt());
	   
	   System.out.println(Stream.of(1,5,3,8,6,9,0,2).min((n1,n2) -> n1>n2 ? 1 : -1).get());
	   

	  }

	  public void max() {
		  IntStream intStream = IntStream.of(1,5,3,8,6,9,0,2);
		   
		   int max=-879899889;
		   
		   int[] numbers = intStream.toArray();
		   for(int i : numbers) {
			   if(i>max)
				   max=i;
		   }
		   System.out.println(max);
		   
		   intStream = IntStream.of(1,5,3,8,6,9,0,2);
		   System.out.println(intStream.max().getAsInt());
		   System.out.println(Stream.of(1,5,3,8,6,9,0,2).max((n1,n2) -> n1>n2 ? 1 : -1).get());
		  
	  }
}
