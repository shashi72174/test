import React from 'react'
import {render} from 'react-dom'
import RestApp from '../app/RestApp'
import { DragDropContext } from 'react-dnd'
import HTML5Backend from 'react-dnd-html5-backend'
import { AppContainer } from 'react-hot-loader';
import css from './index.css';
const rootElement = document.getElementById('app')
const AppContainerDnD = DragDropContext(HTML5Backend)(AppContainer);
const ctx = window.contextPath;

render(<AppContainerDnD>< RestApp contextPath={ctx}/></AppContainerDnD>, rootElement)
  if (module.hot) {
    module.hot.accept('../app/RestApp', () => {
      const NewRoot = require('../app/RestApp').default
      render(
        <AppContainerDnD>< NewRoot contextPath={ctx} /></AppContainerDnD>,
        rootElement
      )
    })
  }