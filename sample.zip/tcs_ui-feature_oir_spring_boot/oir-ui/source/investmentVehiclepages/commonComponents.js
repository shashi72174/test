import React, { Component } from "react"
import { Form, Button, connectRest, AlertBanner, DataGrid, Modal } from 'ssc-cdt4';
import { FormGroup, ControlLabel, FormControl } from 'react-bootstrap';


class FormComponent extends Component {
    constructor(props) {
        super(props);
    }

    render(){
        const { type, formData, fieldDatas, formButtonProps, parentClass ={} } = this.props;
        return (
            fieldDatas.length > 0 
                ? <Form {...formData} key={`${type}Form`}>
                    {fieldDatas.map((fieldProps, i) => <Form.Field {...fieldProps} 
                        key={`${type}FormField-${i}`} />)}
                    <div style={parentClass}>
                        {formButtonProps.length > 0 
                            && formButtonProps.map((btnProp, i)=> {
                                const { btnLabel, ...btn } = btnProp;
                                return (<Form.Button {...btn} key={`${type}FormButton-${i}`} >
                                    {btnLabel}
                                </Form.Button>);
                            })}
                    </div>
                </Form>
                : null 
        );
    }
};
class ModalComponent extends Component{
    constructor(props) {
        super(props);
    }
    closeBanner(){
    }
    render() {  
    const { modalType, isFormAvailable = false, modalData, title, 
        formProps, modalSubheader="", modalButtons=[], modalLevelError = false, modalLevelErrorMsg, modalLevelErrorType } = this.props;
       return (
        <Modal {...modalData}>
	     <Modal.Header>
         	<Modal.Title>{title}</Modal.Title>
         </Modal.Header>
         <Modal.Body>
             {
                modalLevelError 
                    ? <div style={{marginBottom: '10px'}}>
                        <AlertBanner type={modalLevelErrorType || "warning"} label={modalLevelErrorMsg} onClose={this.closeBanner} inline={true}/>
                    </div>
                    : null
            }
            {isFormAvailable && modalSubheader ? <p>{modalSubheader}</p> : null}
            {isFormAvailable 
                ? <FormComponent formData={formProps.modalFormData} 
                    fieldDatas={formProps.modalFormFieldDatas} parentClass = {formProps.addClass}
                    formButtonProps={formProps.modalFormBtnProps} type={modalType}/>
                : modalSubheader || modalButtons.length>0
                    ? <div className={`${modalType}-modal-body`}>
                        <p>{modalSubheader}</p>
                        { modalButtons.length>0 && modalButtons.map((mBtn, i)=> {
                            const { btnLbl, ...btnProp } = mBtn;
                            return <Button {...btnProp} key={`${modalType}-modalbtn-${i}`}>{btnLbl}</Button>
                        })}
                    </div>
                    : null }
        </Modal.Body>
    </Modal>
       );
    }
};


export {FormComponent, ModalComponent};