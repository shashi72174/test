const data = {
    
        "sources": [
            {
                "value": "105",
                "label": "SSGAUS"
            },
            {
                "value": "106",
                "label": "SSGANONUS"
            },
            {
                "value": "107",
                "label": "SSGACAD"
            }
        ],
        "triparty": [
            {
                "value": "101",
                "label": "BONYUS"
            },
            {
                "value": "102",
                "label": "BONYE"
            },
            {
                "value": "114",
                "label": "BONYCT"
            },
            {
                "value": "103",
                "label": "CHASE"
            },
            {
                "value": "104",
                "label": "CHASEGLOBAL"
            },
            {
                "value": "111",
                "label": "CLEARSTREAM"
            },
            {
                "value": "140",
                "label": "CMW"
            },
            {
                "value": "145",
                "label": "CREST"
            },
            {
                "value": "110",
                "label": "DEUTSCHE"
            },
            {
                "value": "109",
                "label": "EUROCLEAR"
            },
            {
                "value": "115",
                "label": "IBT"
            },
            {
                "value": "112",
                "label": "MSPFI"
            },
            {
                "value": "113",
                "label": "MSSFI"
            }
        ],
        "srcinvvehid": [
            {
                "value": "$EV1"
            },
            {
                "value": "$EV2"
            },
            {
                "value": "01AA",
                "label": "DG"
            },
            {
                "value": "01B2",
                "label": "Inactive"
            },
            {
                "value": "01B2",
                "label": "TEST IN"
            },
            {
                "value": "01BD",
                "label": "Inactive-CAISSE DE DEPOT DURATION"
            },
            {
                "value": "01BE",
                "label": "Inactive-WICHITA DURATION"
            },
            {
                "value": "01BF",
                "label": "Inactive-BAXTER PENSION DURATION"
            },
            {
                "value": "01BG",
                "label": "Inactive-MERCY QD DURATION"
            },
            {
                "value": "01BH",
                "label": "Inactive-ACS QD DURATION"
            },
            {
                "value": "01BI",
                "label": "Inactive-KAISER DURATION"
            },
            {
                "value": "01BJ",
                "label": "Inactive-MERCY SLQT DURATION"
            },
            {
                "value": "01BL",
                "label": "Inactive-ACS SLQT DURATION"
            },
            {
                "value": "01BM",
                "label": "ELEC DATA SYS RETIREMENT DURAT"
            },
            {
                "value": "01BN",
                "label": "ELEC DATA SYS 1994 PENSION DUR"
            },
            {
                "value": "01BO",
                "label": "Inactive-WESTCHESTER FIRE INS DURATION"
            },
            {
                "value": "01BP",
                "label": "Inactive-ACE TEMPEST LIFE HIGH DURATION"
            },
            {
                "value": "01BQ",
                "label": "Inactive-TRIPAR PARTNERSHIP DURATION"
            },
            {
                "value": "01BR",
                "label": "Inactive-BAXTER SAVINGS DURATION"
            },
            {
                "value": "01BU",
                "label": "Inactive-CITY OF BIRMINGHAM RETIREMENT AND RELIEF SYSTEM"
            },
            {
                "value": "01BV",
                "label": "Inactive-MARIN COUNTY"
            },
            {
                "value": "01BW",
                "label": "Inactive-SBCERA DURATION"
            },
            {
                "value": "01BZ",
                "label": "ADVENTIST HEALTH SYS SUNBELT HEALTHCARE CORP"
            },
            {
                "value": "01BZ"
            },
            {
                "value": "01CE",
                "label": "Inactive-SBERA"
            },
            {
                "value": "01CF",
                "label": "CITY OF SAN JOSE POLICE AND FIRE"
            },
            {
                "value": "01CF"
            },
            {
                "value": "01DB",
                "label": "Inactive-MBOI QD DURATION"
            },
            {
                "value": "01DE",
                "label": "Inactive-MBOI SLQT DURATION"
            },
            {
                "value": "01DE"
            },
            {
                "value": "01DF",
                "label": "Inactive-DCRB DURATION"
            },
            {
                "value": "01DG",
                "label": "Inactive-CTWW DURATION"
            },
            {
                "value": "01DH",
                "label": "Inactive-ACE TEMPEST REINSUR DURATION"
            },
            {
                "value": "01DI",
                "label": "Inactive-ACE AMERICAN DURATION"
            },
            {
                "value": "01DJ",
                "label": "Inactive-ACE FIRE DURATION"
            },
            {
                "value": "01DL",
                "label": "Inactive-ACE PROPERTY AND CASUALTY DURA"
            },
            {
                "value": "01DM",
                "label": "Inactive-BANKERS STANDARD FIRE DURATION"
            },
            {
                "value": "01DN",
                "label": "Inactive-BANKERS STANDARD INSU DURATION"
            },
            {
                "value": "01DP",
                "label": "Inactive-CENTURY INDEMNITY DURATION"
            },
            {
                "value": "01DQ",
                "label": "Inactive-INDEMNITY INSURANCE N A DURAITON"
            },
            {
                "value": "01DR",
                "label": "Inactive-INSURANCE CO N A DURATION"
            },
            {
                "value": "01DS",
                "label": "Inactive-PACIFIC EMPLOYEES INS DURATION"
            },
            {
                "value": "01DU",
                "label": "Inactive-CELANESE DURATION"
            },
            {
                "value": "01DV",
                "label": "LAMCTA COLLATERAL FUND"
            },
            {
                "value": "01DW",
                "label": "JOHN HANCOCK PREMIUM DIVIDEND FUND DE"
            },
            {
                "value": "01DW",
                "label": "STATE OF MICHIGAN MPSERS ACCT"
            },
            {
                "value": "01DW"
            },
            {
                "value": "01F2",
                "label": "DIAMOND HILL NAVIGATOR"
            },
            {
                "value": "01F4",
                "label": "NORFOLK COUNTY RETIREMENT SYSTEM"
            },
            {
                "value": "01F5",
                "label": "HBOS INVESTMENT FUND MANAGERS LIMITED"
            },
            {
                "value": "01F7",
                "label": "CITY OF NEW BEDFORD RETIREMENT SYSTEM"
            },
            {
                "value": "01F8",
                "label": "GLOBAL SECURITIES LENDING TRUST DURATION POOL"
            },
            {
                "value": "01F8",
                "label": "Inactive-GLOBAL SECURITIES LENDING TRUST DURATION POOL"
            },
            {
                "value": "01FA",
                "label": "Inactive-NEW CASTLE COUNTY COLLATERAL ACCOUNT DE"
            },
            {
                "value": "01FB",
                "label": "CITY OF HAVERHILL RETIREMENT SYSTEM"
            },
            {
                "value": "01FD",
                "label": "CAMBRIDGE RETIREMENT SYSTEM"
            },
            {
                "value": "01FS",
                "label": "SUNSUPER USD COLLATERAL TRUST"
            },
            {
                "value": "01FY",
                "label": "NESTLE USA SAVINGS TRUST FUND"
            },
            {
                "value": "01FZ",
                "label": "SSM HEALTH DURATION"
            },
            {
                "value": "01LA",
                "label": "INTE"
            },
            {
                "value": "01LA",
                "label": "Inactive-NATIONAL BANK OF SLOVAKIA"
            },
            {
                "value": "01LB",
                "label": "BANK  DE LA REPUBLICA"
            },
            {
                "value": "01LB",
                "label": "Inactive-BANK OF COLUMBIA"
            },
            {
                "value": "01LD"
            },
            {
                "value": "01LE"
            },
            {
                "value": "01LF",
                "label": "AUTOTEST2"
            },
            {
                "value": "01LF",
                "label": "KUWAIT INVESTMENT AUTHORITY-1"
            },
            {
                "value": "01LG",
                "label": "BANCO CENTRAL --DE BOLIVIA"
            },
            {
                "value": "01LG",
                "label": "Inactive-BANCO CENTRAL DE BOLIVIA"
            },
            {
                "value": "01LH",
                "label": "SAMA"
            },
            {
                "value": "01LH",
                "label": "SAUDI ARABIAN MONETARY AUTHORITY"
            },
            {
                "value": "01LJ",
                "label": "EVEREST"
            },
            {
                "value": "01LJ",
                "label": "EVEREST --"
            },
            {
                "value": "01LM",
                "label": "DAIMLER CHRYSLER"
            },
            {
                "value": "01LM",
                "label": "DAIMLER CHRYSLER CORPORATION"
            },
            {
                "value": "01LN",
                "label": "Inactive-BADEA"
            },
            {
                "value": "01LN"
            },
            {
                "value": "01LP",
                "label": "Inactive-QUALITY D II"
            },
            {
                "value": "01LP",
                "label": "QUALITY D II 9000 XL"
            },
            {
                "value": "01LQ",
                "label": "Inactive-RUSSELL INVESTMENT FUNDS"
            },
            {
                "value": "01LQ"
            },
            {
                "value": "01LR",
                "label": "FRANK RUSSELL INTERNAL"
            },
            {
                "value": "01LR",
                "label": "Inactive-RUSSELL INVESTMENT FUNDS"
            },
            {
                "value": "01LS",
                "label": "Inactive-CHICAGO MERCANTILE EXCHANGE"
            },
            {
                "value": "01LS"
            },
            {
                "value": "01LU",
                "label": "Inactive-STRONG CAPITAL MANAGEMENT"
            },
            {
                "value": "01LU"
            },
            {
                "value": "01LV",
                "label": "Inactive-TEXAS MUNICIPAL RETIREMENT SYSTEM"
            },
            {
                "value": "01LW",
                "label": "Inactive-FRANK RUSSELL IRELAND"
            },
            {
                "value": "01LW"
            },
            {
                "value": "01LX",
                "label": "Inactive-CESKA NARODNI BANKA"
            },
            {
                "value": "01LX"
            },
            {
                "value": "01LY",
                "label": "Inactive-MULTI-STYLE/MANAGER FUNDS PLC"
            },
            {
                "value": "01LY"
            },
            {
                "value": "01LZ",
                "label": "Inactive-NATIONWIDE BUILDING SOCIETY"
            },
            {
                "value": "01LZ"
            },
            {
                "value": "01M1",
                "label": "ASTO1 COLLATERAL"
            },
            {
                "value": "01M2",
                "label": "ASTO2 COLLATERAL"
            },
            {
                "value": "01M2"
            },
            {
                "value": "01M3",
                "label": "ASTO3 COLLATERAL"
            },
            {
                "value": "01M3"
            },
            {
                "value": "01M4",
                "label": "Inactive-ASTO4 COLLATERAL"
            },
            {
                "value": "01M5",
                "label": "Inactive-UNITED WISCONSIN INSUR CO COLL"
            },
            {
                "value": "01M6",
                "label": "Inactive-BC BS MICHIGAN COLL"
            },
            {
                "value": "01M8",
                "label": "Inactive-FOUNDATION FOR LOCAL SCHOOLS (463)"
            },
            {
                "value": "01M8"
            },
            {
                "value": "01MA",
                "label": "Inactive-NORGES BANK"
            },
            {
                "value": "01MA"
            },
            {
                "value": "01MB",
                "label": "Inactive-NORGES BANK"
            },
            {
                "value": "01MB"
            },
            {
                "value": "01MD",
                "label": "LLOYDS BANKING GROUP UK INS CO"
            },
            {
                "value": "01MD"
            },
            {
                "value": "01ME",
                "label": "Inactive-SST LTD AS DEP SCOTTISH WIDOWS"
            },
            {
                "value": "01ME"
            },
            {
                "value": "01MF",
                "label": "Inactive-BP PENSION TRUSTEES LIMITED"
            },
            {
                "value": "01MF"
            },
            {
                "value": "01MG",
                "label": "Inactive-SVERIGES RIKSBANK"
            },
            {
                "value": "01MG"
            },
            {
                "value": "01MH",
                "label": "BANK OF SLOVENIA"
            },
            {
                "value": "01MH"
            },
            {
                "value": "01MJ",
                "label": "BRITISH AIRWAYS PENSION TRUST"
            },
            {
                "value": "01MJ"
            },
            {
                "value": "01ML",
                "label": "Inactive-LLOYDS BANKING GROUP GRBF"
            },
            {
                "value": "01ML"
            },
            {
                "value": "01MP",
                "label": "DIMENSIONAL FUNDS PLC COLLATERAL ACCOUNT"
            },
            {
                "value": "01MP"
            },
            {
                "value": "01MQ",
                "label": "DIMENSIONAL FUNDS II PLC COLLATERAL ACCOUNT"
            },
            {
                "value": "01MR"
            },
            {
                "value": "01MS",
                "label": "LACERA STT CASH COLLATERAL FUND"
            },
            {
                "value": "01MS"
            },
            {
                "value": "01MU",
                "label": "PARTNERS HC SY EMP BPT COLL"
            },
            {
                "value": "01MU"
            },
            {
                "value": "01MV",
                "label": "Inactive-PARTNERS HEALTHCARE COLL"
            },
            {
                "value": "01MV"
            },
            {
                "value": "01MW",
                "label": "Inactive-UST INC COLLATERAL ACCOUNT"
            },
            {
                "value": "01MX",
                "label": "Inactive-PITNEY BOWES RPT COLLATERAL ACCOUNT"
            },
            {
                "value": "01MY",
                "label": "Inactive-ASCENSION HEALTH WELFARE BENEFITS TRUST"
            },
            {
                "value": "01MZ",
                "label": "Inactive-CITY PHOENIX ERS COLL"
            },
            {
                "value": "0787"
            },
            {
                "value": "0MHR",
                "label": "Inactive-TRS OF IL FINANCE-MAIN"
            },
            {
                "value": "1011"
            },
            {
                "value": "11CM"
            },
            {
                "value": "12CM"
            },
            {
                "value": "193 "
            },
            {
                "value": "1AHR",
                "label": "Inactive-TRS OF IL FINANCE-POB"
            },
            {
                "value": "1CHF"
            },
            {
                "value": "1IB4",
                "label": "GLENMEDE FINANCE"
            },
            {
                "value": "1IB4"
            },
            {
                "value": "1IB8",
                "label": "PCT PARTNERS"
            },
            {
                "value": "1LMS"
            },
            {
                "value": "2C72"
            },
            {
                "value": "2D01",
                "label": "Inactive-SSGA MONEY MARKET FUND"
            },
            {
                "value": "2D02",
                "label": "Inactive-SSGA U.S. GOV'T MONEY MARKET"
            },
            {
                "value": "2D02",
                "label": "SSGA U.S. GOV'T MONEY MARKET"
            },
            {
                "value": "2D07",
                "label": "Inactive-SSGA YIELD PLUS FUND"
            },
            {
                "value": "2D12",
                "label": "Inactive-SSGA U.S. TREASURY MONEY MKT"
            },
            {
                "value": "2D16",
                "label": "Inactive-SSGA PRIME MONEY MARKET FUND"
            },
            {
                "value": "2G99",
                "label": "Inactive-MET LIFE CASH MNGMT ACCOUNT"
            },
            {
                "value": "2GHY",
                "label": "2GHY"
            },
            {
                "value": "2LMS"
            },
            {
                "value": "2R39",
                "label": "Inactive-SANFORD BERNSTEIN II"
            },
            {
                "value": "2R39"
            },
            {
                "value": "2R40",
                "label": "Inactive-SANFORD BERNSTEIN"
            },
            {
                "value": "2R40"
            },
            {
                "value": "2XBX",
                "label": "Inactive-DAIMLER CHRYSLER MASTER RT"
            },
            {
                "value": "32002"
            },
            {
                "value": "34002"
            },
            {
                "value": "3C1B",
                "label": "Inactive-GLOBAL INCOME FUND"
            },
            {
                "value": "3C1B"
            },
            {
                "value": "3C1E",
                "label": "Inactive-MIDAS FUND INC"
            },
            {
                "value": "3C1E"
            },
            {
                "value": "3C1J",
                "label": "Inactive-MIDAS SPECIAL FUND"
            },
            {
                "value": "3C1J"
            },
            {
                "value": "3C1L",
                "label": "Inactive-FOXBY CORP"
            },
            {
                "value": "3C1L"
            },
            {
                "value": "3ER8",
                "label": "Inactive"
            },
            {
                "value": "3fdg"
            },
            {
                "value": "3FH2",
                "label": "Inactive-3FH2"
            },
            {
                "value": "3FH2",
                "label": "Inactive-PEARL ASSURANCE PLC"
            },
            {
                "value": "3FH3",
                "label": "Inactive-3FH3"
            },
            {
                "value": "3FH4",
                "label": "Inactive"
            },
            {
                "value": "3FH4"
            },
            {
                "value": "3FH5",
                "label": "Inactive"
            },
            {
                "value": "3FH5"
            },
            {
                "value": "3FH6",
                "label": "Inactive"
            },
            {
                "value": "3FH6"
            },
            {
                "value": "3FH9",
                "label": "Inactive"
            },
            {
                "value": "3FH9"
            },
            {
                "value": "3FHA",
                "label": "NATIONAL BANK OF SLOVAKIA"
            },
            {
                "value": "3FHA"
            },
            {
                "value": "3FHB",
                "label": "Inactive-BADEA EUR"
            },
            {
                "value": "3FHB"
            },
            {
                "value": "3FHD",
                "label": "Inactive-CZECH NATIONAL BANK"
            },
            {
                "value": "3FHD"
            },
            {
                "value": "3FHE",
                "label": "Inactive-GOVERNMENT OF NORWAY"
            },
            {
                "value": "3FHE"
            },
            {
                "value": "3FHF",
                "label": "THE BANK OF KOREA"
            },
            {
                "value": "3FHF"
            },
            {
                "value": "3FHG",
                "label": "Inactive-NATIONWIDE BUILDING SOCIETY"
            },
            {
                "value": "3FHG"
            },
            {
                "value": "3FHI",
                "label": "Inactive-GOVERNMENT OF NORWAY"
            },
            {
                "value": "3FHI"
            },
            {
                "value": "3FHJ",
                "label": "Inactive-NORGES PETROL INS"
            },
            {
                "value": "3FHJ"
            },
            {
                "value": "3FHM",
                "label": "Inactive-STITCHING PENSIOENFONDS"
            },
            {
                "value": "3FHM"
            },
            {
                "value": "3FHQ"
            },
            {
                "value": "3FHR"
            },
            {
                "value": "3FHS",
                "label": "Inactive-SVERIGES RIKSBANK (CB SWEDEN)"
            },
            {
                "value": "3FHS"
            },
            {
                "value": "3FHU",
                "label": "LLOYDS BANKING GROUP GRBF"
            },
            {
                "value": "3FHU"
            },
            {
                "value": "3FHV",
                "label": "LLOYDS BANKING GROUP GRBF"
            },
            {
                "value": "3FHV"
            },
            {
                "value": "3FHW",
                "label": "THE BANK OF KOREA"
            },
            {
                "value": "3FHW"
            },
            {
                "value": "3FHX",
                "label": "Inactive-CATHAY LIFE"
            },
            {
                "value": "3FHX"
            },
            {
                "value": "3FHY",
                "label": "KUWAIT INVESTMENT AUTHORITY"
            },
            {
                "value": "3FHY"
            },
            {
                "value": "3FJ2",
                "label": "ANDRA FONDEN CASH COLLATERAL ACCOUNT"
            },
            {
                "value": "3FJ3",
                "label": "STICHTING PENSIOENFONDS CHEVRON TEXACO NETHERLANDS"
            },
            {
                "value": "3FJ4",
                "label": "CHEVRON UK PENSION PLAN EUR"
            },
            {
                "value": "3FJ4"
            },
            {
                "value": "3FJ5",
                "label": "KINGFISHER PENSION TRUSTEE LIMITED"
            },
            {
                "value": "3FJ6",
                "label": "Inactive-BANK OF GHANA EUR"
            },
            {
                "value": "3FJW",
                "label": "Inactive-BEAMTENVERSICHERUNGSKASSE EUR"
            },
            {
                "value": "3FJX",
                "label": "AARGAUISCHE PENSIONSKASSE EUR"
            },
            {
                "value": "3FJY",
                "label": "MARKS AND SPENCER PENSION TRUST LIMITED"
            },
            {
                "value": "3FJZ",
                "label": "TATE AND LYLE"
            },
            {
                "value": "3FU2",
                "label": "Inactive-DEAM IRELAND"
            },
            {
                "value": "3FU2"
            },
            {
                "value": "3FU3",
                "label": "Inactive-RUSSELL INVESTMENT COMPANY"
            },
            {
                "value": "3FU3"
            },
            {
                "value": "3FU4",
                "label": "LLOYDS BANKING GROUP UK INS CO"
            },
            {
                "value": "3FU4"
            },
            {
                "value": "3FU5",
                "label": "LLOYDS BANKING GROUP UK INS CO"
            },
            {
                "value": "3FU5"
            },
            {
                "value": "3FU6",
                "label": "SCOTTISH WIDOWS INVESTMENT PARTNERSHIP LIMITED"
            },
            {
                "value": "3FU6"
            },
            {
                "value": "3FU7",
                "label": "SCOTTISH WIDOWS INVESTMENT PARTNERSHIP LIMITED"
            },
            {
                "value": "3FU7"
            },
            {
                "value": "3FU8",
                "label": "Inactive-BANK DE PORTUGAL"
            },
            {
                "value": "3FU8"
            },
            {
                "value": "3FU9",
                "label": "NATIONAL BANK OF HUNGARY"
            },
            {
                "value": "3FU9"
            },
            {
                "value": "3FUB"
            },
            {
                "value": "3HAV",
                "label": "EURO TRUST DURATION"
            },
            {
                "value": "3HAV"
            },
            {
                "value": "3HG2",
                "label": "Inactive-SUOMEN PANKKI (FINLAND)"
            },
            {
                "value": "3HG2",
                "label": "TEST"
            },
            {
                "value": "3HG3"
            },
            {
                "value": "3HG4",
                "label": "Inactive-CENTRAL BANK AND FINANCIAL SERVICES AUTHORITY OF IRELAND"
            },
            {
                "value": "3HG4"
            },
            {
                "value": "3HG5"
            },
            {
                "value": "3HG6",
                "label": "Inactive-NATIONAL BANK OF KAZAKHSTAN"
            },
            {
                "value": "3HG6"
            },
            {
                "value": "3HG7",
                "label": "Inactive-BANK OF ENGLAND"
            },
            {
                "value": "3HG7"
            },
            {
                "value": "3HG8",
                "label": "Inactive-NATIONWIDE BUILDING SOCIETY"
            },
            {
                "value": "3HG8"
            },
            {
                "value": "3HG9",
                "label": "BANK OF SLOVENIA"
            },
            {
                "value": "3HG9"
            },
            {
                "value": "3HGA",
                "label": "Inactive-UNIVERSAL INVESTMENT FUNDS"
            },
            {
                "value": "3HGB",
                "label": "Inactive-SAN BERNARDINO COUNTY EMPLOYEES RETIREMENT ASSOCIATION"
            },
            {
                "value": "3HGD",
                "label": "BRUNEI INVESTMENT AGENCY"
            },
            {
                "value": "3HGD"
            },
            {
                "value": "3HGE",
                "label": "Inactive-THE NMR PENSION FUND"
            },
            {
                "value": "3HGF",
                "label": "ELECTRONIC DATA SYSTEMS RETIREMENT PLAN"
            },
            {
                "value": "3HGH",
                "label": "ELECTRONIC DATA SYSTEMS 1994 PENSION SCHEME"
            },
            {
                "value": "3HGJ",
                "label": "NOMURA ASSET MANAGEMENT INSTITUTIONAL GLOBAL TRUST"
            },
            {
                "value": "3HGL",
                "label": "SAN DIEGO CITY EMPLOYEE'S RETIREMENT SYSTEM"
            },
            {
                "value": "3HGM",
                "label": "TECHMANAGEMENT LIMITED"
            },
            {
                "value": "3HGN",
                "label": "MALTA PENSION INVESTMENTS"
            },
            {
                "value": "3HGN"
            },
            {
                "value": "3HGP",
                "label": "Inactive-STATE ADMINISTRATION OF FOREIGN EXCHANGE EUR"
            },
            {
                "value": "3HH2",
                "label": "Inactive-NORGES BANK PETROLEUM FUND GBP"
            },
            {
                "value": "3HH2"
            },
            {
                "value": "3HH3",
                "label": "Inactive-NORGES BANK FX RESERVES GBP"
            },
            {
                "value": "3HH3"
            },
            {
                "value": "3HH4",
                "label": "Inactive-NORGES BANK PETROL INSURANCE"
            },
            {
                "value": "3HH4"
            },
            {
                "value": "3HH5",
                "label": "SAMA"
            },
            {
                "value": "3HH5"
            },
            {
                "value": "3HH6",
                "label": "Inactive-SAUDI ARABIAN MONETARY AUTHORITY"
            },
            {
                "value": "3HH6"
            },
            {
                "value": "3HH8",
                "label": "BRITISH AIRWAYS PENSION TRUSTEES LIMITED"
            },
            {
                "value": "3HH8"
            },
            {
                "value": "3HH9"
            },
            {
                "value": "3HHA",
                "label": "LLOYDS BANKING GROUP OEICS"
            },
            {
                "value": "3HHA"
            },
            {
                "value": "3HHB",
                "label": "LLOYDS BANKING GROUP OEICS"
            },
            {
                "value": "3HHB"
            },
            {
                "value": "4V08",
                "label": "JPM 130/30 CANADA FUND FINANCE"
            },
            {
                "value": "4V08"
            },
            {
                "value": "4ZL1",
                "label": "Inactive-MERCK & Co REPO"
            },
            {
                "value": "4ZL1",
                "label": "Inactive-Merck  Repo"
            },
            {
                "value": "4ZL3",
                "label": "Inactive-MSDI (H) REPO"
            },
            {
                "value": "4ZL3",
                "label": "Inactive-MSDI (H) Repo"
            },
            {
                "value": "4ZL4",
                "label": "Inactive-OMC REPO"
            },
            {
                "value": "4ZL4",
                "label": "Inactive-OMC Repo"
            },
            {
                "value": "5011"
            },
            {
                "value": "5670",
                "label": "Inactive-NORGES BANK INVESTMENT FUND"
            },
            {
                "value": "5670",
                "label": "Inactive-Norges Bank Investment Fund"
            },
            {
                "value": "5I6H",
                "label": "Inactive-CISCO SYSTEMS FINANCE INTERNATIONAL"
            },
            {
                "value": "5KP "
            },
            {
                "value": "6011"
            },
            {
                "value": "65KP"
            },
            {
                "value": "67SN"
            },
            {
                "value": "7011"
            },
            {
                "value": "769 ",
                "label": "Inactive-DEAM"
            },
            {
                "value": "769 "
            },
            {
                "value": "787 "
            },
            {
                "value": "8011"
            },
            {
                "value": "8483",
                "label": "Inactive-NORGES BANK BOND FUND"
            },
            {
                "value": "8483",
                "label": "Inactive-Norges Bank Bond Fund"
            },
            {
                "value": "8D1G",
                "label": "Inactive-REALNETWORKS, INC."
            },
            {
                "value": "8Y88",
                "label": "Inactive-FIT US GOVERMENT MONEY MARKET"
            },
            {
                "value": "8Y89",
                "label": "Inactive-FIT US TREASURY MONEY MARKET"
            },
            {
                "value": "8Y91",
                "label": "Inactive-FIT PRIME MONEY MARKET FUND"
            },
            {
                "value": "8Y91",
                "label": "Inactive-FIT US TREASURY MONEY MARKET"
            },
            {
                "value": "8Y92",
                "label": "Inactive-AMER FREEDOM US GOVT MNY MKT"
            },
            {
                "value": "9011"
            },
            {
                "value": "9KP ",
                "label": "TEST\n"
            },
            {
                "value": "9L01",
                "label": "Inactive-PAX WORLD BALANCED FUND"
            },
            {
                "value": "9L02",
                "label": "Inactive-PAX WORLD GROWTH FUND"
            },
            {
                "value": "9L03",
                "label": "Inactive-PAX WORLD HIGH YIELD BOND FUND"
            },
            {
                "value": "9L05",
                "label": "Inactive-PAX WORLD WOMEN'S EQUITY FUND"
            },
            {
                "value": "9T19",
                "label": "EURO TRUST (SSGSLET)"
            },
            {
                "value": "9T19",
                "label": "EURO TRUST LIQUIDITY"
            },
            {
                "value": "9T22",
                "label": "Inactive-HKMA EURO"
            },
            {
                "value": "9T22"
            },
            {
                "value": "9T36",
                "label": "Inactive-SS LUXEMBOURG"
            },
            {
                "value": "9T36R"
            },
            {
                "value": "9WJ5",
                "label": "NEUBERGER BERMAN (ECM)"
            },
            {
                "value": "9WJ5"
            },
            {
                "value": "9WJ8",
                "label": "NEUBERGER BERMAN ALTERNATIVE"
            },
            {
                "value": "AARG",
                "label": "IM ARGONAUT EURO ALPHA FUND"
            },
            {
                "value": "ABAR",
                "label": "AMERICAN BAR ASSOCIATION"
            },
            {
                "value": "ABC1"
            },
            {
                "value": "ABC2"
            },
            {
                "value": "ABC3"
            },
            {
                "value": "ABC4"
            },
            {
                "value": "ABC5"
            },
            {
                "value": "ABC6"
            },
            {
                "value": "ABC7"
            },
            {
                "value": "ABC8"
            },
            {
                "value": "ABC9"
            },
            {
                "value": "ABD1"
            },
            {
                "value": "ABD2"
            },
            {
                "value": "ABER",
                "label": "ALLIANCE BERNSTEIN EXCH RESERV"
            },
            {
                "value": "ABER"
            },
            {
                "value": "ABPSF"
            },
            {
                "value": "ABPU",
                "label": "Inactive"
            },
            {
                "value": "ABPU"
            },
            {
                "value": "ABYE",
                "label": "ABBEY LIFE ASSURANCE COMPANY"
            },
            {
                "value": "ABYG",
                "label": "ABBEY LIFE ASSURANCE COMPANY"
            },
            {
                "value": "ABYU",
                "label": "ABBEY LIFE ASSURANCE COMPANY"
            },
            {
                "value": "ACET",
                "label": "ACE TEMPEST RE INV GRADE FI"
            },
            {
                "value": "add "
            },
            {
                "value": "AGIE",
                "label": "Inactive-ALLIANZ GLOBAL INVESTORS EUR"
            },
            {
                "value": "AGIE"
            },
            {
                "value": "AIM ",
                "label": "Inactive"
            },
            {
                "value": "ALLM",
                "label": "Inactive"
            },
            {
                "value": "ALLM"
            },
            {
                "value": "AMER",
                "label": "Inactive"
            },
            {
                "value": "AMFE",
                "label": "Inactive"
            },
            {
                "value": "AMFE"
            },
            {
                "value": "AMFG",
                "label": "Inactive"
            },
            {
                "value": "AMFG"
            },
            {
                "value": "AMFU",
                "label": "ARAB MONETARY FUND - USD"
            },
            {
                "value": "AMFU"
            },
            {
                "value": "AMGN",
                "label": "Inactive"
            },
            {
                "value": "AMR ",
                "label": "Inactive"
            },
            {
                "value": "AND7"
            },
            {
                "value": "ANW1"
            },
            {
                "value": "ANW2"
            },
            {
                "value": "ANW3"
            },
            {
                "value": "ANW4"
            },
            {
                "value": "ANWA"
            },
            {
                "value": "ANZ ",
                "label": "Inactive"
            },
            {
                "value": "APIC",
                "label": "Inactive-ARAB PETROLEUM INVESTMENTS CORPORATION"
            },
            {
                "value": "APIC"
            },
            {
                "value": "APIE",
                "label": "Inactive-ARAB PETROLEUM INV CORP - EUR"
            },
            {
                "value": "APIE"
            },
            {
                "value": "APIG",
                "label": "Inactive"
            },
            {
                "value": "APIG"
            },
            {
                "value": "APKU",
                "label": "Inactive-AARGAUISCHE PENSIONSKASSE"
            },
            {
                "value": "ARGA",
                "label": "ARGONAUT EUR ABSOLUTE RETURN"
            },
            {
                "value": "ARGE",
                "label": "ARGONAUT EUR ENHANCED INCOME"
            },
            {
                "value": "ARGI",
                "label": "ARGONAUT EUR INCOME"
            },
            {
                "value": "ARGI"
            },
            {
                "value": "ARGO",
                "label": "ARGONAUT FUNDS"
            },
            {
                "value": "ARGO"
            },
            {
                "value": "ASTS"
            },
            {
                "value": "ATFE",
                "label": "ARAB TRADE FINANCING PROGRAM"
            },
            {
                "value": "ATFE"
            },
            {
                "value": "ATFG",
                "label": "ARAB TRDAE FINANCING - GBP"
            },
            {
                "value": "ATFG"
            },
            {
                "value": "ATFU",
                "label": "ARAB TRADE FINANCING PROGRAM"
            },
            {
                "value": "ATFU"
            },
            {
                "value": "AUT1"
            },
            {
                "value": "BALA"
            },
            {
                "value": "BAPE",
                "label": "Inactive-BRITISH ALCAN PENSION PLAN"
            },
            {
                "value": "BAPE"
            },
            {
                "value": "BAPG",
                "label": "Inactive"
            },
            {
                "value": "BAPG"
            },
            {
                "value": "BAPU",
                "label": "Inactive-BRITISH ALCAN PENSION PLAN"
            },
            {
                "value": "BAPU"
            },
            {
                "value": "BARG",
                "label": "Inactive-BRITISH AIRWAYS PENSION TRUSTEES LIMITED"
            },
            {
                "value": "BERN",
                "label": "Inactive"
            },
            {
                "value": "BERN"
            },
            {
                "value": "BIRA"
            },
            {
                "value": "BIRB"
            },
            {
                "value": "BL00",
                "label": "Inactive-YIELD ENHANCED STIF PORTFOLIO"
            },
            {
                "value": "BLDR",
                "label": "BOULDER GROWTH & INCOME FUND"
            },
            {
                "value": "BLMS"
            },
            {
                "value": "BMCH",
                "label": "Inactive"
            },
            {
                "value": "BMCH"
            },
            {
                "value": "BPSL",
                "label": "Inactive"
            },
            {
                "value": "BPSL"
            },
            {
                "value": "BQ8H",
                "label": "Inactive-RUSSELL AUSTRALIAN SHARES FUND"
            },
            {
                "value": "BRBA",
                "label": "BAM - ATLAS MASTER FUND LTD"
            },
            {
                "value": "BRBD",
                "label": "BAM - ATLAS ENHANCED MASTER"
            },
            {
                "value": "BRBE",
                "label": "BAM - ATLAS FUNDAMENTAL TRADING"
            },
            {
                "value": "BRBF",
                "label": "BAM - BAM ZIE MASTER FUND LTD"
            },
            {
                "value": "BRLM"
            },
            {
                "value": "BRY1"
            },
            {
                "value": "BRY2"
            },
            {
                "value": "BRY3"
            },
            {
                "value": "BRY4"
            },
            {
                "value": "BRY5"
            },
            {
                "value": "BUIE",
                "label": "Inactive-BALZAC UMBRELLA INDEX SICAV"
            },
            {
                "value": "BUIE"
            },
            {
                "value": "BUIU",
                "label": "Inactive"
            },
            {
                "value": "BUIU"
            },
            {
                "value": "BXWA",
                "label": "BLACKSTONE ALTERNATIVE MULTI MANAGER FUND WELLINGTON"
            },
            {
                "value": "BXWB",
                "label": "BLACKSTONE ALTERNATIVE MULTI MANAGER FUND TWO SIGMA"
            },
            {
                "value": "BXWD",
                "label": "BLACKSTONE ALTERNATIVE MULTI MANAGER FUND BTG PACTUAL"
            },
            {
                "value": "BXWE",
                "label": "BLACKSTONE ALTERNATIVE MULTI MANAGER FUND HEDGING GRIFFO"
            },
            {
                "value": "BXWF",
                "label": "BLACKSTONE ALTERNATIVE MULTI MANAGER SUBFUND III BG SARK"
            },
            {
                "value": "BXWG",
                "label": "BLACKSTONE ALTERNATIVE MULTI MANAGER FUND NEPHILA"
            },
            {
                "value": "BXWL",
                "label": "BLACKSTONE ALTERNATIVE MULTI MANAGER SUBFUND IV CASPIAN"
            },
            {
                "value": "BXWM",
                "label": "BLACKSTONE ALT MM FD GOLDMAN"
            },
            {
                "value": "BXWM"
            },
            {
                "value": "BXWN",
                "label": "BLACKSTONE ALTERNATIVE MULTI MANAGER SUBFUND IV HEALTHCOR"
            },
            {
                "value": "BXWN"
            },
            {
                "value": "BXWP",
                "label": "BLACKSTONE ALTERNATIVE MULTI MANAGER SUBFUND III CERBERUS"
            },
            {
                "value": "BXWQ",
                "label": "BLACKSTONE ALTERNATIVE MULTI MANAGER SUBFUND III CHATHAM"
            },
            {
                "value": "BXWQ"
            },
            {
                "value": "BXWR",
                "label": "BLACKSTONE ALTERNATIVE MULTI MANAGER SUBFUND III GOOD HILL"
            },
            {
                "value": "BXWV",
                "label": "BLACKSTONE AMM SUB RAILSPLIT"
            },
            {
                "value": "BXWV"
            },
            {
                "value": "BZWM",
                "label": "BLACKSTONE ALTERNATIVE MULTI-STRATEGY FUND"
            },
            {
                "value": "BZWM"
            },
            {
                "value": "BZWN",
                "label": "BLACKSTONE ALTERNATIVE MULTI-STRATEGY SUB-FUND IV, L.L.C."
            },
            {
                "value": "BZWN"
            },
            {
                "value": "BZWQ",
                "label": "BLACKSTONE ALTERNATIVE MULTI-STRATEGY SUB-FUND III, L.L.C."
            },
            {
                "value": "BZWQ"
            },
            {
                "value": "BZWV",
                "label": "BLACKSTONE AMS SUB RAILSPLIT"
            },
            {
                "value": "BZWV"
            },
            {
                "value": "C020"
            },
            {
                "value": "C040"
            },
            {
                "value": "CALA",
                "label": "Inactive"
            },
            {
                "value": "CALA"
            },
            {
                "value": "CALP",
                "label": "CALIFORNIA PUBLIC EMPLOYEES RETIREMENT SYSTEM"
            },
            {
                "value": "CALP"
            },
            {
                "value": "CALV",
                "label": "CALVERT"
            },
            {
                "value": "CARG",
                "label": "IM ARGONAUT EURO ENHANCED FUND"
            },
            {
                "value": "CASE",
                "label": "Inactive"
            },
            {
                "value": "CASH",
                "label": "Inactive-UNINVESTED CASH"
            },
            {
                "value": "CCHF"
            },
            {
                "value": "CDPE",
                "label": "Inactive"
            },
            {
                "value": "CDPE"
            },
            {
                "value": "CF90",
                "label": "Inactive-FATIMA TEST"
            },
            {
                "value": "CF91"
            },
            {
                "value": "CF92"
            },
            {
                "value": "CF93"
            },
            {
                "value": "CF95"
            },
            {
                "value": "CF96"
            },
            {
                "value": "CF97"
            },
            {
                "value": "CF98"
            },
            {
                "value": "CF99"
            },
            {
                "value": "CFG3",
                "label": "Inactive"
            },
            {
                "value": "CFI4",
                "label": "PACE LARGE CO VALUE EQUITIES INVESTMENTS"
            },
            {
                "value": "CFK8",
                "label": "PACE INTERNATIONAL EQUITIES INVESTMENTS"
            },
            {
                "value": "CI5H",
                "label": "Inactive-CISCO SYSTEMS, INC"
            },
            {
                "value": "CI5H",
                "label": "Inactive-CISCO SYSTEMS, INC."
            },
            {
                "value": "CI6H",
                "label": "Inactive-CISCO SYSTEMS FINANCE INTERNATIONAL"
            },
            {
                "value": "CI6H",
                "label": "Inactive-Cisco Systems Finance International"
            },
            {
                "value": "CIDG",
                "label": "CITADEL MULTI-STRATEGY EQ MSTR"
            },
            {
                "value": "CISC",
                "label": "Inactive"
            },
            {
                "value": "CLBR",
                "label": "Inactive"
            },
            {
                "value": "CLBR"
            },
            {
                "value": "CLIE",
                "label": "CATHAY LIFE INSURANCE CO LTD"
            },
            {
                "value": "CLIE"
            },
            {
                "value": "CM4B",
                "label": "Inactive-US DOLLAR LIBOR PLUS FD"
            },
            {
                "value": "CMA2",
                "label": "Inactive-US DOLLAR LIBOR PLUS CTF"
            },
            {
                "value": "CMD5",
                "label": "STATE OF ALABAMA"
            },
            {
                "value": "CMD5"
            },
            {
                "value": "CMDA",
                "label": "Inactive-SSGA CAYMAN HEDGED CORE EQ 40"
            },
            {
                "value": "CMDA"
            },
            {
                "value": "CMDB",
                "label": "Inactive-SSGA CAYMAN PERFORMPERSISTENCE"
            },
            {
                "value": "CMJ6",
                "label": "Inactive-FUND CLOSED ON 06/01/2003"
            },
            {
                "value": "COED",
                "label": "Inactive"
            },
            {
                "value": "COED"
            },
            {
                "value": "COMF",
                "label": "Inactive"
            },
            {
                "value": "COMF"
            },
            {
                "value": "CON1"
            },
            {
                "value": "CON2"
            },
            {
                "value": "CON3"
            },
            {
                "value": "CON4"
            },
            {
                "value": "CON5"
            },
            {
                "value": "CR01"
            },
            {
                "value": "CR02"
            },
            {
                "value": "CR03"
            },
            {
                "value": "CR04"
            },
            {
                "value": "CR06"
            },
            {
                "value": "CR07"
            },
            {
                "value": "CREF",
                "label": "COLLEGE RETIREMENT EQUITIES FUND"
            },
            {
                "value": "CREF"
            },
            {
                "value": "CREG",
                "label": "TIAA CREF SOCIAL CHOICE EQUITY FUND"
            },
            {
                "value": "CREG"
            },
            {
                "value": "CREI",
                "label": "TIAA CREF - SOCIAL CHOICE INTL SLEEVE"
            },
            {
                "value": "CREI"
            },
            {
                "value": "CRF2",
                "label": "Inactive"
            },
            {
                "value": "CRF2"
            },
            {
                "value": "CRN1",
                "label": "Inactive-CORNELL UNIVERSITY US TRUST ACCOUNT"
            },
            {
                "value": "CSAM",
                "label": "Inactive"
            },
            {
                "value": "CSAM"
            },
            {
                "value": "CSTL"
            },
            {
                "value": "CVX5",
                "label": "CALAMOS DYNAMIC CONVERTIBLE & INCOME FUND"
            },
            {
                "value": "CVX5"
            },
            {
                "value": "CVXA",
                "label": "CALAMOS STRATEGIC TOTAL RETURN"
            },
            {
                "value": "CVXA"
            },
            {
                "value": "CVXB",
                "label": "CALAMOS CONVERTIBLE OPPORTUNIT"
            },
            {
                "value": "CVXB"
            },
            {
                "value": "CVXD",
                "label": "CALAMOS CONVERTIBLE AND HIGH"
            },
            {
                "value": "CVXD"
            },
            {
                "value": "CVXE",
                "label": "CALAMOS GLOBAL TOTAL RETURN FU"
            },
            {
                "value": "CVXE"
            },
            {
                "value": "CVXF",
                "label": "CALAMOS GLOBAL DYNAMIC INCOME"
            },
            {
                "value": "CVXF"
            },
            {
                "value": "DAA1"
            },
            {
                "value": "DARG",
                "label": "IM ARGONAUT EURO ABSOLUTE RETURN FUND"
            },
            {
                "value": "DARM"
            },
            {
                "value": "DBA2",
                "label": "Inactive-DBCON5RC"
            },
            {
                "value": "DBB2"
            },
            {
                "value": "DBCON5RC"
            },
            {
                "value": "DBG1"
            },
            {
                "value": "DCC3"
            },
            {
                "value": "DDDD"
            },
            {
                "value": "DEAM",
                "label": "Inactive"
            },
            {
                "value": "DEHE",
                "label": "D. E. SHAW HELIANT CAPITAL, L.L.C."
            },
            {
                "value": "DEHE"
            },
            {
                "value": "DEM ",
                "label": "Inactive"
            },
            {
                "value": "DEM1"
            },
            {
                "value": "DEQY",
                "label": "Inactive"
            },
            {
                "value": "DESH",
                "label": "D.E SHAW U.S. BMC AE AGENCY"
            },
            {
                "value": "DFBE",
                "label": "Inactive-DIMENSIONAL FUNDS PLC EUR"
            },
            {
                "value": "DFBG",
                "label": "Inactive-CREATED IN ERROR"
            },
            {
                "value": "DFCE",
                "label": "Inactive-CREATED IN ERROR"
            },
            {
                "value": "DFCG",
                "label": "Inactive-DIMENSIONAL FUNDS II PLS GBP"
            },
            {
                "value": "DG3L"
            },
            {
                "value": "DGMR"
            },
            {
                "value": "DJP1"
            },
            {
                "value": "DM01"
            },
            {
                "value": "DM02"
            },
            {
                "value": "DM03"
            },
            {
                "value": "DMIV",
                "label": "DON MAWSON TEST INVESTMENT VEHICLE"
            },
            {
                "value": "DRU1"
            },
            {
                "value": "DRU2"
            },
            {
                "value": "DRU3"
            },
            {
                "value": "DRU4"
            },
            {
                "value": "DSTF",
                "label": "DFA SHORT TERM INVESTMENT FUND"
            },
            {
                "value": "DSTF"
            },
            {
                "value": "DU19",
                "label": "Inactive-CAISSE DE DEPOT ET PLACEMENT DU QUEBEC"
            },
            {
                "value": "DU28",
                "label": "Inactive-CAISSE DE DEPOT ET PLACEMENT DU QUEBEC"
            },
            {
                "value": "DZF9",
                "label": "ALBERTA"
            },
            {
                "value": "DZF9"
            },
            {
                "value": "E222"
            },
            {
                "value": "E255"
            },
            {
                "value": "E277"
            },
            {
                "value": "EARG",
                "label": "IM ARGONAUT EURO INCOME FUND"
            },
            {
                "value": "ECFF",
                "label": "Inactive"
            },
            {
                "value": "EDAF",
                "label": "DWS DIVERSIFIED MARKET NEUTRAL FUND"
            },
            {
                "value": "EDAF"
            },
            {
                "value": "EEFE",
                "label": "Inactive-EURIZON EASY FUND EUR"
            },
            {
                "value": "EEFU",
                "label": "Inactive-EURIZON EASY FUND USD"
            },
            {
                "value": "EFRE",
                "label": "Inactive-EURIZON FOCUS RISERVA EUR"
            },
            {
                "value": "EFRU",
                "label": "Inactive-EURIZON FOCUS RISERVA USD"
            },
            {
                "value": "EFSE",
                "label": "Inactive-EURIZONFOCUSSTRATFLESSIBLE EUR"
            },
            {
                "value": "EFSU",
                "label": "Inactive-EURIZONFOCUSSTRATFLESSIBLE USD"
            },
            {
                "value": "EHP1"
            },
            {
                "value": "EHP5"
            },
            {
                "value": "EHP8"
            },
            {
                "value": "EMED",
                "label": "Inactive"
            },
            {
                "value": "EMED"
            },
            {
                "value": "EOC1",
                "label": "Inactive-EUROCLEAR MORGAN STANLEY CREDIT LINE ACCOUNT 99210"
            },
            {
                "value": "ER01"
            },
            {
                "value": "ER02"
            },
            {
                "value": "ERO3"
            },
            {
                "value": "ESEC",
                "label": "Inactive-34002"
            },
            {
                "value": "ESFE",
                "label": "Inactive-EURIZON STARS FUND EUR"
            },
            {
                "value": "ESFU",
                "label": "Inactive-EURIZON STARS FUND USD"
            },
            {
                "value": "ESH2",
                "label": "DE SHAW US BMC AE PORTFOLIOS"
            },
            {
                "value": "ESH3",
                "label": "DE SHAW US BMC AE PLUS PORTFOLIO"
            },
            {
                "value": "ESH5",
                "label": "SHAW VALENCE"
            },
            {
                "value": "ESH5"
            },
            {
                "value": "ESH6",
                "label": "DESHAW OCULUS ECM"
            },
            {
                "value": "ESHA",
                "label": "DESHAW OCULUS AGENCY"
            },
            {
                "value": "ESHA"
            },
            {
                "value": "ESHB",
                "label": "DE SHAW US BMC AE SPECIAL PORTFOLIO"
            },
            {
                "value": "ESHD",
                "label": "D.E. SHAW US LARGE CAP CORE ALFA"
            },
            {
                "value": "ESHN",
                "label": "DE SHAW (EC SELF-FINANCE)"
            },
            {
                "value": "ESHP",
                "label": "DE SHAW WOULD ALPHA EXTENSION PORTFOLIOS, LLC"
            },
            {
                "value": "ESHQ",
                "label": "DE SHAW ALL COUNTRY GLOBAL ALPHA EXTENSION PORTFOLIOS LLC"
            },
            {
                "value": "ESHR",
                "label": "Inactive-D. E. SHAW BMCAE SPECIAL FUND, L.P."
            },
            {
                "value": "ESHS",
                "label": "Inactive-D. E. SHAW VALUE ALL COUNTRY ALPHA EXTENSION FUND, L.P."
            },
            {
                "value": "EVAL",
                "label": "Inactive"
            },
            {
                "value": "EVAN",
                "label": "Inactive-THE EATON VANCE INVESTMENT COMPANIES - VARIOUS FUNDS"
            },
            {
                "value": "EVAN"
            },
            {
                "value": "EVGN",
                "label": "Inactive"
            },
            {
                "value": "EXTR",
                "label": "Inactive"
            },
            {
                "value": "EXTR"
            },
            {
                "value": "f950"
            },
            {
                "value": "FC01",
                "label": "Inactive-G - STIF"
            },
            {
                "value": "FC02",
                "label": "Inactive-STATE STREET STIF"
            },
            {
                "value": "FC09",
                "label": "Inactive-SUPER COLLATERAL FUND"
            },
            {
                "value": "FC09"
            },
            {
                "value": "FC10",
                "label": "CALIFORNIA STATE TEACHER'S RETIREMENT SYSTEM"
            },
            {
                "value": "FC10"
            },
            {
                "value": "FC12",
                "label": "SLQT LIQUIDITY"
            },
            {
                "value": "FC12"
            },
            {
                "value": "FC14",
                "label": "QUALITY D\n"
            },
            {
                "value": "FC14",
                "label": "QUALITY D LIQUIDITY"
            },
            {
                "value": "FC15",
                "label": "THE REGENTS OF THE UNIVERSITY OF CALIFORNIA"
            },
            {
                "value": "FC15"
            },
            {
                "value": "FC17",
                "label": "MET LIFE SHORT TERM INVESTMENT FUND"
            },
            {
                "value": "FC17"
            },
            {
                "value": "FC19",
                "label": "QUALITY A\n"
            },
            {
                "value": "FC19",
                "label": "QUALITY A SHORT TERM INVESTMENT FUND"
            },
            {
                "value": "FC1A",
                "label": "Inactive"
            },
            {
                "value": "FC1A",
                "label": "Inactive-NAVIGATOR GOVT"
            },
            {
                "value": "FC1B",
                "label": "STATE STREET NAVIGATOR SECURITIES LENDING GOVERNMENT MONEY MARKET PORTFOLIO"
            },
            {
                "value": "FC1B"
            },
            {
                "value": "FC1D",
                "label": "Inactive-STATE STREET NAVIGATOR SECURITIES LENDING GOVERNMENT PORTFOLIO"
            },
            {
                "value": "FC1D"
            },
            {
                "value": "FC1H",
                "label": "CISCO SYSTEMS INTERNATIONAL B.V."
            },
            {
                "value": "FC1H"
            },
            {
                "value": "FC1J",
                "label": "GOVERNMENT OF SINGAPORE INVESTMENT CORPORATION PTE LTD"
            },
            {
                "value": "FC1L",
                "label": "Inactive-OVERSES ASSURANCE CORPORATION LIMITED"
            },
            {
                "value": "FC1M",
                "label": "RETAIL EMPLOYEES SUPERANNUATION PTY LIMITED USD"
            },
            {
                "value": "FC1M"
            },
            {
                "value": "FC1N",
                "label": "Inactive-STATE ADMINISTRATION OF FOREIGN EXCHANGE"
            },
            {
                "value": "FC1P",
                "label": "Inactive-STICHTING CHEVRON PENSIOENFOND"
            },
            {
                "value": "FC1Q",
                "label": "Inactive-CHEVRON UK PENSION TRUSTEES"
            },
            {
                "value": "FC1Q"
            },
            {
                "value": "FC1R",
                "label": "Inactive-INVESTEC FUND MANAGERS LIMITED"
            },
            {
                "value": "FC1S",
                "label": "Inactive-INVESTEC GLOBAL STRATEGY FUND"
            },
            {
                "value": "FC1U",
                "label": "LLOYDS BANKING GROUP OEICS"
            },
            {
                "value": "FC1V",
                "label": "Inactive-LAWRENCE LIVERMORE LOS ALAMOS NAT SEC LLC"
            },
            {
                "value": "FC1X",
                "label": "TIAA CREF NAVIGATOR"
            },
            {
                "value": "FC1X"
            },
            {
                "value": "FC1Y",
                "label": "Inactive-STATE STREET BANK AND TRST COMP AS TRUSTEE OF BECHTEL CORP MASTER TRST COLL ACCT"
            },
            {
                "value": "FC1Z",
                "label": "VERMONT PENSION INVESTMENT COMMITTEE"
            },
            {
                "value": "FC1Z"
            },
            {
                "value": "FC20",
                "label": "Inactive-MISSISSIPPI"
            },
            {
                "value": "FC20"
            },
            {
                "value": "FC21",
                "label": "GLOBAL SECURITIES LENDING TRUST\n"
            },
            {
                "value": "FC21",
                "label": "SSGSLT LIQUIDITY"
            },
            {
                "value": "FC22",
                "label": "Inactive-AMERITECH"
            },
            {
                "value": "FC22"
            },
            {
                "value": "FC23",
                "label": "Inactive-CALPERS"
            },
            {
                "value": "FC23"
            },
            {
                "value": "FC24",
                "label": "STATE OF CONNECTICUT COLLATERAL INVESTMENT TRUST"
            },
            {
                "value": "FC24"
            },
            {
                "value": "FC25",
                "label": "SSGA CIF"
            },
            {
                "value": "FC25"
            },
            {
                "value": "FC26",
                "label": "Inactive-STATE OF WASHINGTON"
            },
            {
                "value": "FC26"
            },
            {
                "value": "FC27",
                "label": "BANK OF CANADA"
            },
            {
                "value": "FC27",
                "label": "CANADA SHORT-TERM INVESTMENT FUND"
            },
            {
                "value": "FC28",
                "label": "Inactive-STATE OF OREGON"
            },
            {
                "value": "FC28"
            },
            {
                "value": "FC29",
                "label": "Inactive-STATE OF NEW MEXICO"
            },
            {
                "value": "FC29"
            },
            {
                "value": "FC2A",
                "label": "Inactive-VCI INTL EQUITIES FUND"
            },
            {
                "value": "FC2B",
                "label": "Inactive-VCI GOVERNMENT SECURITIES FUND"
            },
            {
                "value": "FC2D",
                "label": "Inactive-VCI CAPITAL CONSERVATION FUND"
            },
            {
                "value": "FC2E",
                "label": "Inactive-VCI STOCK INDEX FUND"
            },
            {
                "value": "FC2F",
                "label": "Inactive-VCI SOCIAL AWARENESS FUND"
            },
            {
                "value": "FC2G",
                "label": "Inactive-VCI MID CAP INDEX FUND"
            },
            {
                "value": "FC2H",
                "label": "Inactive-VCI SMALL CAP INDEX FUND"
            },
            {
                "value": "FC2I",
                "label": "Inactive-VCI GROWTH & INCOME FUND"
            },
            {
                "value": "FC2J",
                "label": "Inactive-VCI SCIENCE & TECH FUND"
            },
            {
                "value": "FC2L",
                "label": "Inactive-VCI NADA 100 INDEX FUND"
            },
            {
                "value": "FC2M",
                "label": "Inactive-VCI INTERNATIONAL GROWTH I FUND"
            },
            {
                "value": "FC2N",
                "label": "Inactive-VCI BLUE CHIP GROWTH FUND"
            },
            {
                "value": "FC2P",
                "label": "Inactive-VCI SMALL CAP FUND"
            },
            {
                "value": "FC2Q",
                "label": "Inactive-VCI FOREIGN VALUE FUND"
            },
            {
                "value": "FC2R",
                "label": "Inactive-VCI GLOBAL EQUITY FUND"
            },
            {
                "value": "FC2S",
                "label": "Inactive-VCI LARGE CAP CORE FUND"
            },
            {
                "value": "FC2U",
                "label": "Inactive-VCI SMALL CAP AGGRESSIVE GROWTH"
            },
            {
                "value": "FC2V",
                "label": "Inactive-VCI SMALL-MID GROWTH FUND"
            },
            {
                "value": "FC2W",
                "label": "Inactive-VCI GROWTH FUND"
            },
            {
                "value": "FC2X",
                "label": "Inactive-VCI GLOBAL STRATEGY FUND - EQUITY"
            },
            {
                "value": "FC2Y",
                "label": "Inactive-VCI SMALL CAP SPECIAL VALUE"
            },
            {
                "value": "FC2Z",
                "label": "Inactive-VCI CORE EQUITY FUND"
            },
            {
                "value": "FC30",
                "label": "MINNESOTA STATE BOARD OF LEGACY ASSET FUND"
            },
            {
                "value": "FC30"
            },
            {
                "value": "FC32",
                "label": "Inactive-GENERAL MOTORS PENSION TRUST COMPANY"
            },
            {
                "value": "FC32"
            },
            {
                "value": "FC33",
                "label": "Inactive-AETNA CASH COLLATERAL PORTFOLIO"
            },
            {
                "value": "FC33"
            },
            {
                "value": "FC34",
                "label": "Inactive-MITSUI"
            },
            {
                "value": "FC34"
            },
            {
                "value": "FC35",
                "label": "Inactive-STATE OF TENNESSEE"
            },
            {
                "value": "FC35"
            },
            {
                "value": "FC36",
                "label": "Inactive-SSGA CASH MANAGEMENT FUND PLC"
            },
            {
                "value": "FC36",
                "label": "SSGA CASH MANAGEMENT FUND PLC"
            },
            {
                "value": "FC37",
                "label": "Inactive-IBM INVESTMENT FUND"
            },
            {
                "value": "FC37"
            },
            {
                "value": "FC39",
                "label": "SAFE COLLATERAL INVESTMENT AC"
            },
            {
                "value": "FC39"
            },
            {
                "value": "FC3D",
                "label": "BRUNEI INVESTMENT AGENCY"
            },
            {
                "value": "FC3E",
                "label": "Inactive-ABERDEEN LIQUIDATING TRUST"
            },
            {
                "value": "FC3F",
                "label": "Inactive-THE ABERDEEN FIXED INCOME FUND POOLED TRUST"
            },
            {
                "value": "FC3G",
                "label": "TREASURER OF THE STATE OF NORTH CAROLINA EQUITY INVESTMENT FUND POOLED TRUST"
            },
            {
                "value": "FC3G"
            },
            {
                "value": "FC3H",
                "label": "TREASURER OF THE STATE OF NC LEGACY ACCOUNT"
            },
            {
                "value": "FC3I",
                "label": "Inactive-NEW STAR INTERNATIONAL EQUITY FUND"
            },
            {
                "value": "FC3J",
                "label": "GOOGLE IRELAND HOLDINGS"
            },
            {
                "value": "FC3J"
            },
            {
                "value": "FC3L",
                "label": "Inactive-THE KANSAS UNIVERSITY ENDOWMENT ASSOCIATION"
            },
            {
                "value": "FC3M",
                "label": "Inactive-THE HONG KONG JOCKEY CLUB"
            },
            {
                "value": "FC3N",
                "label": "KAISER FOUNDATION HOSPITALS"
            },
            {
                "value": "FC3N"
            },
            {
                "value": "FC3P",
                "label": "KAISER FOUNDATION HEALTH PLAN"
            },
            {
                "value": "FC3P"
            },
            {
                "value": "FC3Q",
                "label": "KAISER PERMANENTE GROUP TRUST"
            },
            {
                "value": "FC3Q"
            },
            {
                "value": "FC3R",
                "label": "Inactive-CITY OF PHILADELPHIA"
            },
            {
                "value": "FC3S",
                "label": "FRANCISCAN ALLIANCE"
            },
            {
                "value": "FC3S"
            },
            {
                "value": "FC3U",
                "label": "CITY OF HIALEAH EMPLOYEES' RETIREMENT SYSTEM"
            },
            {
                "value": "FC3U"
            },
            {
                "value": "FC3V",
                "label": "Inactive-AMERICAN AIRLINES INC., MASTER FIXED BENEFIT PENSION TRUST"
            },
            {
                "value": "FC3W",
                "label": "Inactive-AMERICAN AIRLINES INC., PILOTS RETIREMENT BENEFIT PROGRAM VARIABLE INCOME PLAN"
            },
            {
                "value": "FC3X",
                "label": "Inactive-VALUE LINE FUND"
            },
            {
                "value": "FC3Y",
                "label": "WASHINGTON STATE INVESTMENT BOARD"
            },
            {
                "value": "FC3Y"
            },
            {
                "value": "FC41",
                "label": "Inactive-STATE OF FLORIDA"
            },
            {
                "value": "FC41"
            },
            {
                "value": "FC42",
                "label": "Inactive-BILL AND MELINDA GATES FOUNDATION SHORT-TERM INVESTMENT FUND"
            },
            {
                "value": "FC42"
            },
            {
                "value": "FC45",
                "label": "Inactive-HKMA"
            },
            {
                "value": "FC45"
            },
            {
                "value": "FC47",
                "label": "BANK OF KOREA INVESTMENT FUND\n"
            },
            {
                "value": "FC47",
                "label": "THE BANK OF KOREA"
            },
            {
                "value": "FC48",
                "label": "TEACHER RETIREMENT SYSTEM OF TEXAS"
            },
            {
                "value": "FC48"
            },
            {
                "value": "FC49",
                "label": "OHIO PERS TRUST FUND"
            },
            {
                "value": "FC49"
            },
            {
                "value": "FC4A",
                "label": "SLQT DURATION"
            },
            {
                "value": "FC4A"
            },
            {
                "value": "FC4B",
                "label": "Inactive-SSGSLT DURATION"
            },
            {
                "value": "FC4B"
            },
            {
                "value": "FC4D",
                "label": "Inactive-SUPPLEMENTAL RETIREMENT INCOME PLAN OF NORTH CAROLINA"
            },
            {
                "value": "FC4E",
                "label": "Inactive-INVESCO INSTITUTIONAL TRUST INTERNATIONAL EQUITY"
            },
            {
                "value": "FC4E"
            },
            {
                "value": "FC4F",
                "label": "Inactive-INVESCO INSTITUTIONAL TRUST EMERGING MARKET"
            },
            {
                "value": "FC4F"
            },
            {
                "value": "FC4G",
                "label": "Inactive-TRILOGY"
            },
            {
                "value": "FC4H",
                "label": "Inactive-VCI LARGE CAP GROWTH"
            },
            {
                "value": "FC4I",
                "label": "Inactive-BAXTER INTERNATIONAL INC."
            },
            {
                "value": "FC4J",
                "label": "QUALITY D DURATION"
            },
            {
                "value": "FC4J"
            },
            {
                "value": "FC4L",
                "label": "Inactive-VOUGHT AIRCRAFT INDUSTRIES, INC. MASTER DEFINED BENEFIT TRUST"
            },
            {
                "value": "FC4M",
                "label": "Inactive-ICI AMERICAN HOLDINGS"
            },
            {
                "value": "FC4N",
                "label": "Inactive-CHEVRON MASTER PENSION TRUST"
            },
            {
                "value": "FC4N"
            },
            {
                "value": "FC4P",
                "label": "Inactive-INVESCO INSTITUTIONAL RETIREMENT TRUST"
            },
            {
                "value": "FC4P"
            },
            {
                "value": "FC4Q",
                "label": "Inactive-INTERNATIONAL GROUP TRUST I"
            },
            {
                "value": "FC4R",
                "label": "Inactive-VCI MID CAP STRATEGIC GROWTH"
            },
            {
                "value": "FC4U",
                "label": "Inactive-AARGAUISCHE PENSIONSKASSE USD"
            },
            {
                "value": "FC4V",
                "label": "Inactive-BANK OF GHANA"
            },
            {
                "value": "FC4W",
                "label": "TATE AND LYLE CASH COLL ACCT"
            },
            {
                "value": "FC4Y",
                "label": "Inactive-GMAM GROUP PENSION TRUST II"
            },
            {
                "value": "FC4Z",
                "label": "Inactive-GM HR RATE EMPL PENSION TRUST"
            },
            {
                "value": "FC50",
                "label": "SEA 1"
            },
            {
                "value": "FC50"
            },
            {
                "value": "FC51",
                "label": "Inactive-SLQT III"
            },
            {
                "value": "FC51"
            },
            {
                "value": "FC52",
                "label": "Inactive-G.M. WELFARE BENEFIT TRUST"
            },
            {
                "value": "FC52"
            },
            {
                "value": "FC53",
                "label": "Inactive-BOEING"
            },
            {
                "value": "FC53"
            },
            {
                "value": "FC55",
                "label": "Inactive-STICHTING SHELL PENSIOENFOND"
            },
            {
                "value": "FC55",
                "label": "STICHTING SHELL PENSI"
            },
            {
                "value": "FC56",
                "label": "Inactive-CISCO BERMUDA COLLATERAL FUND"
            },
            {
                "value": "FC56"
            },
            {
                "value": "FC57",
                "label": "Inactive-HEWLETT PACKARD MTL"
            },
            {
                "value": "FC57"
            },
            {
                "value": "FC58",
                "label": "Inactive-CENTRAL BANK OF CHINA"
            },
            {
                "value": "FC58"
            },
            {
                "value": "FC5A",
                "label": "Inactive-THE J. PAUL GETTY TRUST"
            },
            {
                "value": "FC5B",
                "label": "Inactive-INOVA HEALTH SYSTEM FOUNDATION"
            },
            {
                "value": "FC5D",
                "label": "Inactive-HENRY LUCE FOUNDATION"
            },
            {
                "value": "FC5E",
                "label": "Inactive-WISCONSIN ALUMNI RESEARCH FOUNDATION"
            },
            {
                "value": "FC5F",
                "label": "Inactive-WELLINGTON MGMT DUBLIN"
            },
            {
                "value": "FC5G",
                "label": "Inactive-STATE OF NEW JERSEY COMMON PENSION FUND A"
            },
            {
                "value": "FC5H",
                "label": "Inactive-STATE OF NEW JERSEY COMMON PENSION FUND B"
            },
            {
                "value": "FC5I",
                "label": "STATE OF NEW JERSEY COMMON PENSION FUND D"
            },
            {
                "value": "FC5I"
            },
            {
                "value": "FC5L",
                "label": "OREGON PUBLIC EMPLOYEES RETIREMENT SYSTEM"
            },
            {
                "value": "FC5L"
            },
            {
                "value": "FC5M",
                "label": "Inactive-TARGET CORPORATION MASTER PENSION TRUST"
            },
            {
                "value": "FC5N",
                "label": "OREGON PERF LEGACY ACCOUNT"
            },
            {
                "value": "FC5V",
                "label": "Inactive-AMERICAN BAR ASSOCIATION MEMBERS COLLECTIVE TRUST"
            },
            {
                "value": "FC5W",
                "label": "Inactive-STITCHING PENSIOENFONDS"
            },
            {
                "value": "FC5X",
                "label": "EDS 401K LEGACY"
            },
            {
                "value": "FC5Y",
                "label": "Inactive-SBCERA"
            },
            {
                "value": "FC5Z",
                "label": "Inactive-UNIVERSAL INVESTMENT FUNDS"
            },
            {
                "value": "FC60",
                "label": "Inactive-STICHTING PENSIOENFONDS ABP"
            },
            {
                "value": "FC60"
            },
            {
                "value": "FC61",
                "label": "Inactive-BIOGEN MATCH TERM LOAN"
            },
            {
                "value": "FC61"
            },
            {
                "value": "FC62",
                "label": "CISCO SWITZERLAND CASH COLLATERAL FUND"
            },
            {
                "value": "FC62"
            },
            {
                "value": "FC63",
                "label": "THE BANK OF KOREA"
            },
            {
                "value": "FC63"
            },
            {
                "value": "FC64",
                "label": "NYSTRS"
            },
            {
                "value": "FC64"
            },
            {
                "value": "FC65",
                "label": "CATHAY LIFE INSURANCE CASH COLLATERAL FUND"
            },
            {
                "value": "FC65"
            },
            {
                "value": "FC66",
                "label": "Inactive-DUPONT SHORT-TERM CASH COLLATERAL FUND"
            },
            {
                "value": "FC66"
            },
            {
                "value": "FC67",
                "label": "GOOGLE INC."
            },
            {
                "value": "FC67"
            },
            {
                "value": "FC68",
                "label": "CREF STOCK ACCOUNT"
            },
            {
                "value": "FC68"
            },
            {
                "value": "FC69",
                "label": "CREF GLOBAL EQUITIES ACCOUNT"
            },
            {
                "value": "FC69"
            },
            {
                "value": "FC6E",
                "label": "Inactive-THE NMR PENSION FUND"
            },
            {
                "value": "FC6E"
            },
            {
                "value": "FC6F",
                "label": "Inactive"
            },
            {
                "value": "FC6F"
            },
            {
                "value": "FC6G",
                "label": "Inactive-ASCENSION HEALTH ACCOUNT"
            },
            {
                "value": "FC6G"
            },
            {
                "value": "FC6H",
                "label": "MASTER PENSION TRUST ACCOUNT"
            },
            {
                "value": "FC6H"
            },
            {
                "value": "FC6I",
                "label": "Inactive"
            },
            {
                "value": "FC6I"
            },
            {
                "value": "FC6J",
                "label": "Inactive"
            },
            {
                "value": "FC6J"
            },
            {
                "value": "FC6L",
                "label": "BOSTON RETIREMENT SYSTEM"
            },
            {
                "value": "FC6L"
            },
            {
                "value": "FC6M",
                "label": "Inactive-MITCHELLS AND BUTLERS CIF LTD"
            },
            {
                "value": "FC6M"
            },
            {
                "value": "FC6N",
                "label": "INTEL CORPORATION"
            },
            {
                "value": "FC6N"
            },
            {
                "value": "FC6P",
                "label": "Minnesota State Board of Investments Legacy Asset Fund"
            },
            {
                "value": "FC6V",
                "label": "Inactive"
            },
            {
                "value": "FC6W",
                "label": "Inactive-EUROPEAN PATENT ORGANISATION"
            },
            {
                "value": "FC70",
                "label": "Inactive-OHIO BWC CASH SL FUND"
            },
            {
                "value": "FC70"
            },
            {
                "value": "FC71",
                "label": "Inactive-KUWAIT INVESTMENT OFFICE"
            },
            {
                "value": "FC71"
            },
            {
                "value": "FC72",
                "label": "Inactive-KOREAN SECURITIES DEPOSITORY"
            },
            {
                "value": "FC72"
            },
            {
                "value": "FC73",
                "label": "DOLPHIN"
            },
            {
                "value": "FC73"
            },
            {
                "value": "FC74",
                "label": "Inactive-FONDO DE GARANTIAS DE INSTITUCIONES FINANCIERAS"
            },
            {
                "value": "FC74"
            },
            {
                "value": "FC75",
                "label": "Inactive-MARIN COUNTY"
            },
            {
                "value": "FC75"
            },
            {
                "value": "FC76",
                "label": "ABBEY LIFE ASSURANCE COMPANY LIMITED"
            },
            {
                "value": "FC76"
            },
            {
                "value": "FC77",
                "label": "Inactive-FRESNO CNTY EMP RETIREMNT ASSOCIATION"
            },
            {
                "value": "FC77"
            },
            {
                "value": "FC78",
                "label": "Inactive"
            },
            {
                "value": "FC78"
            },
            {
                "value": "FC79",
                "label": "ROYCE VALUE TRUST"
            },
            {
                "value": "FC79"
            },
            {
                "value": "FC7E"
            },
            {
                "value": "FC7F"
            },
            {
                "value": "FC7G"
            },
            {
                "value": "FC7J",
                "label": "Inactive-SSCSIL A/C SSGA FI FUNDS PLC L"
            },
            {
                "value": "FC7J"
            },
            {
                "value": "FC7P",
                "label": "Inactive-SSCSIL A/C SSGA FI FUNDS PLC P"
            },
            {
                "value": "FC7P"
            },
            {
                "value": "FC7Q",
                "label": "Inactive"
            },
            {
                "value": "FC7Q"
            },
            {
                "value": "FC7R",
                "label": "Inactive-ARIZONA STATE RETIREMENT SYSTEM"
            },
            {
                "value": "FC7S",
                "label": "ARIZONA STATE RETIREMENT SYSTEM"
            },
            {
                "value": "FC7S"
            },
            {
                "value": "FC7U",
                "label": "Inactive-SERIES SUPER COLLATERAL FUND"
            },
            {
                "value": "FC7U"
            },
            {
                "value": "FC7V",
                "label": "SERIES QUALITY TRUST FOR SSGA FUNDS"
            },
            {
                "value": "FC7V"
            },
            {
                "value": "FC7W",
                "label": "Inactive-SSGA MSCI EAFE INDEX SL FUND"
            },
            {
                "value": "FC7W"
            },
            {
                "value": "FC7X",
                "label": "Inactive-TEACHERS RETIREMENT SYSTEM OF THE STATE OR ILLINOIS"
            },
            {
                "value": "FC7X"
            },
            {
                "value": "FC7Y",
                "label": "Inactive-HP/EDS LEGACY COLLATERAL FUND"
            },
            {
                "value": "FC7Y"
            },
            {
                "value": "FC80",
                "label": "ROYCE PREMIER FUND"
            },
            {
                "value": "FC80",
                "label": "SSGA5CODE1"
            },
            {
                "value": "FC81",
                "label": "ROYCE MICRO CAP FUND"
            },
            {
                "value": "FC81",
                "label": "SSGA5CODE2"
            },
            {
                "value": "FC82",
                "label": "ROYCE MICRO CAP TRUST"
            },
            {
                "value": "FC82"
            },
            {
                "value": "FC83",
                "label": "ROYCE LOW PRICED STOCK FUND"
            },
            {
                "value": "FC83"
            },
            {
                "value": "FC84",
                "label": "ROYCE TOTAL RETURN FUND"
            },
            {
                "value": "FC84"
            },
            {
                "value": "FC85",
                "label": "ROYCE HERITAGE FUND"
            },
            {
                "value": "FC85"
            },
            {
                "value": "FC86",
                "label": "ROYCE OPPORTUNITY FUND"
            },
            {
                "value": "FC86"
            },
            {
                "value": "FC87",
                "label": "ROYCE FOCUS TRUST"
            },
            {
                "value": "FC87"
            },
            {
                "value": "FC88",
                "label": "ROYCE FOCUS TRUST"
            },
            {
                "value": "FC88"
            },
            {
                "value": "FC89",
                "label": "ROYCE VALUE PLUS FUND"
            },
            {
                "value": "FC89"
            },
            {
                "value": "FC8A",
                "label": "STATE OF MARYLAND RETIREMENT"
            },
            {
                "value": "FC8A"
            },
            {
                "value": "FC8B",
                "label": "Inactive"
            },
            {
                "value": "FC8B"
            },
            {
                "value": "FC8D",
                "label": "Inactive"
            },
            {
                "value": "FC8E",
                "label": "Inactive"
            },
            {
                "value": "FC8E"
            },
            {
                "value": "FC8G",
                "label": "Inactive-GM BROADSCOPE MANDATE"
            },
            {
                "value": "FC8G"
            },
            {
                "value": "FC8I",
                "label": "Inactive-PROMARK EMERGING MKT EQUITY FD"
            },
            {
                "value": "FC8I"
            },
            {
                "value": "FC8L",
                "label": "Inactive-PROMARK INT'L EQUITY FUND"
            },
            {
                "value": "FC8L"
            },
            {
                "value": "FC8N",
                "label": "Inactive-PROMARK GTAA FUND"
            },
            {
                "value": "FC8N"
            },
            {
                "value": "FC8Q",
                "label": "Inactive-PROMARK REAL ESTATE SEC FUND"
            },
            {
                "value": "FC8Q"
            },
            {
                "value": "FC8S",
                "label": "Inactive-PROMARK GREATER CHINA FUND"
            },
            {
                "value": "FC8S"
            },
            {
                "value": "FC8V",
                "label": "Inactive-PROMARK GLOBAL EQUITY FUND"
            },
            {
                "value": "FC8V"
            },
            {
                "value": "FC8X",
                "label": "TRS OF THE STATE OF ILLINOIS"
            },
            {
                "value": "FC8X"
            },
            {
                "value": "FC8Y",
                "label": "Inactive-STATE STREET GLOBAL ADVISORS AUSTRALIA SERVICES LIMITED SECURITIES LENDING TRUST"
            },
            {
                "value": "FC8Y"
            },
            {
                "value": "FC8Z",
                "label": "Inactive"
            },
            {
                "value": "FC8Z"
            },
            {
                "value": "FC90",
                "label": "Inactive"
            },
            {
                "value": "FC90"
            },
            {
                "value": "FC91",
                "label": "OREGON SHORT-TERM FUND"
            },
            {
                "value": "FC91"
            },
            {
                "value": "FC92",
                "label": "MORGAN STANLEY SERVICES COMP"
            },
            {
                "value": "FC92"
            },
            {
                "value": "FC93",
                "label": "Inactive"
            },
            {
                "value": "FC93"
            },
            {
                "value": "FC94",
                "label": "Inactive"
            },
            {
                "value": "FC94"
            },
            {
                "value": "FC95",
                "label": "CONSOLIDATED EDISON PENSION MASTER TRUST COLLATERAL FUND"
            },
            {
                "value": "FC95"
            },
            {
                "value": "FC97",
                "label": "Inactive"
            },
            {
                "value": "FC97"
            },
            {
                "value": "FC98",
                "label": "KOREA INVESTMENT CORPORATION"
            },
            {
                "value": "FC98"
            },
            {
                "value": "FC99"
            },
            {
                "value": "FC9A",
                "label": "QUALITY TRUST FOR SSGA FUNDS"
            },
            {
                "value": "FC9A"
            },
            {
                "value": "FC9B",
                "label": "Inactive-SSGA USD ABS TRUST"
            },
            {
                "value": "FC9B"
            },
            {
                "value": "FC9D",
                "label": "QUANTITATIVE GRP FUNDS ECM"
            },
            {
                "value": "FC9D"
            },
            {
                "value": "FC9E",
                "label": "Inactive"
            },
            {
                "value": "FC9E"
            },
            {
                "value": "FC9F",
                "label": "Inactive"
            },
            {
                "value": "FC9F"
            },
            {
                "value": "FC9G",
                "label": "Inactive"
            },
            {
                "value": "FC9G"
            },
            {
                "value": "FC9H",
                "label": "Inactive"
            },
            {
                "value": "FC9H"
            },
            {
                "value": "FC9I",
                "label": "CB CLASSIC VALUE FLEX ECM"
            },
            {
                "value": "FC9I"
            },
            {
                "value": "FC9J",
                "label": "Inactive"
            },
            {
                "value": "FC9J"
            },
            {
                "value": "FC9L",
                "label": "Inactive"
            },
            {
                "value": "FC9L"
            },
            {
                "value": "FC9M",
                "label": "Inactive"
            },
            {
                "value": "FC9M"
            },
            {
                "value": "FC9N",
                "label": "LOCAL GOV PENSIONS INSTITUTION"
            },
            {
                "value": "FC9N"
            },
            {
                "value": "FC9P",
                "label": "Inactive-REGENTS OF THE UOC"
            },
            {
                "value": "FC9P"
            },
            {
                "value": "FC9Q",
                "label": "MSIM INTL MAGNUM TRUST"
            },
            {
                "value": "FC9Q"
            },
            {
                "value": "FC9R",
                "label": "Inactive-DAVIS SELECT COLLATERAL ACCOUNT"
            },
            {
                "value": "FC9R"
            },
            {
                "value": "FC9S",
                "label": "Inactive-SELECTED AMERICAN SHARES COLLATERAL ACCOUNT"
            },
            {
                "value": "FC9S"
            },
            {
                "value": "FC9U",
                "label": "OFFICE OF TREASURY AND FISCAL SERVICES - STATE OF GEORGIA"
            },
            {
                "value": "FC9U"
            },
            {
                "value": "FC9V",
                "label": "Inactive"
            },
            {
                "value": "FC9V"
            },
            {
                "value": "FC9W",
                "label": "THE PUBLIC SCHOOL RETIREMENT SYSTEM OF MISSOURI"
            },
            {
                "value": "FC9W"
            },
            {
                "value": "FC9X",
                "label": "MSIM EMERGING MARKETS TRUST"
            },
            {
                "value": "FC9X"
            },
            {
                "value": "FC9Y",
                "label": "Inactive-GOT FS COLLATERAL FUND"
            },
            {
                "value": "FC9Z",
                "label": "Inactive-GSFIC COLLATERAL FUND"
            },
            {
                "value": "FCBA",
                "label": "Inactive-ACE TEMPEST REINSURANCE LTD"
            },
            {
                "value": "FCBD",
                "label": "Inactive-ACE TEMPEST LIFE REINSURANCE LTD"
            },
            {
                "value": "FCBE",
                "label": "Inactive-ACE BERMUDA INSURANCE LTD"
            },
            {
                "value": "FCBF",
                "label": "Inactive-WESTCHESTER FIRE INSURANCE CO"
            },
            {
                "value": "FCBG",
                "label": "Inactive-INA TRUST, FSB"
            },
            {
                "value": "FCBH",
                "label": "Inactive-WESTCHESTER FIRE INSURANCE CO"
            },
            {
                "value": "FCBL",
                "label": "Inactive-COCA COLA ENTERPRISES"
            },
            {
                "value": "FCBM",
                "label": "Inactive-NATIONAL GRANGE NUTUAL INSURANCE CO"
            },
            {
                "value": "FCBN",
                "label": "Inactive-BEAMTENVERSICHERUNGSKASSE DES KANTONS ZURICH (BVK)"
            },
            {
                "value": "FCBP",
                "label": "Inactive-BLUE CROSS BLUE SHIELD DELAWARE"
            },
            {
                "value": "FCBQ",
                "label": "Inactive-ARIEL REINSURANCE COMPANY LTD"
            },
            {
                "value": "FCBR",
                "label": "Inactive-PROGRESS ENERGY PENSION PLANS MASTER TRUST"
            },
            {
                "value": "FCBS",
                "label": "Inactive-SLBI COLLATERAL FUND"
            },
            {
                "value": "FCBU",
                "label": "Inactive-JOINT INDUSTRY BOARD COLLATERAL ACCOUNT"
            },
            {
                "value": "FCBW",
                "label": "Inactive-RUSSELL INTERNATIONAL SHARES FUND"
            },
            {
                "value": "FCBX",
                "label": "Inactive-RUSSELL INTERNATIONAL BOND FUND"
            },
            {
                "value": "FCBY",
                "label": "Inactive-RUSSELL GLOBAL OPPORTUNITIES FUND"
            },
            {
                "value": "FCBZ",
                "label": "Inactive-RUSSELL INTERNATIONAL PROPERTY SECURITIES FUND A$ HEDGED"
            },
            {
                "value": "FCQV",
                "label": "STATE STREET NAVIGATOR SECURITIES LENDING MET PORTFOLIO"
            },
            {
                "value": "FCQV"
            },
            {
                "value": "FCQW",
                "label": "Inactive-CITY OF KNOXVILLE PENSION BOARD"
            },
            {
                "value": "FCQX",
                "label": "FRESNO COUNTY EMPLOYEES' RETIREMENT ASSOCIATION"
            },
            {
                "value": "FCQX"
            },
            {
                "value": "FCQY",
                "label": "MSIM - UST MONEY FUND COLLATERAL FUND"
            },
            {
                "value": "FCQZ",
                "label": "THE DFA GROUP TRUST COLLATERAL ACCOUNT"
            },
            {
                "value": "FED ",
                "label": "Inactive"
            },
            {
                "value": "FGOF",
                "label": "GOF FOR ROYCE"
            },
            {
                "value": "FGOF"
            },
            {
                "value": "FHAS"
            },
            {
                "value": "FHAU",
                "label": "Inactive-HELVETIA SWISS LIFE INSURANCE COMPANY LTD"
            },
            {
                "value": "FHAU"
            },
            {
                "value": "FHAV",
                "label": "Inactive"
            },
            {
                "value": "FHAV"
            },
            {
                "value": "FHAW",
                "label": "Inactive"
            },
            {
                "value": "FHAW"
            },
            {
                "value": "FHAX",
                "label": "Inactive-SSCSIL A/C SSGA FI FUNDS PLC L"
            },
            {
                "value": "FHAY",
                "label": "Inactive-ARIZONA EURO LEGACY"
            },
            {
                "value": "FHAZ"
            },
            {
                "value": "FHBA",
                "label": "Inactive-ASRS EURO COMPOSITE"
            },
            {
                "value": "FHBA"
            },
            {
                "value": "FHBF",
                "label": "BANK OF ESTONIA - EUR"
            },
            {
                "value": "FHBF"
            },
            {
                "value": "FHBG",
                "label": "Inactive-LLOYDS TSB GROUP PENSION TRUST (NO.1)  LIMITED"
            },
            {
                "value": "FHBG"
            },
            {
                "value": "FHBH",
                "label": "Inactive-LLOYDS TSB GROUP PENSION TRUST (NO.2)  LIMITED"
            },
            {
                "value": "FHBH"
            },
            {
                "value": "FHBJ",
                "label": "KOREA INVESTMENT COMPANY"
            },
            {
                "value": "FHBJ"
            },
            {
                "value": "FHBL",
                "label": "Inactive-MITCHELLS& BUTLERS CIF LTD-EUR"
            },
            {
                "value": "FHBL"
            },
            {
                "value": "FHBM",
                "label": "Inactive"
            },
            {
                "value": "FHBN",
                "label": "ACE EUROPEAN GROUP LIMITED"
            },
            {
                "value": "FHBN"
            },
            {
                "value": "FHBP",
                "label": "ACE TEMPEST  REINSURANCE LTD."
            },
            {
                "value": "FHBP"
            },
            {
                "value": "FHBQ",
                "label": "BP PENSION TRUSTEES LIMITED"
            },
            {
                "value": "FHBR",
                "label": "STICHTING PENSIONF VOOR WONING"
            },
            {
                "value": "FIN1"
            },
            {
                "value": "FIN3"
            },
            {
                "value": "FRRU",
                "label": "Inactive-FRANK RUSSELL"
            },
            {
                "value": "FRRU"
            },
            {
                "value": "FRUS",
                "label": "Inactive-FRANK RUSSELL EMEA - VARIOUS"
            },
            {
                "value": "FRUS"
            },
            {
                "value": "FS1A"
            },
            {
                "value": "FTHR",
                "label": "Inactive-FIFTH THIRD"
            },
            {
                "value": "FUND",
                "label": "FUND PARTNERS LIMITED"
            },
            {
                "value": "FUND"
            },
            {
                "value": "GCCL",
                "label": "GLOBAL CUSTODY & Clearing LTD"
            },
            {
                "value": "GLNB",
                "label": "GLENVIEW GLNB"
            },
            {
                "value": "GLNB"
            },
            {
                "value": "GLNF",
                "label": "GLENVIEW GLNF"
            },
            {
                "value": "GLNF"
            },
            {
                "value": "GOPE",
                "label": "Inactive-GOVERNMENT PENSION FUND"
            },
            {
                "value": "GOPE"
            },
            {
                "value": "GOPF",
                "label": "Inactive-GOVERNMENT PENSION FUND"
            },
            {
                "value": "GOPF"
            },
            {
                "value": "GP15",
                "label": "Inactive-MINNESOTA STATE BOARD OF INVT"
            },
            {
                "value": "GP60",
                "label": "Inactive-MINNESOTA STATE BOARD OF INVMT"
            },
            {
                "value": "GSIC",
                "label": "Inactive"
            },
            {
                "value": "GSIC"
            },
            {
                "value": "GSIE",
                "label": "Inactive"
            },
            {
                "value": "GSIE"
            },
            {
                "value": "GSLT",
                "label": "Inactive"
            },
            {
                "value": "GSTF",
                "label": "Inactive"
            },
            {
                "value": "GVXX",
                "label": "US GOVT MM FUND OGVXX"
            },
            {
                "value": "GVXX"
            },
            {
                "value": "HARV",
                "label": "Inactive"
            },
            {
                "value": "HERE",
                "label": "IFDS HENDERSON ROWE INDEX FUND"
            },
            {
                "value": "HERE"
            },
            {
                "value": "HERU",
                "label": "IFDS HENDERSON ROWE INDEX FUND"
            },
            {
                "value": "HERU"
            },
            {
                "value": "HKFZ",
                "label": "Inactive-HALLIBURTON POOLED PENSION FUND"
            },
            {
                "value": "HLBE",
                "label": "Inactive-HALLIBURTON SSGA LIQUIDITY EUR"
            },
            {
                "value": "HLBG",
                "label": "Inactive-HALLIBURTON SSGA LIQUIDITY GBP"
            },
            {
                "value": "HLBU",
                "label": "Inactive-HALLIBURTON SSGA LIQUIDITY"
            },
            {
                "value": "HMAA",
                "label": "Inactive-MAVERICK FUND II, LTD AGENCY"
            },
            {
                "value": "HMAA"
            },
            {
                "value": "HMAB",
                "label": "Inactive-MAVERICK FUND II, LTD FINANCE"
            },
            {
                "value": "HMR1",
                "label": "Inactive-MAVERICK FUND L.D.C. (ECM)"
            },
            {
                "value": "HMRA",
                "label": "Inactive-MAVERICK LNG ENHANCED FINANCE"
            },
            {
                "value": "HMRB",
                "label": "Inactive-MAVERICK FUND USA, LTD FINANCE"
            },
            {
                "value": "HMRD",
                "label": "Inactive-MAVERICK NEUT LEVERED FINANCE"
            },
            {
                "value": "HMRE",
                "label": "Inactive-MAVERICK NEUTRAL FUND FINANCE"
            },
            {
                "value": "HMRU",
                "label": "MAVERICK FUND LDC"
            },
            {
                "value": "HMRU"
            },
            {
                "value": "HMSS",
                "label": "Inactive-MAVERICK LNG ENHANCED AGENCY"
            },
            {
                "value": "HMSS"
            },
            {
                "value": "HMUU",
                "label": "Inactive-MAVERICK NEUT LEVERED AGENCY"
            },
            {
                "value": "HMUU"
            },
            {
                "value": "HMVV",
                "label": "Inactive-MAVERICK NEUTRAL FUND AGENCY"
            },
            {
                "value": "HMVV"
            },
            {
                "value": "HPTE",
                "label": "Inactive-HEWLETT PACKARD TRUST E.V (UNIVERSAL)"
            },
            {
                "value": "IARP"
            },
            {
                "value": "IBM ",
                "label": "Inactive"
            },
            {
                "value": "IBM "
            },
            {
                "value": "IBT1",
                "label": "Inactive-IBT ASSETS"
            },
            {
                "value": "IDAF",
                "label": "Inactive"
            },
            {
                "value": "IE3A",
                "label": "Inactive"
            },
            {
                "value": "IE3A"
            },
            {
                "value": "IE3B",
                "label": "Inactive"
            },
            {
                "value": "IE3B"
            },
            {
                "value": "IE3F",
                "label": "Inactive"
            },
            {
                "value": "IE3F"
            },
            {
                "value": "IE3G",
                "label": "Inactive"
            },
            {
                "value": "IE3G"
            },
            {
                "value": "IFAD",
                "label": "Inactive"
            },
            {
                "value": "IFME",
                "label": "Inactive-INVESTEC FUNDS SERIES III - GLOBAL FUND EUR"
            },
            {
                "value": "IFME"
            },
            {
                "value": "IFMG",
                "label": "Inactive-INVESTEC FUNDS SERIES III - GLOBAL FUND GBP"
            },
            {
                "value": "IFMG"
            },
            {
                "value": "IFMU",
                "label": "Inactive-INVESTEC FUNDS SERIES III - GLOBAL FUND USD"
            },
            {
                "value": "IFMU"
            },
            {
                "value": "IGAE",
                "label": "Inactive-INVESTMENT GRADE CORPORATE BOND FUND"
            },
            {
                "value": "IGAE"
            },
            {
                "value": "IGAG",
                "label": "Inactive-INVESTMENT GRADE CORPORATE BOND FUND"
            },
            {
                "value": "IGAG"
            },
            {
                "value": "IGAU",
                "label": "Inactive-INVESTMENT GRADE CORPORATE BOND FUND"
            },
            {
                "value": "IGAU"
            },
            {
                "value": "IGBE",
                "label": "Inactive-UK EQUITY FUND"
            },
            {
                "value": "IGBE"
            },
            {
                "value": "IGBG",
                "label": "Inactive-UK EQUITY FUND"
            },
            {
                "value": "IGBG"
            },
            {
                "value": "IGBU",
                "label": "Inactive-UK EQUITY FUND"
            },
            {
                "value": "IGBU"
            },
            {
                "value": "IGCE",
                "label": "Inactive-AMERICAN EQUITY FUND"
            },
            {
                "value": "IGCE"
            },
            {
                "value": "IGCG",
                "label": "Inactive-AMERICAN EQUITY FUND"
            },
            {
                "value": "IGCU",
                "label": "Inactive-AMERICAN EQUITY FUND"
            },
            {
                "value": "IGCU"
            },
            {
                "value": "IGDE",
                "label": "Inactive-ASIAN EQUITY FUND"
            },
            {
                "value": "IGDE"
            },
            {
                "value": "IGDG",
                "label": "Inactive-ASIAN EQUITY FUND"
            },
            {
                "value": "IGDG"
            },
            {
                "value": "IGDU",
                "label": "Inactive-ASIAN EQUITY FUND"
            },
            {
                "value": "IGDU"
            },
            {
                "value": "IGEE",
                "label": "Inactive-EUROPEAN EQUITY FUND"
            },
            {
                "value": "IGEE"
            },
            {
                "value": "IGEG",
                "label": "Inactive-EUROPEAN EQUITY FUND"
            },
            {
                "value": "IGEG"
            },
            {
                "value": "IGEU",
                "label": "Inactive-EUROPEAN EQUITY FUND"
            },
            {
                "value": "IGEU"
            },
            {
                "value": "IGFE",
                "label": "Inactive-HIGH INCOME BOND FUND"
            },
            {
                "value": "IGFE"
            },
            {
                "value": "IGFG",
                "label": "Inactive-HIGH INCOME BOND FUND"
            },
            {
                "value": "IGFG"
            },
            {
                "value": "IGFU",
                "label": "Inactive-HIGH INCOME BOND FUND"
            },
            {
                "value": "IGFU"
            },
            {
                "value": "IGGE",
                "label": "Inactive-GLOBAL STRATEGIC MANAGED FUND"
            },
            {
                "value": "IGGG",
                "label": "Inactive-GLOBAL STRATEGIC MANAGED FUND"
            },
            {
                "value": "IGGU",
                "label": "Inactive-GLOBAL STRATEGIC MANAGED FUND"
            },
            {
                "value": "IGHE",
                "label": "Inactive-GLOBAL BOND FUND"
            },
            {
                "value": "IGHE"
            },
            {
                "value": "IGHG",
                "label": "Inactive-GLOBAL BOND FUND"
            },
            {
                "value": "IGHG"
            },
            {
                "value": "IGHU",
                "label": "Inactive-GLOBAL BOND FUND"
            },
            {
                "value": "IGHU"
            },
            {
                "value": "IGIE",
                "label": "Inactive-GLOBAL ENERGY FUND"
            },
            {
                "value": "IGIE"
            },
            {
                "value": "IGIG",
                "label": "Inactive-GLOBAL ENERGY FUND"
            },
            {
                "value": "IGIG"
            },
            {
                "value": "IGIU",
                "label": "Inactive-GLOBAL ENERGY FUND"
            },
            {
                "value": "IGIU"
            },
            {
                "value": "IGJE",
                "label": "Inactive-GLOBAL EQUITY FUND"
            },
            {
                "value": "IGJE"
            },
            {
                "value": "IGJG",
                "label": "Inactive-GLOBAL EQUITY FUND"
            },
            {
                "value": "IGJG"
            },
            {
                "value": "IGJU",
                "label": "Inactive-GLOBAL EQUITY FUND"
            },
            {
                "value": "IGJU"
            },
            {
                "value": "IGKE",
                "label": "Inactive-GLOBAL GOLD FUND"
            },
            {
                "value": "IGKE"
            },
            {
                "value": "IGKG",
                "label": "Inactive-GLOBAL GOLD FUND"
            },
            {
                "value": "IGKG"
            },
            {
                "value": "IGKU",
                "label": "Inactive-GLOBAL GOLD FUND"
            },
            {
                "value": "IGKU"
            },
            {
                "value": "IGLE",
                "label": "Inactive-GLOBAL STRATEGIC INCOME FUND"
            },
            {
                "value": "IGLE"
            },
            {
                "value": "IGLG",
                "label": "Inactive-GLOBAL STRATEGIC INCOME FUND"
            },
            {
                "value": "IGLG"
            },
            {
                "value": "IGLU",
                "label": "Inactive-GLOBAL STRATEGIC INCOME FUND"
            },
            {
                "value": "IGLU"
            },
            {
                "value": "IGME",
                "label": "Inactive-GLOBAL STRATEGIC EQUITY FUND"
            },
            {
                "value": "IGME"
            },
            {
                "value": "IGMG",
                "label": "Inactive-GLOBAL STRATEGIC EQUITY FUND"
            },
            {
                "value": "IGMG"
            },
            {
                "value": "IGMU",
                "label": "Inactive-GLOBAL STRATEGIC EQUITY FUND"
            },
            {
                "value": "IGMU"
            },
            {
                "value": "IGNE",
                "label": "Inactive-GLOBAL DYNAMIC FUND"
            },
            {
                "value": "IGNE"
            },
            {
                "value": "IGNG",
                "label": "Inactive-GLOBAL DYNAMIC FUND"
            },
            {
                "value": "IGNG"
            },
            {
                "value": "IGNU",
                "label": "Inactive-GLOBAL DYNAMIC FUND"
            },
            {
                "value": "IGNU"
            },
            {
                "value": "IGOE",
                "label": "Inactive-EAFE FUND"
            },
            {
                "value": "IGOG",
                "label": "Inactive-EAFE FUND"
            },
            {
                "value": "IGOU",
                "label": "Inactive-EAFE FUND"
            },
            {
                "value": "IGPE",
                "label": "Inactive-GLOBAL NATURAL RESOURCES FUND"
            },
            {
                "value": "IGPE"
            },
            {
                "value": "IGPG",
                "label": "Inactive-GLOBAL NATURAL RESOURCES FUND"
            },
            {
                "value": "IGPG"
            },
            {
                "value": "IGPU",
                "label": "Inactive-GLOBAL NATURAL RESOURCES FUND"
            },
            {
                "value": "IGPU"
            },
            {
                "value": "IGQE",
                "label": "Inactive-EMERGING MARKETS LOCAL CURRENCY DEBT FUND"
            },
            {
                "value": "IGQE"
            },
            {
                "value": "IGQG",
                "label": "Inactive-EMERGING MARKETS LOCAL CURRENCY DEBT FUND"
            },
            {
                "value": "IGQG"
            },
            {
                "value": "IGQU",
                "label": "Inactive-EMERGING MARKETS LOCAL CURRENCY DEBT FUND"
            },
            {
                "value": "IGQU"
            },
            {
                "value": "IGRE",
                "label": "Inactive-GLOBAL FRANCHISE FUND"
            },
            {
                "value": "IGRE"
            },
            {
                "value": "IGRG",
                "label": "Inactive-GLOBAL FRANCHISE FUND"
            },
            {
                "value": "IGRG"
            },
            {
                "value": "IGRU",
                "label": "Inactive-GLOBAL FRANCHISE FUND"
            },
            {
                "value": "IGRU"
            },
            {
                "value": "IGSE",
                "label": "Inactive-INVESTEC GLOBAL STRATEGY EUR"
            },
            {
                "value": "IGSE"
            },
            {
                "value": "IGSG",
                "label": "Inactive-INVESTEC GLOBAL STRATEGY GBP"
            },
            {
                "value": "IGSU",
                "label": "Inactive-ENHANCED GLOBAL ENERGY FUND"
            },
            {
                "value": "IGSU"
            },
            {
                "value": "IGTE",
                "label": "Inactive-ENHANCED NATURAL RESOURCES FUND"
            },
            {
                "value": "IGTE"
            },
            {
                "value": "IGTG",
                "label": "Inactive-ENHANCED NATURAL RESOURCES FUND"
            },
            {
                "value": "IGTG"
            },
            {
                "value": "IGTU",
                "label": "Inactive-ENHANCED NATURAL RESOURCES FUND"
            },
            {
                "value": "IGTU"
            },
            {
                "value": "IGUE",
                "label": "Inactive-EMERGING MARKETS CURRENCY ALPHA FUND"
            },
            {
                "value": "IGUE"
            },
            {
                "value": "IGUG",
                "label": "Inactive-EMERGING MARKETS CURRENCY ALPHA FUND"
            },
            {
                "value": "IGUG"
            },
            {
                "value": "IGUU",
                "label": "Inactive-EMERGING MARKETS CURRENCY ALPHA FUND"
            },
            {
                "value": "IGUU"
            },
            {
                "value": "IGVE",
                "label": "Inactive-LATIN AMERICAN EQUITY FUND"
            },
            {
                "value": "IGVE"
            },
            {
                "value": "IGVG",
                "label": "Inactive-LATIN AMERICAN EQUITY FUND"
            },
            {
                "value": "IGVG"
            },
            {
                "value": "IGVU",
                "label": "Inactive-LATIN AMERICAN EQUITY FUND"
            },
            {
                "value": "IGVU"
            },
            {
                "value": "IGWE",
                "label": "Inactive-LATIN AMERICAN CORPORATE DEBT FUND"
            },
            {
                "value": "IGWE"
            },
            {
                "value": "IGWG",
                "label": "Inactive-LATIN AMERICAN CORPORATE DEBT FUND"
            },
            {
                "value": "IGWG"
            },
            {
                "value": "IGWU",
                "label": "Inactive-LATIN AMERICAN CORPORATE DEBT FUND"
            },
            {
                "value": "IGWU"
            },
            {
                "value": "IGXE",
                "label": "Inactive-ASIA PACIFIC EQUITY FUND"
            },
            {
                "value": "IGXE"
            },
            {
                "value": "IGXG",
                "label": "Inactive-ASIA PACIFIC EQUITY FUND"
            },
            {
                "value": "IGXG"
            },
            {
                "value": "IGXU",
                "label": "Inactive-ASIA PACIFIC EQUITY FUND"
            },
            {
                "value": "IGXU"
            },
            {
                "value": "IGYE",
                "label": "Inactive-EMERGING MARKETS BLENDED DEBT FUND"
            },
            {
                "value": "IGYE"
            },
            {
                "value": "IGYG",
                "label": "Inactive-EMERGING MARKETS BLENDED DEBT FUND"
            },
            {
                "value": "IGYG"
            },
            {
                "value": "IGYU",
                "label": "Inactive-EMERGING MARKETS BLENDED DEBT FUND"
            },
            {
                "value": "IGYU"
            },
            {
                "value": "IGZE",
                "label": "Inactive-GLOBAL OPPORTUNITY EQUITY FUND"
            },
            {
                "value": "IGZE"
            },
            {
                "value": "IGZG",
                "label": "Inactive-GLOBAL OPPORTUNITY EQUITY FUND"
            },
            {
                "value": "IGZG"
            },
            {
                "value": "IGZU",
                "label": "Inactive-GLOBAL OPPORTUNITY EQUITY FUND"
            },
            {
                "value": "IGZU"
            },
            {
                "value": "ILTA",
                "label": "Inactive-TRS OF ILLINOIS FINANCE"
            },
            {
                "value": "IMAE",
                "label": "Inactive-UK SPECIAL SITUATIONS FUND"
            },
            {
                "value": "IMAE"
            },
            {
                "value": "IMAG",
                "label": "Inactive-UK SPECIAL SITUATIONS FUND"
            },
            {
                "value": "IMAG"
            },
            {
                "value": "IMAU",
                "label": "Inactive-UK SPECIAL SITUATIONS FUND"
            },
            {
                "value": "IMAU"
            },
            {
                "value": "IMBE",
                "label": "Inactive-MANAGED GROWTH FUND"
            },
            {
                "value": "IMBE"
            },
            {
                "value": "IMBG",
                "label": "Inactive-MANAGED GROWTH FUND"
            },
            {
                "value": "IMBG"
            },
            {
                "value": "IMBU",
                "label": "Inactive-MANAGED GROWTH FUND"
            },
            {
                "value": "IMBU"
            },
            {
                "value": "IMCE",
                "label": "Inactive-ENHANCED NATURAL RESOURCES FUND"
            },
            {
                "value": "IMCE"
            },
            {
                "value": "IMCG",
                "label": "Inactive-ENHANCED NATURAL RESOURCES FUND"
            },
            {
                "value": "IMCG"
            },
            {
                "value": "IMCU",
                "label": "Inactive-ENHANCED NATURAL RESOURCES FUND"
            },
            {
                "value": "IMCU"
            },
            {
                "value": "IMDE",
                "label": "Inactive-AMERICAN FUND"
            },
            {
                "value": "IMDE"
            },
            {
                "value": "IMDG",
                "label": "Inactive-AMERICAN FUND"
            },
            {
                "value": "IMDU",
                "label": "Inactive-AMERICAN FUND"
            },
            {
                "value": "IMDU"
            },
            {
                "value": "IMEE",
                "label": "Inactive-GLOBAL FREE ENTERPRISE FUND"
            },
            {
                "value": "IMEE"
            },
            {
                "value": "IMEG",
                "label": "Inactive-GLOBAL FREE ENTERPRISE FUND"
            },
            {
                "value": "IMEG"
            },
            {
                "value": "IMEU",
                "label": "Inactive-GLOBAL FREE ENTERPRISE FUND"
            },
            {
                "value": "IMEU"
            },
            {
                "value": "IMFE",
                "label": "Inactive-ASIA EX JAPAN FUND"
            },
            {
                "value": "IMFE"
            },
            {
                "value": "IMFG",
                "label": "Inactive-ASIA EX JAPAN FUND"
            },
            {
                "value": "IMFG"
            },
            {
                "value": "IMFU",
                "label": "Inactive-ASIA EX JAPAN FUND"
            },
            {
                "value": "IMFU"
            },
            {
                "value": "IMGE",
                "label": "Inactive-MONTHLY HIGH INCOME FUND"
            },
            {
                "value": "IMGE"
            },
            {
                "value": "IMGG",
                "label": "Inactive-MONTHLY HIGH INCOME FUND"
            },
            {
                "value": "IMGG"
            },
            {
                "value": "IMGU",
                "label": "Inactive-MONTHLY HIGH INCOME FUND"
            },
            {
                "value": "IMGU"
            },
            {
                "value": "IMHE",
                "label": "Inactive-GLOBAL ENERGY FUND"
            },
            {
                "value": "IMHE"
            },
            {
                "value": "IMHG",
                "label": "Inactive-GLOBAL ENERGY FUND"
            },
            {
                "value": "IMHG"
            },
            {
                "value": "IMHU",
                "label": "Inactive-GLOBAL ENERGY FUND"
            },
            {
                "value": "IMHU"
            },
            {
                "value": "IMIE",
                "label": "Inactive-GLOBAL BOND FUND"
            },
            {
                "value": "IMIE"
            },
            {
                "value": "IMIG",
                "label": "Inactive-GLOBAL BOND FUND"
            },
            {
                "value": "IMIG"
            },
            {
                "value": "IMIU",
                "label": "Inactive-GLOBAL BOND FUND"
            },
            {
                "value": "IMIU"
            },
            {
                "value": "IMJE",
                "label": "Inactive-GLOBAL EQUITY FUND"
            },
            {
                "value": "IMJE"
            },
            {
                "value": "IMJG",
                "label": "Inactive-GLOBAL EQUITY FUND"
            },
            {
                "value": "IMJG"
            },
            {
                "value": "IMJU",
                "label": "Inactive-GLOBAL EQUITY FUND"
            },
            {
                "value": "IMJU"
            },
            {
                "value": "IMKE",
                "label": "Inactive-GLOBAL DYNAMIC FUND"
            },
            {
                "value": "IMKE"
            },
            {
                "value": "IMKG",
                "label": "Inactive-GLOBAL DYNAMIC FUND"
            },
            {
                "value": "IMKG"
            },
            {
                "value": "IMKU",
                "label": "Inactive-GLOBAL DYNAMIC FUND"
            },
            {
                "value": "IMKU"
            },
            {
                "value": "IMLE",
                "label": "Inactive-INVESTEC FUND MANAGERS LTD EUR"
            },
            {
                "value": "IMLG",
                "label": "Inactive-INVESTEC FUND MANAGERS LTD GBP"
            },
            {
                "value": "IMLU",
                "label": "Inactive-GLOBAL GOLD FUND"
            },
            {
                "value": "IMLU"
            },
            {
                "value": "IMME",
                "label": "Inactive-EMERGING MARKETS LOCAL CURRENCY DEBT FUND"
            },
            {
                "value": "IMME"
            },
            {
                "value": "IMMG",
                "label": "Inactive-EMERGING MARKETS LOCAL CURRENCY DEBT FUND"
            },
            {
                "value": "IMMG"
            },
            {
                "value": "IMMU",
                "label": "Inactive-EMERGING MARKETS LOCAL CURRENCY DEBT FUND"
            },
            {
                "value": "IMMU"
            },
            {
                "value": "IMNE",
                "label": "Inactive-DIVERSIFIED GROWTH FUND"
            },
            {
                "value": "IMNE"
            },
            {
                "value": "IMNG",
                "label": "Inactive-DIVERSIFIED GROWTH FUND"
            },
            {
                "value": "IMNG"
            },
            {
                "value": "IMNU",
                "label": "Inactive-DIVERSIFIED GROWTH FUND"
            },
            {
                "value": "IMNU"
            },
            {
                "value": "IMOE",
                "label": "Inactive-TARGET RETURN FUND"
            },
            {
                "value": "IMOE"
            },
            {
                "value": "IMOG",
                "label": "Inactive-TARGET RETURN FUND"
            },
            {
                "value": "IMOG"
            },
            {
                "value": "IMOU",
                "label": "Inactive-TARGET RETURN FUND"
            },
            {
                "value": "IMOU"
            },
            {
                "value": "IMPE",
                "label": "Inactive-CAPITAL ACCUMULATOR FUND"
            },
            {
                "value": "IMPE"
            },
            {
                "value": "IMPG",
                "label": "Inactive-CAPITAL ACCUMULATOR FUND"
            },
            {
                "value": "IMPG"
            },
            {
                "value": "IMPU",
                "label": "Inactive-CAPITAL ACCUMULATOR FUND"
            },
            {
                "value": "IMPU"
            },
            {
                "value": "IMQE",
                "label": "Inactive-GLOBAL SPECIAL SITUATIONS FUND"
            },
            {
                "value": "IMQE"
            },
            {
                "value": "IMQG",
                "label": "Inactive-GLOBAL SPECIAL SITUATIONS FUND"
            },
            {
                "value": "IMQG"
            },
            {
                "value": "IMQU",
                "label": "Inactive-GLOBAL SPECIAL SITUATIONS FUND"
            },
            {
                "value": "IMQU"
            },
            {
                "value": "IMRE",
                "label": "Inactive-MULTI ASSET PROTECTOR FUND"
            },
            {
                "value": "IMRE"
            },
            {
                "value": "IMRG",
                "label": "Inactive-MULTI ASSET PROTECTOR FUND"
            },
            {
                "value": "IMRG"
            },
            {
                "value": "IMRU",
                "label": "Inactive-MULTI ASSET PROTECTOR FUND"
            },
            {
                "value": "IMRU"
            },
            {
                "value": "IMSE",
                "label": "Inactive-MULTI ASSET PROTECTOR 2 FUND"
            },
            {
                "value": "IMSE"
            },
            {
                "value": "IMSG",
                "label": "Inactive-MULTI ASSET PROTECTOR 2 FUND"
            },
            {
                "value": "IMSG"
            },
            {
                "value": "IMSU",
                "label": "Inactive-MULTI ASSET PROTECTOR 2 FUND"
            },
            {
                "value": "IMSU"
            },
            {
                "value": "IMTE",
                "label": "Inactive-EMERGING MARKETS BLENDED DEBT FUND"
            },
            {
                "value": "IMTE"
            },
            {
                "value": "IMTG",
                "label": "Inactive-EMERGING MARKETS BLENDED DEBT FUND"
            },
            {
                "value": "IMTG"
            },
            {
                "value": "IMTU",
                "label": "Inactive-EMERGING MARKETS BLENDED DEBT FUND"
            },
            {
                "value": "IMTU"
            },
            {
                "value": "IMUE",
                "label": "Inactive-EMERGING MARKETS EQUITY FUND"
            },
            {
                "value": "IMUE"
            },
            {
                "value": "IMUG",
                "label": "Inactive-EMERGING MARKETS EQUITY FUND"
            },
            {
                "value": "IMUG"
            },
            {
                "value": "IMUU",
                "label": "Inactive-EMERGING MARKETS EQUITY FUND"
            },
            {
                "value": "IMUU"
            },
            {
                "value": "IMVE",
                "label": "Inactive-GLOBAL FRANCHISE FUND"
            },
            {
                "value": "IMVE"
            },
            {
                "value": "IMVG",
                "label": "Inactive-GLOBAL FRANCHISE FUND"
            },
            {
                "value": "IMVG"
            },
            {
                "value": "IMVU",
                "label": "Inactive-GLOBAL FRANCHISE FUND"
            },
            {
                "value": "IMVU"
            },
            {
                "value": "IMWE",
                "label": "Inactive-SHORT DATED BOND FUND"
            },
            {
                "value": "IMWE"
            },
            {
                "value": "IMWG",
                "label": "Inactive-SHORT DATED BOND FUND"
            },
            {
                "value": "IMWG"
            },
            {
                "value": "IMWU",
                "label": "Inactive-SHORT DATED BOND FUND"
            },
            {
                "value": "IMWU"
            },
            {
                "value": "INAE",
                "label": "Inactive-GLOBAL DIVERSIFIED INCOME FUND"
            },
            {
                "value": "INAE"
            },
            {
                "value": "INAG",
                "label": "Inactive-GLOBAL DIVERSIFIED INCOME FUND"
            },
            {
                "value": "INAG"
            },
            {
                "value": "INAU",
                "label": "Inactive-GLOBAL DIVERSIFIED INCOME FUND"
            },
            {
                "value": "INAU"
            },
            {
                "value": "INBE",
                "label": "Inactive-EMERGING MARKETS CURRENCY FUND"
            },
            {
                "value": "INBE"
            },
            {
                "value": "INBG",
                "label": "Inactive-EMERGING MARKETS CURRENCY FUND"
            },
            {
                "value": "INBG"
            },
            {
                "value": "INBU",
                "label": "Inactive-EMERGING MARKETS CURRENCY FUND"
            },
            {
                "value": "INBU"
            },
            {
                "value": "INCE",
                "label": "Inactive-EMERGING MARKETS LOCAL CURRENCY DYNAMIC DEBT FUND"
            },
            {
                "value": "INCE"
            },
            {
                "value": "INCG",
                "label": "Inactive-EMERGING MARKETS LOCAL CURRENCY DYNAMIC DEBT FUND"
            },
            {
                "value": "INCG"
            },
            {
                "value": "INCU",
                "label": "Inactive-EMERGING MARKETS LOCAL CURRENCY DYNAMIC DEBT FUND"
            },
            {
                "value": "INCU"
            },
            {
                "value": "INDB",
                "label": "INVESCO DUBLIN"
            },
            {
                "value": "INDB"
            },
            {
                "value": "INDE",
                "label": "INVESCO DUBLIN EUR"
            },
            {
                "value": "INDE"
            },
            {
                "value": "INDG",
                "label": "Inactive"
            },
            {
                "value": "INDG"
            },
            {
                "value": "INDU",
                "label": "Inactive"
            },
            {
                "value": "INDU"
            },
            {
                "value": "INEE",
                "label": "Inactive-AFRICA HIGH INCOME FUND"
            },
            {
                "value": "INEG",
                "label": "Inactive-AFRICA HIGH INCOME FUND"
            },
            {
                "value": "INEU",
                "label": "Inactive-AFRICA HIGH INCOME FUND"
            },
            {
                "value": "INFE",
                "label": "Inactive"
            },
            {
                "value": "INFE"
            },
            {
                "value": "INFG",
                "label": "Inactive"
            },
            {
                "value": "INFG"
            },
            {
                "value": "INFU",
                "label": "Inactive"
            },
            {
                "value": "INFU"
            },
            {
                "value": "INGE",
                "label": "Inactive-EURO MONEY FUND"
            },
            {
                "value": "INGE"
            },
            {
                "value": "INGG",
                "label": "Inactive-EURO MONEY FUND"
            },
            {
                "value": "INGG"
            },
            {
                "value": "INGU",
                "label": "Inactive-EURO MONEY FUND"
            },
            {
                "value": "INGU"
            },
            {
                "value": "INHE",
                "label": "Inactive-STERLING MONEY FUND"
            },
            {
                "value": "INHE"
            },
            {
                "value": "INHG",
                "label": "Inactive-STERLING MONEY FUND"
            },
            {
                "value": "INHG"
            },
            {
                "value": "INHU",
                "label": "Inactive-STERLING MONEY FUND"
            },
            {
                "value": "INHU"
            },
            {
                "value": "INIE",
                "label": "Inactive-MANAGED CURRENCY FUND"
            },
            {
                "value": "INIE"
            },
            {
                "value": "INIG",
                "label": "Inactive-MANAGED CURRENCY FUND"
            },
            {
                "value": "INIG"
            },
            {
                "value": "INIU",
                "label": "Inactive-MANAGED CURRENCY FUND"
            },
            {
                "value": "INIU"
            },
            {
                "value": "INJE",
                "label": "Inactive-EMERGING MARKETS CORPORATE DEBT FUND"
            },
            {
                "value": "INJE"
            },
            {
                "value": "INJG",
                "label": "Inactive-EMERGING MARKETS CORPORATE DEBT FUND"
            },
            {
                "value": "INJG"
            },
            {
                "value": "INJU",
                "label": "Inactive-EMERGING MARKETS CORPORATE DEBT FUND"
            },
            {
                "value": "INJU"
            },
            {
                "value": "INKE",
                "label": "Inactive-EMERGING MARKETS EQUITY FUND"
            },
            {
                "value": "INKE"
            },
            {
                "value": "INKG",
                "label": "Inactive-EMERGING MARKETS EQUITY FUND"
            },
            {
                "value": "INKG"
            },
            {
                "value": "INKU",
                "label": "Inactive-EMERGING MARKETS EQUITY FUND"
            },
            {
                "value": "INKU"
            },
            {
                "value": "INLE",
                "label": "INVESCO LUXEMBOURG EUR"
            },
            {
                "value": "INLE"
            },
            {
                "value": "INLG",
                "label": "Inactive"
            },
            {
                "value": "INLG"
            },
            {
                "value": "INLU",
                "label": "Inactive-EMERGING MARKETS HARD CURRENCY DEBT FUND"
            },
            {
                "value": "INLU"
            },
            {
                "value": "INLX",
                "label": "INVESCO LUXEMBOURG"
            },
            {
                "value": "INLX"
            },
            {
                "value": "INME",
                "label": "Inactive-GLOBAL ENERGY LONG SHORT FUND"
            },
            {
                "value": "INMG",
                "label": "Inactive-GLOBAL ENERGY LONG SHORT FUND"
            },
            {
                "value": "INMU",
                "label": "Inactive-GLOBAL ENERGY LONG SHORT FUND"
            },
            {
                "value": "INNE",
                "label": "Inactive-EMERGING MARKETS INVESTMENT GRADE DEBT FUND"
            },
            {
                "value": "INNE"
            },
            {
                "value": "INNG",
                "label": "Inactive-EMERGING MARKETS INVESTMENT GRADE DEBT FUND"
            },
            {
                "value": "INNG"
            },
            {
                "value": "INNU",
                "label": "Inactive-EMERGING MARKETS INVESTMENT GRADE DEBT FUND"
            },
            {
                "value": "INNU"
            },
            {
                "value": "INOE",
                "label": "Inactive-GLOBAL CONTRARIAN EQUITY FUND"
            },
            {
                "value": "INOE"
            },
            {
                "value": "INOG",
                "label": "Inactive-GLOBAL CONTRARIAN EQUITY FUND"
            },
            {
                "value": "INOG"
            },
            {
                "value": "INOU",
                "label": "Inactive-GLOBAL CONTRARIAN EQUITY FUND"
            },
            {
                "value": "INOU"
            },
            {
                "value": "INPE",
                "label": "Inactive-EMERGING MARKETS MULTI-ASSET FUND"
            },
            {
                "value": "INPE"
            },
            {
                "value": "INPG",
                "label": "Inactive-EMERGING MARKETS MULTI-ASSET FUND"
            },
            {
                "value": "INPG"
            },
            {
                "value": "INPU",
                "label": "Inactive-EMERGING MARKETS MULTI-ASSET FUND"
            },
            {
                "value": "INPU"
            },
            {
                "value": "INQE",
                "label": "Inactive-LATIN AMERICAN SMALLER COMPANIES FUND"
            },
            {
                "value": "INQE"
            },
            {
                "value": "INQG",
                "label": "Inactive-LATIN AMERICAN SMALLER COMPANIES FUND"
            },
            {
                "value": "INQG"
            },
            {
                "value": "INQU",
                "label": "Inactive-LATIN AMERICAN SMALLER COMPANIES FUND"
            },
            {
                "value": "INQU"
            },
            {
                "value": "INRE",
                "label": "Inactive-DYNAMIC COMMODITIES FUND"
            },
            {
                "value": "INRE"
            },
            {
                "value": "INRG",
                "label": "Inactive-DYNAMIC COMMODITIES FUND"
            },
            {
                "value": "INRG"
            },
            {
                "value": "INRU",
                "label": "Inactive-DYNAMIC COMMODITIES FUND"
            },
            {
                "value": "INRU"
            },
            {
                "value": "INSE",
                "label": "Inactive-GLOBAL ENDURANCE EQUITY FUND"
            },
            {
                "value": "INSE"
            },
            {
                "value": "INSG",
                "label": "Inactive-GLOBAL ENDURANCE EQUITY FUND"
            },
            {
                "value": "INSG"
            },
            {
                "value": "INSU",
                "label": "Inactive-GLOBAL ENDURANCE EQUITY FUND"
            },
            {
                "value": "INSU"
            },
            {
                "value": "INTE",
                "label": "Inactive-EMERGING MARKETS INVESTMENT GRADE CORPORATE DEBT FUND"
            },
            {
                "value": "INTE"
            },
            {
                "value": "INTG",
                "label": "Inactive-EMERGING MARKETS INVESTMENT GRADE CORPORATE DEBT FUND"
            },
            {
                "value": "INTG"
            },
            {
                "value": "INTU",
                "label": "Inactive-EMERGING MARKETS INVESTMENT GRADE CORPORATE DEBT FUND"
            },
            {
                "value": "INTU"
            },
            {
                "value": "INUE",
                "label": "Inactive"
            },
            {
                "value": "INUE"
            },
            {
                "value": "INUG",
                "label": "Inactive"
            },
            {
                "value": "INUG"
            },
            {
                "value": "INUK",
                "label": "Inactive-INVESCO UK"
            },
            {
                "value": "INUK"
            },
            {
                "value": "INUU",
                "label": "Inactive-CAUTIOUS MANAGED FUND"
            },
            {
                "value": "INUU"
            },
            {
                "value": "INVE",
                "label": "INVESTEC"
            },
            {
                "value": "INVE"
            },
            {
                "value": "INVG",
                "label": "INVESTEC"
            },
            {
                "value": "INVG"
            },
            {
                "value": "INVS",
                "label": "INVESCO"
            },
            {
                "value": "INVS"
            },
            {
                "value": "INVT",
                "label": "Inactive-INVESTEC GLOBAL STRATEGY FUND LIMITED"
            },
            {
                "value": "INVT",
                "label": "Inactive-INVESTMENT VEHICLE TEST INTERNAL NAME"
            },
            {
                "value": "INVU",
                "label": "Inactive-DIVERSIFIED INCOME FUND"
            },
            {
                "value": "INVU"
            },
            {
                "value": "INWE",
                "label": "Inactive-STRATEGIC BOND FUND"
            },
            {
                "value": "INWE"
            },
            {
                "value": "INWG",
                "label": "Inactive-STRATEGIC BOND FUND"
            },
            {
                "value": "INWG"
            },
            {
                "value": "INWU",
                "label": "Inactive-STRATEGIC BOND FUND"
            },
            {
                "value": "INWU"
            },
            {
                "value": "INXE",
                "label": "Inactive-UK BLUE CHIP FUND"
            },
            {
                "value": "INXE"
            },
            {
                "value": "INXG",
                "label": "Inactive-UK BLUE CHIP FUND"
            },
            {
                "value": "INXG"
            },
            {
                "value": "INXU",
                "label": "Inactive-UK BLUE CHIP FUND"
            },
            {
                "value": "INXU"
            },
            {
                "value": "INYE",
                "label": "Inactive-UK ALPHA FUND"
            },
            {
                "value": "INYE"
            },
            {
                "value": "INYG",
                "label": "Inactive-UK ALPHA FUND"
            },
            {
                "value": "INYG"
            },
            {
                "value": "INYU",
                "label": "Inactive-UK ALPHA FUND"
            },
            {
                "value": "INYU"
            },
            {
                "value": "INZE",
                "label": "Inactive-UK SMALLER COMPANIES FUND"
            },
            {
                "value": "INZE"
            },
            {
                "value": "INZG",
                "label": "Inactive-UK SMALLER COMPANIES FUND"
            },
            {
                "value": "INZG"
            },
            {
                "value": "INZU",
                "label": "Inactive-UK SMALLER COMPANIES FUND"
            },
            {
                "value": "INZU"
            },
            {
                "value": "IPAA",
                "label": "Inactive"
            },
            {
                "value": "IPAA"
            },
            {
                "value": "IPAC",
                "label": "Inactive"
            },
            {
                "value": "IPAC"
            },
            {
                "value": "IPAE",
                "label": "Inactive-ENHANCED GLOBAL ENERGY FUND"
            },
            {
                "value": "IPAE"
            },
            {
                "value": "IPAG",
                "label": "Inactive-ENHANCED GLOBAL ENERGY FUND"
            },
            {
                "value": "IPAG"
            },
            {
                "value": "IPBE",
                "label": "Inactive-AFRICA OPPORTUNITIES FUND"
            },
            {
                "value": "IPBE"
            },
            {
                "value": "IPBG",
                "label": "Inactive-AFRICA OPPORTUNITIES FUND"
            },
            {
                "value": "IPBG"
            },
            {
                "value": "IPBU",
                "label": "Inactive-AFRICA OPPORTUNITIES FUND"
            },
            {
                "value": "IPBU"
            },
            {
                "value": "IPCE",
                "label": "Inactive-EMERGING MARKETS HARD CURRENCY DEBT FUND"
            },
            {
                "value": "IPCE"
            },
            {
                "value": "IPCG",
                "label": "Inactive-EMERGING MARKETS HARD CURRENCY DEBT FUND"
            },
            {
                "value": "IPCG"
            },
            {
                "value": "IPDE",
                "label": "Inactive-CAUTIOUS MANAGED FUND"
            },
            {
                "value": "IPDE"
            },
            {
                "value": "IPDG",
                "label": "Inactive-CAUTIOUS MANAGED FUND"
            },
            {
                "value": "IPDG"
            },
            {
                "value": "IPEE",
                "label": "Inactive-DIVERSIFIED INCOME FUND"
            },
            {
                "value": "IPEE"
            },
            {
                "value": "IPEG",
                "label": "Inactive-DIVERSIFIED INCOME FUND"
            },
            {
                "value": "IPEG"
            },
            {
                "value": "IPFE",
                "label": "Inactive-GLOBAL GOLD FUND"
            },
            {
                "value": "IPFE"
            },
            {
                "value": "IPFG",
                "label": "Inactive-GLOBAL GOLD FUND"
            },
            {
                "value": "IPFG"
            },
            {
                "value": "JA1D",
                "label": "Inactive-WHITEMIST LIMITED"
            },
            {
                "value": "JAH1",
                "label": "JOHN HANCOCK LIQUIDITY FINANCING"
            },
            {
                "value": "JANB",
                "label": "JNL/GOLDMAN SACHS US EQUITY FLEX FUND"
            },
            {
                "value": "JHAB",
                "label": "JOHN HANCOCK INCOME SECURITIES TRUST DE"
            },
            {
                "value": "JHAC",
                "label": "JOHN HANCOCK INVESTORS TRUST DE"
            },
            {
                "value": "JHAD",
                "label": "JOHN HANCOCK PREMIUM DIVIDEND FUND DE"
            },
            {
                "value": "JHAE",
                "label": "JOHN HANCOCK TAX-ADVANTAGED DIVIDEND INCOME FUND DE"
            },
            {
                "value": "Jm00"
            },
            {
                "value": "JM01"
            },
            {
                "value": "JM03"
            },
            {
                "value": "JNAB",
                "label": "JNL/GOLDMAN SACHS US EQUITY FLEX FUND"
            },
            {
                "value": "JOEP"
            },
            {
                "value": "JPAB",
                "label": "JPMIM (ECM)"
            },
            {
                "value": "JPMC",
                "label": "JPM 130/30 CANADA FUND AGENCY"
            },
            {
                "value": "JPMC"
            },
            {
                "value": "JPYC",
                "label": "JAPANESE HYBRID TRADE JPY"
            },
            {
                "value": "JPYC"
            },
            {
                "value": "K1A2",
                "label": "Inactive-THE STATE STREET MONEY MARKET FUND"
            },
            {
                "value": "K1A6",
                "label": "Inactive-STATE STREET U.S. GOVERNMENT MONEY FUND"
            },
            {
                "value": "K1A8",
                "label": "Inactive-SSB T SSGA K1A8 STATE ST TREAS PLUS"
            },
            {
                "value": "K2AC",
                "label": "Inactive"
            },
            {
                "value": "K2AC"
            },
            {
                "value": "K2AM",
                "label": "Inactive"
            },
            {
                "value": "K2AM"
            },
            {
                "value": "KAU1",
                "label": "Inactive-STATE STREET GLOBAL SECURITIES LENDING CANADIAN FUND A"
            },
            {
                "value": "KAU1"
            },
            {
                "value": "KAU2",
                "label": "ALBERTA CLIENT GLOBAL SECURITIES LENDING CANADIAN FUND"
            },
            {
                "value": "KAU2"
            },
            {
                "value": "KAU3",
                "label": "Inactive"
            },
            {
                "value": "KAU3"
            },
            {
                "value": "KAU4",
                "label": "Inactive-OPSEU PENSION PLAN TRUST FUND"
            },
            {
                "value": "KAU5",
                "label": "MANITOBA TRUST"
            },
            {
                "value": "KAU5"
            },
            {
                "value": "KAU6",
                "label": "Inactive-SASKATCHEWAN TEACHERS' SUPERANNUATION COMMISSION GLOBAL SECURITIES LENDING CANAD"
            },
            {
                "value": "KAU6"
            },
            {
                "value": "KAU7",
                "label": "RIO TINTO CANADA MASTER TRUST FUND"
            },
            {
                "value": "KAU8",
                "label": "ALCAN MASTER TRUST"
            },
            {
                "value": "KAU8"
            },
            {
                "value": "KAU9",
                "label": "Inactive-ALCAN FOREIGN TRUST"
            },
            {
                "value": "KICE",
                "label": "Inactive"
            },
            {
                "value": "kp1 "
            },
            {
                "value": "KP7 "
            },
            {
                "value": "KUCE",
                "label": "OC19 MASTER FUND"
            },
            {
                "value": "KUCE"
            },
            {
                "value": "LATE",
                "label": "LATVIJAS BANK"
            },
            {
                "value": "LATE"
            },
            {
                "value": "LATG",
                "label": "LATVIJAS BANKA - GBP"
            },
            {
                "value": "LATG"
            },
            {
                "value": "LATV",
                "label": "LATVIJAS BANK"
            },
            {
                "value": "LATV"
            },
            {
                "value": "LCDZ",
                "label": "KUWAIT INV AUTHORITY"
            },
            {
                "value": "LDT1"
            },
            {
                "value": "LDT2"
            },
            {
                "value": "LDT3"
            },
            {
                "value": "LFTE",
                "label": "Inactive-LUFTHANSA TGV LH STRATEGY"
            },
            {
                "value": "LFTE"
            },
            {
                "value": "LIVE"
            },
            {
                "value": "LJN1"
            },
            {
                "value": "LJNN"
            },
            {
                "value": "LM10"
            },
            {
                "value": "LM11"
            },
            {
                "value": "LM12"
            },
            {
                "value": "LM13"
            },
            {
                "value": "LMAU",
                "label": "Inactive-LEGG MASON ASSET MANAGEMENT AUSTRALIA"
            },
            {
                "value": "LMRE"
            },
            {
                "value": "LMRT"
            },
            {
                "value": "LMS "
            },
            {
                "value": "LMS4"
            },
            {
                "value": "LMS7"
            },
            {
                "value": "LMST"
            },
            {
                "value": "LMT3"
            },
            {
                "value": "LMTS"
            },
            {
                "value": "LSTE",
                "label": "LIONTRUST FUND PARTNERS LLP - UK SMALLER COMPANIES FUND"
            },
            {
                "value": "LSTE"
            },
            {
                "value": "LSTG",
                "label": "Inactive"
            },
            {
                "value": "LSTG"
            },
            {
                "value": "LSTR",
                "label": "LIONTRUST FUND PARTNERS LLP - UK SMALLER COMPANIES FUND"
            },
            {
                "value": "LSTR"
            },
            {
                "value": "LUXB",
                "label": "Inactive-LUXOR CAPITAL PARTNERS OFFSHORE MASTER FUND"
            },
            {
                "value": "LUXB"
            },
            {
                "value": "LUXD",
                "label": "Inactive-LUXOR SPECTRUM OFFSHORE MASTER FUND"
            },
            {
                "value": "LUXD"
            },
            {
                "value": "LUXE",
                "label": "Inactive"
            },
            {
                "value": "LUXE"
            },
            {
                "value": "LUXF",
                "label": "Inactive-LUXOR CAPITAL PARTNERS"
            },
            {
                "value": "LUXG",
                "label": "Inactive-LUXOR WAVEFRONT"
            },
            {
                "value": "LUXU",
                "label": "Inactive"
            },
            {
                "value": "LUXU"
            },
            {
                "value": "M9DA",
                "label": "Inactive-RUSSELL INVESTMENT MANAGEMENT"
            },
            {
                "value": "M9DA"
            },
            {
                "value": "MABE",
                "label": "NEW MILLENNIUM AUGUSTUM BEATRICE EQUITY FUND EUR"
            },
            {
                "value": "MABU",
                "label": "NEW MILLENNIUM AUGUSTUM BEATRICE EQUITY FUND USD"
            },
            {
                "value": "MACE",
                "label": "NEW MILLENNIUM AUGUSTUM CORPORATE BOND EUR"
            },
            {
                "value": "MACU",
                "label": "NEW MILLENNIUM AUGUSTUM CORPORATE BOND USD"
            },
            {
                "value": "MAEE",
                "label": "NEW MILLENNIUM AUGUSTUM PAN EUROPEAN EQUITY EUR"
            },
            {
                "value": "MAEU",
                "label": "NEW MILLENNIUM AUGUSTUM PAN EUROPEAN EQUITY USD"
            },
            {
                "value": "MAPF"
            },
            {
                "value": "Mapf"
            },
            {
                "value": "MAQE",
                "label": "NEW MILLENNIUM AUGUSTUM HIGH QUALITY BOND EUR"
            },
            {
                "value": "MAQU",
                "label": "NEW MILLENNIUM AUGUSTUM HIGH QUALITY BOND USD"
            },
            {
                "value": "MARE",
                "label": "MARTIN CURRIE GLOBAL PORTFOLIO TRUST PLC"
            },
            {
                "value": "MARE"
            },
            {
                "value": "MARG",
                "label": "MARTIN CURRIE GLOBAL PORTFOLIO TRUST PLC"
            },
            {
                "value": "MARG"
            },
            {
                "value": "MART",
                "label": "MARTIN CURRIE GLOBAL PORTFOLIO TRUST PLC USD"
            },
            {
                "value": "MART"
            },
            {
                "value": "MAST"
            },
            {
                "value": "MAUD",
                "label": "Inactive"
            },
            {
                "value": "MAYT"
            },
            {
                "value": "MBN1"
            },
            {
                "value": "MBN2"
            },
            {
                "value": "MCAD",
                "label": "Inactive"
            },
            {
                "value": "MDEM",
                "label": "Inactive"
            },
            {
                "value": "MDKK",
                "label": "Inactive"
            },
            {
                "value": "ME1 "
            },
            {
                "value": "MEBE",
                "label": "NEW MILLENNIUM EURO BONDS SHORT TERM EUR"
            },
            {
                "value": "MEBE"
            },
            {
                "value": "MEBU",
                "label": "NEW MILLENNIUM EURO BONDS SHORT TERM USD"
            },
            {
                "value": "MEBU"
            },
            {
                "value": "MECE",
                "label": "Inactive"
            },
            {
                "value": "MECE"
            },
            {
                "value": "MECG",
                "label": "Inactive"
            },
            {
                "value": "MECG"
            },
            {
                "value": "MECU",
                "label": "Inactive"
            },
            {
                "value": "MECU"
            },
            {
                "value": "MEEE",
                "label": "NEW MILLENNIUM EURO EQUITIES EUR"
            },
            {
                "value": "MEEE"
            },
            {
                "value": "MEEU",
                "label": "NEW MILLENNIUM EURO EQUITIES USD"
            },
            {
                "value": "MEEU"
            },
            {
                "value": "MERC",
                "label": "MERCER- S.S INST US GOVT MM"
            },
            {
                "value": "MERC"
            },
            {
                "value": "MESP",
                "label": "Inactive"
            },
            {
                "value": "MET1",
                "label": "MSF - MET/DIMENSIONAL INT'L SM"
            },
            {
                "value": "MET2",
                "label": "MIST - BLACKROCK HIGH YIELD PO"
            },
            {
                "value": "MET3",
                "label": "MIST - LOOMIS SAYLES GLOBAL MA"
            },
            {
                "value": "MET4",
                "label": "MIST - MET/FRANKLIN LOW DURATI"
            },
            {
                "value": "MEUR",
                "label": "Inactive"
            },
            {
                "value": "MFRF",
                "label": "Inactive"
            },
            {
                "value": "MFS ",
                "label": "Inactive"
            },
            {
                "value": "MG30",
                "label": "Inactive"
            },
            {
                "value": "MGBP",
                "label": "Inactive"
            },
            {
                "value": "MGEE",
                "label": "NEW MILLENNIUM GLOBAL EQUITIES EUR"
            },
            {
                "value": "MGEE"
            },
            {
                "value": "MGEU",
                "label": "NEW MILLENNIUM GLOBAL EQUITIES USD"
            },
            {
                "value": "MGEU"
            },
            {
                "value": "MHDK"
            },
            {
                "value": "MIBE",
                "label": "NEW MILLENNIUM INFLATION LINKED BOND EUROP EUR"
            },
            {
                "value": "MIBE"
            },
            {
                "value": "MIBU",
                "label": "NEW MILLENNIUM INFLATION LINKED BOND EUROP USD"
            },
            {
                "value": "MIBU"
            },
            {
                "value": "MID1",
                "label": "MIDAS FUND"
            },
            {
                "value": "MID2",
                "label": "MIDAS MAGIC"
            },
            {
                "value": "MID3",
                "label": "FOXBY CORP"
            },
            {
                "value": "MID4",
                "label": "MIDAS DIVIDEND AND INCOME FUND"
            },
            {
                "value": "MIN1"
            },
            {
                "value": "MIN2"
            },
            {
                "value": "MIN3"
            },
            {
                "value": "MIN4"
            },
            {
                "value": "MIN5"
            },
            {
                "value": "MIN6"
            },
            {
                "value": "MIN7"
            },
            {
                "value": "MIN8"
            },
            {
                "value": "MJPY",
                "label": "Inactive"
            },
            {
                "value": "MKTE",
                "label": "Inactive-TEST1"
            },
            {
                "value": "ML02",
                "label": "Inactive-LOCKHEED MARTIN S/T INVEST FD"
            },
            {
                "value": "ML1T"
            },
            {
                "value": "MLAB",
                "label": "INTEGRATED CORE STRATEGIES US"
            },
            {
                "value": "MLAB"
            },
            {
                "value": "MLEE",
                "label": "NEW MILLENNIUM LARGE EUROPE CORPORATE EUR"
            },
            {
                "value": "MLEE"
            },
            {
                "value": "MLEU",
                "label": "NEW MILLENNIUM LARGE EUROPE CORPORATE USD"
            },
            {
                "value": "MLEU"
            },
            {
                "value": "MMMF",
                "label": "Inactive"
            },
            {
                "value": "MMMF"
            },
            {
                "value": "MNLG",
                "label": "Inactive"
            },
            {
                "value": "MPFE",
                "label": "Inactive-MERSEYSIDE PENSION FUND - EUR"
            },
            {
                "value": "MPFG",
                "label": "Inactive-MERSEYSIDE PENSION FUND - GBP"
            },
            {
                "value": "MPFU",
                "label": "Inactive-MERSEYSIDE PENSION FUND"
            },
            {
                "value": "MPWE",
                "label": "NEW MILLENNIUM PREVIRA WORLD CONSERVATIVE EUR"
            },
            {
                "value": "MPWE"
            },
            {
                "value": "MPWU",
                "label": "NEW MILLENNIUM PREVIRA WORLD CONSERVATIVE USD"
            },
            {
                "value": "MPWU"
            },
            {
                "value": "MQAE",
                "label": "NEW MILLENNIUM Q7 ALPHA BALANCED EUR"
            },
            {
                "value": "MQAU",
                "label": "NEW MILLENNIUM Q7 ALPHA BALANCED USD"
            },
            {
                "value": "MQEE",
                "label": "NEW MILLENNIUM Q7 ACTIVE EQUITIES INT EUR"
            },
            {
                "value": "MQEE"
            },
            {
                "value": "MQEU",
                "label": "NEW MILLENNIUM Q7 ACTIVE EQUITIES INT USD"
            },
            {
                "value": "MQEU"
            },
            {
                "value": "MQGE",
                "label": "NEW MILLENNIUM Q7 GLOBALFLEX EUR"
            },
            {
                "value": "MQGE"
            },
            {
                "value": "MQGU",
                "label": "NEW MILLENNIUM Q7 GLOBALFLEX USD"
            },
            {
                "value": "MQGU"
            },
            {
                "value": "MQTE",
                "label": "NEW MILLENNIUM Q7 TOTAL RETURN FLEXIBLE EUR"
            },
            {
                "value": "MQTE"
            },
            {
                "value": "MQTU",
                "label": "NEW MILLENNIUM Q7 TOTAL RETURN FLEXIBLE USD"
            },
            {
                "value": "MQTU"
            },
            {
                "value": "MR01"
            },
            {
                "value": "MR02"
            },
            {
                "value": "MR03"
            },
            {
                "value": "MR04"
            },
            {
                "value": "MR05"
            },
            {
                "value": "MR06"
            },
            {
                "value": "MR07"
            },
            {
                "value": "MR08"
            },
            {
                "value": "MR09"
            },
            {
                "value": "MR10"
            },
            {
                "value": "MSAM",
                "label": "MORGAN STANLEY ASSET MANAGEMENT"
            },
            {
                "value": "MSBI",
                "label": "Inactive"
            },
            {
                "value": "MSEK",
                "label": "Inactive"
            },
            {
                "value": "MSGD"
            },
            {
                "value": "MSPE",
                "label": "MARKS & Spencer PENSION SCHEME"
            },
            {
                "value": "MSPE"
            },
            {
                "value": "MSPG",
                "label": "MARKS & Spencer PENSION GBP"
            },
            {
                "value": "MSPG"
            },
            {
                "value": "MSPU",
                "label": "MARKS & Spencer PENSION SCHEME"
            },
            {
                "value": "MSPU"
            },
            {
                "value": "MSSA",
                "label": "MORGAN STANLEY EXTERNAL"
            },
            {
                "value": "MSZ2",
                "label": "Inactive"
            },
            {
                "value": "MSZ2"
            },
            {
                "value": "MTAS"
            },
            {
                "value": "MTGW"
            },
            {
                "value": "MTKE"
            },
            {
                "value": "MTKS"
            },
            {
                "value": "MTL1",
                "label": "Inactive"
            },
            {
                "value": "MTMB"
            },
            {
                "value": "MTNT"
            },
            {
                "value": "MTPC"
            },
            {
                "value": "MTPV"
            },
            {
                "value": "MTRT"
            },
            {
                "value": "MTSA"
            },
            {
                "value": "MTTV"
            },
            {
                "value": "MTTY"
            },
            {
                "value": "MUAE",
                "label": "Inactive-MUZINICH & Co IRELAND LTD - EUR"
            },
            {
                "value": "MUAU",
                "label": "Inactive-MUZINICH & Co IRELAND LTD - USA"
            },
            {
                "value": "MUTL",
                "label": "Inactive"
            },
            {
                "value": "MUZE",
                "label": "Inactive"
            },
            {
                "value": "MUZE"
            },
            {
                "value": "MUZN",
                "label": "Inactive-MUZINICH & Co (IRELAND) LIMITED - EUROPEYIELD FUND"
            },
            {
                "value": "MUZN"
            },
            {
                "value": "MUZZ",
                "label": "MONTANA BOARD OF INVESTMENTS"
            },
            {
                "value": "N478",
                "label": "Inactive"
            },
            {
                "value": "N478"
            },
            {
                "value": "NBAF",
                "label": "NEUBERGER BERMAN ALTERNATIVE"
            },
            {
                "value": "NBAF"
            },
            {
                "value": "NBZI",
                "label": "Inactive-NUVEEN TWINDS GLOBAL ECM"
            },
            {
                "value": "NBZI"
            },
            {
                "value": "NBZM",
                "label": "Inactive-NUVEEN SB GROWTH ECM"
            },
            {
                "value": "NBZM"
            },
            {
                "value": "NBZQ",
                "label": "Inactive"
            },
            {
                "value": "NBZQ"
            },
            {
                "value": "NEC2"
            },
            {
                "value": "NEZ2",
                "label": "Inactive-RUSSELL PRIME"
            },
            {
                "value": "NEZ5",
                "label": "Inactive-RIC LIQUIDATING TRUST"
            },
            {
                "value": "NEZ7",
                "label": "Inactive-RIF LIQUIDATING TRUST"
            },
            {
                "value": "NGRG",
                "label": "Inactive"
            },
            {
                "value": "NGRG",
                "label": "NATIONAL GRG BOXX-2"
            },
            {
                "value": "nik2"
            },
            {
                "value": "NIK8"
            },
            {
                "value": "NILM"
            },
            {
                "value": "NKS "
            },
            {
                "value": "NMFA",
                "label": "Inactive"
            },
            {
                "value": "NMFA"
            },
            {
                "value": "NMFM",
                "label": "Inactive"
            },
            {
                "value": "NMFM"
            },
            {
                "value": "NPAE",
                "label": "Inactive-NEXTAM PARTNERS SICAV INTERNATIONAL EQUITY FUND EUR"
            },
            {
                "value": "NPAE"
            },
            {
                "value": "NPAU",
                "label": "Inactive-NEXTAM PARTNERS SICAV INTERNATIONAL EQUITY FUND USD"
            },
            {
                "value": "NPAU"
            },
            {
                "value": "NPBE",
                "label": "Inactive-NEXTAM PARTNERS SICAV CITIC EUR"
            },
            {
                "value": "NPBE"
            },
            {
                "value": "NPBU",
                "label": "Inactive-NEXTAM PARTNERS SICAV CITIC USD"
            },
            {
                "value": "NPBU"
            },
            {
                "value": "NPCE",
                "label": "Inactive-NEXTAM PARTNERS SICAV FLEX EUR"
            },
            {
                "value": "NPCU",
                "label": "Inactive-NEXTAM PARTNERS SICAV FLEX 1 USD"
            },
            {
                "value": "NPDE",
                "label": "Inactive-NEXTAM PARTHERS SICAV SATOR EUR"
            },
            {
                "value": "NPDE"
            },
            {
                "value": "NPDU",
                "label": "Inactive-NEXTAM PARTNERS SICAV SATOR USD"
            },
            {
                "value": "NPDU"
            },
            {
                "value": "NPEE",
                "label": "Inactive-NEXTAM PARTNERS SICAV FIDEL EUR"
            },
            {
                "value": "NPEE"
            },
            {
                "value": "NPEU",
                "label": "Inactive-NEXTAM PARTNERS SICAV FIDELA USD"
            },
            {
                "value": "NPEU"
            },
            {
                "value": "NPFE",
                "label": "Inactive-NEXTAM PARTNERS BINEVER EUR"
            },
            {
                "value": "NPFE"
            },
            {
                "value": "NPFU",
                "label": "Inactive-NEXTAM PARTNERS SICAV BINEVER USD"
            },
            {
                "value": "NPFU"
            },
            {
                "value": "NPGE",
                "label": "Inactive-NEXTAM PARTNERS AAMPRO EUR"
            },
            {
                "value": "NPGU",
                "label": "Inactive-NEXTAM PARTNERS SICAV AAM PRO USD"
            },
            {
                "value": "NPHE",
                "label": "Inactive-NEXTAM PARTNERS FLEX AM EUR"
            },
            {
                "value": "NPHE"
            },
            {
                "value": "NPHU",
                "label": "Inactive-NEXTAM PARTNERS SICAV FLEX AM USD"
            },
            {
                "value": "NPHU"
            },
            {
                "value": "NPIE",
                "label": "Inactive-NEXTAM PARTNERSLIQUIDITY EUR"
            },
            {
                "value": "NPIE"
            },
            {
                "value": "NPIU",
                "label": "Inactive-NEXTAM PARTNERS SICAV LIQUIDITY USD"
            },
            {
                "value": "NPIU"
            },
            {
                "value": "NPJE",
                "label": "Inactive-NEXTAM PARTNERS INCOME EUR"
            },
            {
                "value": "NPJE"
            },
            {
                "value": "NPJU",
                "label": "Inactive-NEXTAM PARTNERS SICAV INCOME USD"
            },
            {
                "value": "NPJU"
            },
            {
                "value": "NPKE",
                "label": "Inactive-NEXTAM PARTNERS STRATEGIC EUR"
            },
            {
                "value": "NPKE"
            },
            {
                "value": "NPKU",
                "label": "Inactive-NEXTAM PARTNERS SICAV STRATEGIC FUND USD"
            },
            {
                "value": "NPKU"
            },
            {
                "value": "NPLE",
                "label": "Inactive-NEXTAM PARTNERS ITALIAN EUR"
            },
            {
                "value": "NPLE"
            },
            {
                "value": "NPLU",
                "label": "Inactive-NEXTAM PARTNERS SICAV ITALIAN USD"
            },
            {
                "value": "NPLU"
            },
            {
                "value": "NPME",
                "label": "Inactive-NEXTAM PARTNERS USA VALUE EUR"
            },
            {
                "value": "NPMU",
                "label": "Inactive-NEXTAM PERTNERS USA VALUE FUND US"
            },
            {
                "value": "NPMU"
            },
            {
                "value": "NPNE",
                "label": "Inactive-NEXTAMPARTNERS VER CAPITAL EUR"
            },
            {
                "value": "NPNE"
            },
            {
                "value": "NPNU",
                "label": "Inactive-NEXTAM PARTNERS VER CAPITAL"
            },
            {
                "value": "NPNU"
            },
            {
                "value": "NPPE",
                "label": "Inactive-NEXTAM PARTNERS SICAV"
            },
            {
                "value": "NPPE"
            },
            {
                "value": "NPPU",
                "label": "Inactive-NEXTAM PARTNERS SICAV"
            },
            {
                "value": "NPPU"
            },
            {
                "value": "NPV1"
            },
            {
                "value": "NQ01",
                "label": "Inactive"
            },
            {
                "value": "NS34"
            },
            {
                "value": "NSLM"
            },
            {
                "value": "NSTE",
                "label": "Inactive"
            },
            {
                "value": "NSTE"
            },
            {
                "value": "NSTG",
                "label": "Inactive"
            },
            {
                "value": "NSTG"
            },
            {
                "value": "NSTR",
                "label": "Inactive"
            },
            {
                "value": "NSTR"
            },
            {
                "value": "NUVE",
                "label": "Inactive"
            },
            {
                "value": "NUVE"
            },
            {
                "value": "NVFE",
                "label": "Inactive-NORDRHEINISCHE VANT FONDS (INKA)"
            },
            {
                "value": "OMER",
                "label": "ONTARION MUNICIPAL EMPLOYEE RET"
            },
            {
                "value": "OMER"
            },
            {
                "value": "OMKA"
            },
            {
                "value": "OMRS",
                "label": "Inactive"
            },
            {
                "value": "OPDO",
                "label": "Inactive"
            },
            {
                "value": "OPDO"
            },
            {
                "value": "OPIN",
                "label": "Inactive"
            },
            {
                "value": "OPIN"
            },
            {
                "value": "P 77951"
            },
            {
                "value": "P 77952"
            },
            {
                "value": "P 77953"
            },
            {
                "value": "P86969"
            },
            {
                "value": "PA9 "
            },
            {
                "value": "PACL",
                "label": "PACIFIC SELECT FUND"
            },
            {
                "value": "PACL"
            },
            {
                "value": "PAT "
            },
            {
                "value": "PATE",
                "label": "Inactive-PATERNOSTER UK LIMITED"
            },
            {
                "value": "PATE"
            },
            {
                "value": "PATG",
                "label": "Inactive-PATERNOSTER UK LIMITED"
            },
            {
                "value": "PATG"
            },
            {
                "value": "PATU",
                "label": "Inactive-PATERNOSTER UK LIMITED"
            },
            {
                "value": "PATU"
            },
            {
                "value": "PAXW",
                "label": "Inactive-PAX WORLD"
            },
            {
                "value": "PENN",
                "label": "Inactive"
            },
            {
                "value": "PENN"
            },
            {
                "value": "PFSE",
                "label": "Inactive-POLLUX FUNDS SA EUR"
            },
            {
                "value": "PFSE"
            },
            {
                "value": "PFSU",
                "label": "Inactive-POLLUX FUNDS SA USD"
            },
            {
                "value": "PFSU"
            },
            {
                "value": "PGSE",
                "label": "Inactive"
            },
            {
                "value": "PGSE"
            },
            {
                "value": "PGSG",
                "label": "Inactive"
            },
            {
                "value": "PGSG"
            },
            {
                "value": "PGSP",
                "label": "Inactive"
            },
            {
                "value": "PGSP"
            },
            {
                "value": "PHNX",
                "label": "Inactive"
            },
            {
                "value": "PK9 "
            },
            {
                "value": "PNAE",
                "label": "PENSPLAN INV US EQUITIES EUR"
            },
            {
                "value": "PNAE"
            },
            {
                "value": "PNAU",
                "label": "PENSPLAN INV US EQUITIES US"
            },
            {
                "value": "PNAU"
            },
            {
                "value": "PNBE",
                "label": "PENSPLAN EUROPE EQUITIES EUR"
            },
            {
                "value": "PNBE"
            },
            {
                "value": "PNBU",
                "label": "PENSPLAN INV EUROPE EQUITIES US"
            },
            {
                "value": "PNBU"
            },
            {
                "value": "PNCE",
                "label": "PENSPLAN GLOBAL EQUITIES EUR"
            },
            {
                "value": "PNCE"
            },
            {
                "value": "PNCU",
                "label": "PENSPLAN INV GLOBAL EQUITIES US"
            },
            {
                "value": "PNCU"
            },
            {
                "value": "PNDE",
                "label": "PENSPLAN EUR BOND 1-3 YEAR EUR"
            },
            {
                "value": "PNDE"
            },
            {
                "value": "PNDU",
                "label": "PENSPLAN INV EUR BOND 1-3 YEAR US"
            },
            {
                "value": "PNDU"
            },
            {
                "value": "PNEE",
                "label": "PENSPLAN INV EUR CORP BOND EUR"
            },
            {
                "value": "PNEE"
            },
            {
                "value": "PNEU",
                "label": "PENSPLAN INV EUR CORP BOND US"
            },
            {
                "value": "PNEU"
            },
            {
                "value": "PNFE",
                "label": "PENSPLAN INV EUR GOV BOND EUR"
            },
            {
                "value": "PNFE"
            },
            {
                "value": "PNFU",
                "label": "PENSPLAN INV EUR GOV BOND US"
            },
            {
                "value": "PNFU"
            },
            {
                "value": "PNGE",
                "label": "PENSPLAN INV CASH EUR"
            },
            {
                "value": "PNGE"
            },
            {
                "value": "PNGU",
                "label": "PENSPLAN INV CASH USD"
            },
            {
                "value": "PNGU"
            },
            {
                "value": "PNHE",
                "label": "PENSPLAN LOCAL INVESTMENT EUR"
            },
            {
                "value": "PNHE"
            },
            {
                "value": "PNHU",
                "label": "PENSPLAN LOCAL INVESTMENT"
            },
            {
                "value": "PNHU"
            },
            {
                "value": "PP9H",
                "label": "Inactive"
            },
            {
                "value": "PP9H"
            },
            {
                "value": "PPFE",
                "label": "Inactive-PHILIPS PEKA FONDS (INKA)"
            },
            {
                "value": "PQ88"
            },
            {
                "value": "PRIN",
                "label": "Inactive-PRINCIPAL LIFE INSURANCE CO"
            },
            {
                "value": "PRIN"
            },
            {
                "value": "PS2Y",
                "label": "PAC SEL LONG SH LG CAP JPM"
            },
            {
                "value": "PS2Y"
            },
            {
                "value": "PS2Z",
                "label": "PAC SEL L/S LG CAP ANALYTIC"
            },
            {
                "value": "PS2Z"
            },
            {
                "value": "PV01"
            },
            {
                "value": "PV02"
            },
            {
                "value": "PV03"
            },
            {
                "value": "PY1A",
                "label": "PYXIS LONG/SHORT EQUITY FUND"
            },
            {
                "value": "PY1B",
                "label": "PYXIS LONG/SHORT HEALTHCARE FUND"
            },
            {
                "value": "Q3D7",
                "label": "Inactive-SSGA AUSTRALIA"
            },
            {
                "value": "Q3D7"
            },
            {
                "value": "Q3MU",
                "label": "Inactive-SSGA AUSTRALIA ABS"
            },
            {
                "value": "Q3MU"
            },
            {
                "value": "Q3U5",
                "label": "Inactive-SSGA GLOBAL SECURITIED LENDING TRUST"
            },
            {
                "value": "Q3U5"
            },
            {
                "value": "Q3UA",
                "label": "RETAIL EMPLOYEES SUPERANNUATION PTY LIMITED AUD"
            },
            {
                "value": "Q3UA"
            },
            {
                "value": "QA11"
            },
            {
                "value": "QA22"
            },
            {
                "value": "QA33"
            },
            {
                "value": "QA44"
            },
            {
                "value": "QA51"
            },
            {
                "value": "QA52"
            },
            {
                "value": "QA55"
            },
            {
                "value": "QA66"
            },
            {
                "value": "QCGT",
                "label": "QUALCOMM GLOBAL TRADING"
            },
            {
                "value": "QCGT"
            },
            {
                "value": "QTAB",
                "label": "QTB SUPER AUSTRALIAN"
            },
            {
                "value": "QTAB"
            },
            {
                "value": "QUES",
                "label": "INVESCO FUNDS - VARIOUS"
            },
            {
                "value": "QUES"
            },
            {
                "value": "R31 "
            },
            {
                "value": "RAG3"
            },
            {
                "value": "Rag3"
            },
            {
                "value": "RAG4"
            },
            {
                "value": "RAG7"
            },
            {
                "value": "RAH1"
            },
            {
                "value": "RAS1"
            },
            {
                "value": "RAS2"
            },
            {
                "value": "Ras3"
            },
            {
                "value": "RAUT"
            },
            {
                "value": "RCEB",
                "label": "Inactive-RUSSELL COMMINGLED EMP BENEFIT"
            },
            {
                "value": "RDT1"
            },
            {
                "value": "RDT2"
            },
            {
                "value": "RDT3"
            },
            {
                "value": "RDT5"
            },
            {
                "value": "RGAA",
                "label": "IM ARGONAUT EURO ALPHA FUND"
            },
            {
                "value": "RGAA"
            },
            {
                "value": "RGAB",
                "label": "IM ARGONAUT EURO INCOME FUND"
            },
            {
                "value": "RGAC",
                "label": "IM ARGONAUT EURO ENHANCED RETURN FUND"
            },
            {
                "value": "RGAC"
            },
            {
                "value": "RGAD",
                "label": "IM ARGONAUT EURO ABSOLUTE RETURN FUND"
            },
            {
                "value": "RGAD"
            },
            {
                "value": "RIDG",
                "label": "RIDGEWORTH FUNDS"
            },
            {
                "value": "RIDG"
            },
            {
                "value": "RMAD"
            },
            {
                "value": "ROSE",
                "label": "Inactive"
            },
            {
                "value": "RSA3"
            },
            {
                "value": "RSHI",
                "label": "Inactive"
            },
            {
                "value": "RSSE",
                "label": "SEASTONE MASTER FUND, L.P."
            },
            {
                "value": "RSSG",
                "label": "Inactive-RESEVOIR MASTER FUND, L.P."
            },
            {
                "value": "RSSU",
                "label": "SEASTONE MASTER FUND, L.P."
            },
            {
                "value": "RT9E",
                "label": "RIO TINTO 2009 PENSIONFUND EUR"
            },
            {
                "value": "RT9E"
            },
            {
                "value": "RT9G",
                "label": "RIO TINTO 2009 PENSIONFUND GBP"
            },
            {
                "value": "RT9G"
            },
            {
                "value": "RT9U",
                "label": "RIO TINTO 2009 PENSIONFUND USD"
            },
            {
                "value": "RT9U"
            },
            {
                "value": "RTHC"
            },
            {
                "value": "RTIE",
                "label": "Inactive"
            },
            {
                "value": "RTIE"
            },
            {
                "value": "RTIG",
                "label": "Inactive"
            },
            {
                "value": "RTIG"
            },
            {
                "value": "RTIU",
                "label": "Inactive"
            },
            {
                "value": "RTIU"
            },
            {
                "value": "RTPE",
                "label": "RIO TINTO PENSION FUND"
            },
            {
                "value": "RTPE"
            },
            {
                "value": "RTPG",
                "label": "RIO TINTO PENSION FUND - GBP"
            },
            {
                "value": "RTPG"
            },
            {
                "value": "RTPU",
                "label": "RIO TINTO PENSION FUND"
            },
            {
                "value": "RTPU"
            },
            {
                "value": "RTVC"
            },
            {
                "value": "RUS1"
            },
            {
                "value": "RUS9",
                "label": "Inactive-RUSSELL AUS OPPORTUNITIES FUND"
            },
            {
                "value": "RUS9"
            },
            {
                "value": "S1Y3",
                "label": "ONTARIO MUNICIPAL EMPLOYEE RETIREMENT BOARD CAD"
            },
            {
                "value": "S1YB",
                "label": "ONTARIO MUNIEMPLOYEERETIREMENT"
            },
            {
                "value": "S2BH",
                "label": "OMERS GMAP LONG/SHORT"
            },
            {
                "value": "SA10"
            },
            {
                "value": "SACH"
            },
            {
                "value": "SAFA",
                "label": "STEADFAST INTERNATIONAL MASTER FUND, LTD"
            },
            {
                "value": "SAFB",
                "label": "STEADFAST, L.P."
            },
            {
                "value": "SAFD",
                "label": "AMERICAN STEADFAST, L.P."
            },
            {
                "value": "SAFU",
                "label": "STEADFAST INTERNATIONAL MASTER FUND LTD."
            },
            {
                "value": "SAFU"
            },
            {
                "value": "SANT"
            },
            {
                "value": "SAT1"
            },
            {
                "value": "SAV1"
            },
            {
                "value": "SAV2"
            },
            {
                "value": "SC2B",
                "label": "Inactive-STATE OF CONNECTICUT - SC2B"
            },
            {
                "value": "SCHW",
                "label": "Inactive-SCHWAB"
            },
            {
                "value": "SCHW"
            },
            {
                "value": "SCOT",
                "label": "SECURITIES TRUST OF SCOTLAND"
            },
            {
                "value": "SCOT"
            },
            {
                "value": "SCTE",
                "label": "SECURITIES TRUST OF SCOTLAND"
            },
            {
                "value": "SCTE"
            },
            {
                "value": "SCTG",
                "label": "SECURITIES TRUST OF SCOTLAND"
            },
            {
                "value": "SCTG"
            },
            {
                "value": "SD11"
            },
            {
                "value": "SD12"
            },
            {
                "value": "SDXA",
                "label": "NGS SUPER AUD CASH COLLATERAL TRUST"
            },
            {
                "value": "SDXA"
            },
            {
                "value": "SEC1",
                "label": "Inactive"
            },
            {
                "value": "SEC1",
                "label": "Inactive-SF NON-CASH COLLATERAL (EST.)"
            },
            {
                "value": "SFB1"
            },
            {
                "value": "SIRJ"
            },
            {
                "value": "SJR2"
            },
            {
                "value": "SLF8"
            },
            {
                "value": "SNP0",
                "label": "Inactive"
            },
            {
                "value": "SNTL",
                "label": "SENTINEL INVESTMENTS"
            },
            {
                "value": "SOHP",
                "label": "Inactive"
            },
            {
                "value": "SOPA",
                "label": "Inactive"
            },
            {
                "value": "SP01"
            },
            {
                "value": "SP02"
            },
            {
                "value": "SP03"
            },
            {
                "value": "SP04"
            },
            {
                "value": "SP05"
            },
            {
                "value": "SP06"
            },
            {
                "value": "SP07"
            },
            {
                "value": "SP08"
            },
            {
                "value": "SP09"
            },
            {
                "value": "SP10"
            },
            {
                "value": "SP11"
            },
            {
                "value": "SP12"
            },
            {
                "value": "SP13"
            },
            {
                "value": "SP14"
            },
            {
                "value": "SP15"
            },
            {
                "value": "SPF1"
            },
            {
                "value": "SPMT"
            },
            {
                "value": "SPR1"
            },
            {
                "value": "SPRT",
                "label": "SPROTT PRIVET"
            },
            {
                "value": "SPRT"
            },
            {
                "value": "SPT1"
            },
            {
                "value": "SQ00"
            },
            {
                "value": "SQ11"
            },
            {
                "value": "SQ22"
            },
            {
                "value": "SQ33"
            },
            {
                "value": "SQ44"
            },
            {
                "value": "SQ55"
            },
            {
                "value": "SQ66"
            },
            {
                "value": "SQ77"
            },
            {
                "value": "SQ88"
            },
            {
                "value": "SQ99"
            },
            {
                "value": "SQA1"
            },
            {
                "value": "SQB1"
            },
            {
                "value": "SQC1"
            },
            {
                "value": "SQD1"
            },
            {
                "value": "SS11"
            },
            {
                "value": "SS3 "
            },
            {
                "value": "SS55"
            },
            {
                "value": "SSgA",
                "label": "Inactive"
            },
            {
                "value": "SSLM"
            },
            {
                "value": "ST11"
            },
            {
                "value": "STES"
            },
            {
                "value": "STIF",
                "label": "Inactive"
            },
            {
                "value": "STIF"
            },
            {
                "value": "SUCZ",
                "label": "SUNSUPER AUD"
            },
            {
                "value": "SUCZ"
            },
            {
                "value": "SURU",
                "label": "SUREVIEW MASTER FUND, LTD"
            },
            {
                "value": "SURU"
            },
            {
                "value": "SVF1"
            },
            {
                "value": "SVF2"
            },
            {
                "value": "SVF4"
            },
            {
                "value": "SVF5"
            },
            {
                "value": "SVF6"
            },
            {
                "value": "SVF7"
            },
            {
                "value": "SVF8"
            },
            {
                "value": "SVT1"
            },
            {
                "value": "SVT2"
            },
            {
                "value": "SVT4"
            },
            {
                "value": "SVT5"
            },
            {
                "value": "SVT6"
            },
            {
                "value": "SVT7"
            },
            {
                "value": "SVT8"
            },
            {
                "value": "SWFJ",
                "label": "Inactive"
            },
            {
                "value": "SWFJ"
            },
            {
                "value": "SWFL",
                "label": "CALPERS FINANCE POOL"
            },
            {
                "value": "SWFL"
            },
            {
                "value": "SWFN",
                "label": "Inactive-CALPERS FINANCE POOL"
            },
            {
                "value": "SWFN"
            },
            {
                "value": "SWJE",
                "label": "CALPERS FINANCE POOL"
            },
            {
                "value": "SWJE"
            },
            {
                "value": "SY1B",
                "label": "OMERS PUBLIC INVESTMENT HOLDINGS INC"
            },
            {
                "value": "TES1",
                "label": "INT NAME1"
            },
            {
                "value": "TES1",
                "label": "INTERNAL NAME"
            },
            {
                "value": "TESR"
            },
            {
                "value": "TESS"
            },
            {
                "value": "TEST",
                "label": "TEST"
            },
            {
                "value": "TEST",
                "label": "TEST INTERNAL NAME"
            },
            {
                "value": "test"
            },
            {
                "value": "TET1"
            },
            {
                "value": "TFPS"
            },
            {
                "value": "TH04",
                "label": "Inactive"
            },
            {
                "value": "TH04"
            },
            {
                "value": "TH08",
                "label": "Inactive-CS-EMERGING MARKETS-ECM"
            },
            {
                "value": "TH08"
            },
            {
                "value": "TH20",
                "label": "Inactive"
            },
            {
                "value": "TH20"
            },
            {
                "value": "TH24",
                "label": "Inactive"
            },
            {
                "value": "TH24"
            },
            {
                "value": "TH33",
                "label": "Inactive"
            },
            {
                "value": "TH33"
            },
            {
                "value": "TH34",
                "label": "Inactive-CS - SMALL CAP GROWTH- ECM"
            },
            {
                "value": "TH34"
            },
            {
                "value": "TH69",
                "label": "Inactive"
            },
            {
                "value": "TH69"
            },
            {
                "value": "TLMS"
            },
            {
                "value": "TLOA"
            },
            {
                "value": "TREU",
                "label": "T. ROWE PRICE SHORT-TERM RESERVE FUND"
            },
            {
                "value": "TREU"
            },
            {
                "value": "TRPR",
                "label": "T ROWE PRICE - VARIOUS FUNDS"
            },
            {
                "value": "TRPR"
            },
            {
                "value": "TRVT",
                "label": "Inactive"
            },
            {
                "value": "TRVT"
            },
            {
                "value": "TSLM"
            },
            {
                "value": "TST3"
            },
            {
                "value": "TTT "
            },
            {
                "value": "TTT1"
            },
            {
                "value": "U.S.",
                "label": "Inactive"
            },
            {
                "value": "U480",
                "label": "Inactive-SSGA EURO SHORT TERM BOND FUND"
            },
            {
                "value": "UAWA",
                "label": "UAW GM RETIREES MEDICAL BENEFITS"
            },
            {
                "value": "UAWB",
                "label": "UAW CHRYSTLER RETIREES MEDICAL BENEFITS PLAN"
            },
            {
                "value": "UAWB"
            },
            {
                "value": "UAWC",
                "label": "UAW FORD RETIREES MEDICAL BENEFITS PLAN"
            },
            {
                "value": "UAWC"
            },
            {
                "value": "UBMM",
                "label": "UBS RMA MONEY MARKET PORTFOLIO"
            },
            {
                "value": "UBMM"
            },
            {
                "value": "UBRE",
                "label": "Inactive"
            },
            {
                "value": "UBRE"
            },
            {
                "value": "UBSG",
                "label": "UBS GOVERNMENT"
            },
            {
                "value": "UFA1",
                "label": "UFCW BENEFIT PLAN COLLATERAL F"
            },
            {
                "value": "UFA1"
            },
            {
                "value": "UFCP",
                "label": "UFCW PENSION PLAN COLLATERAL F"
            },
            {
                "value": "UFCP"
            },
            {
                "value": "UKSG",
                "label": "Inactive-BELLSOUTH SSGA CASH"
            },
            {
                "value": "UNIV",
                "label": "Inactive"
            },
            {
                "value": "UNMA"
            },
            {
                "value": "UPEN",
                "label": "Inactive"
            },
            {
                "value": "V540"
            },
            {
                "value": "V541"
            },
            {
                "value": "vani"
            },
            {
                "value": "VC66"
            },
            {
                "value": "VC77"
            },
            {
                "value": "VC88"
            },
            {
                "value": "VC99"
            },
            {
                "value": "VH01"
            },
            {
                "value": "VH02"
            },
            {
                "value": "VH03"
            },
            {
                "value": "VMUE",
                "label": "Inactive"
            },
            {
                "value": "VMUE"
            },
            {
                "value": "VMUG",
                "label": "Inactive"
            },
            {
                "value": "VMUG"
            },
            {
                "value": "VMUT",
                "label": "Inactive"
            },
            {
                "value": "VMUT"
            },
            {
                "value": "VR01"
            },
            {
                "value": "VT01",
                "label": "Inactive"
            },
            {
                "value": "WICU",
                "label": "WATER ISLAND CAPITAL"
            },
            {
                "value": "WNTE",
                "label": "Inactive"
            },
            {
                "value": "WNTE"
            },
            {
                "value": "WNTU",
                "label": "Inactive"
            },
            {
                "value": "WNTU"
            },
            {
                "value": "XCXJ",
                "label": "ABBEY LIFE ASSURANCE COMPANY"
            },
            {
                "value": "XCXJ"
            },
            {
                "value": "XCXL",
                "label": "ABBEY LIFE ASSURANCE COMPANY LIMITED"
            },
            {
                "value": "XCXL"
            },
            {
                "value": "XJPY",
                "label": "Inactive"
            },
            {
                "value": "XXXX",
                "label": "Inactive"
            },
            {
                "value": "xxxx",
                "label": "Inactive"
            },
            {
                "value": "XYY9",
                "label": "Inactive-AMERICAN LEGACY OPERATING FUND"
            },
            {
                "value": "YWU1",
                "label": "YWU1"
            },
            {
                "value": "YWU2",
                "label": "YWU2"
            },
            {
                "value": "YY01"
            },
            {
                "value": "YYYY",
                "label": "LAMTA DURATION"
            },
            {
                "value": "Z33 "
            },
            {
                "value": "ZC5I"
            },
            {
                "value": "ZZ01"
            },
            {
                "value": "ZZAR",
                "label": "TEST"
            },
            {
                "value": "zzzz",
                "label": "Inactive"
            }
        ],
        "srccollcodes": [
            {
                "value": "00",
                "label": "EUROCLEAR SET 00"
            },
            {
                "value": "01",
                "label": "EUROCLEAR SET 01"
            },
            {
                "value": "02",
                "label": "EUROCLEAR SET 02"
            },
            {
                "value": "03",
                "label": "EUROCLEAR SET 03"
            },
            {
                "value": "04",
                "label": "EUROCLEAR SET 04"
            },
            {
                "value": "05",
                "label": "EUROCLEAR SET 05"
            },
            {
                "value": "06",
                "label": "EUROCLEAR SET 06"
            },
            {
                "value": "07",
                "label": "EUROCLEAR SET 07"
            },
            {
                "value": "08",
                "label": "EUROCLEAR SET 08"
            },
            {
                "value": "09",
                "label": "EUROCLEAR SET 09"
            },
            {
                "value": "10",
                "label": "EUROCLEAR SET 10"
            },
            {
                "value": "A",
                "label": "US TREASURY BILLS, BONDS, NOTES"
            },
            {
                "value": "ABS",
                "label": "PRIVATE ASSET BACKED SECURITIES"
            },
            {
                "value": "ABS1",
                "label": "ASSET BACKED SECURITIES_A_ASSET BACKED SECURITIES_A_UAT"
            },
            {
                "value": "ABS2",
                "label": "ASSET BACKED SECURITIES_AA"
            },
            {
                "value": "ABS3",
                "label": "ASSET BACKED SECURITIES_AAA"
            },
            {
                "value": "ACMO",
                "label": "AGENCY"
            },
            {
                "value": "AMP",
                "label": "AUCTION MARKET PREFERREDS"
            },
            {
                "value": "B",
                "label": "US TREASURY STRIPS"
            },
            {
                "value": "B1",
                "label": "BONY PROFILE 01"
            },
            {
                "value": "B2",
                "label": "BONY PROFILE 02"
            },
            {
                "value": "B3",
                "label": "BONY PROFILE 03"
            },
            {
                "value": "B4",
                "label": "BONY PROFILE 04"
            },
            {
                "value": "B5",
                "label": "BONY PROFILE 05"
            },
            {
                "value": "BB",
                "label": "LT CORPORATE FIXED INCOME"
            },
            {
                "value": "BB1",
                "label": "CORP_HIGH YIELD_B3/B- (+)"
            },
            {
                "value": "BB2",
                "label": "CORP_INVESTMENT GRADE_BAA3/BBB- (+)"
            },
            {
                "value": "BB3",
                "label": "CORP_A3/A- (+)"
            },
            {
                "value": "BGS",
                "label": "BRITISH GOVERNMENT STOCK (GILTS)"
            },
            {
                "value": "BPB",
                "label": "BONY PROFILE B (EQUITY)"
            },
            {
                "value": "BPC",
                "label": "BONY PROFILE C (EQUITY)"
            },
            {
                "value": "C",
                "label": "US AGENCY BONDS & NOTES"
            },
            {
                "value": "C1",
                "label": "CLEARSTREAM SET 1"
            },
            {
                "value": "C2",
                "label": "CLEARSTREAM SET 2"
            },
            {
                "value": "C3",
                "label": "CLEARSTREAM SET 3"
            },
            {
                "value": "C4",
                "label": "CLEARSTREAM SET 4"
            },
            {
                "value": "C5",
                "label": "CLEARSTREAM SET 5"
            },
            {
                "value": "C6",
                "label": "CLEARSTREAM SET 6"
            },
            {
                "value": "C7",
                "label": "CLEARSTREAM SET 7"
            },
            {
                "value": "C8",
                "label": "CLEARSTREAM SET 8"
            },
            {
                "value": "CB",
                "label": "CONVERTIBLE BOND"
            },
            {
                "value": "CB1",
                "label": "CNVRT_HIGH YIELD_B3/B- (+)"
            },
            {
                "value": "CB2",
                "label": "CNVRT_INVESTMENT GRADE_BAA3/BBB-(+)"
            },
            {
                "value": "CB3",
                "label": "CNVRT_A3/A- (+)"
            },
            {
                "value": "CMO",
                "label": "COLLATERALIZED MORTGAGE OBLIGATION"
            },
            {
                "value": "CP",
                "label": "PRIVATE MONEY MARKET INSTRUMENTS"
            },
            {
                "value": "CP1",
                "label": "MONEY MARKETS_A2/P2"
            },
            {
                "value": "CP2",
                "label": "MONEY MARKETS_A1/P1"
            },
            {
                "value": "CV1",
                "label": "CONV HY (+) HC1"
            },
            {
                "value": "CV2",
                "label": "CONV HY (+) HC2"
            },
            {
                "value": "CV3",
                "label": "CONV HY (+) HC3"
            },
            {
                "value": "D",
                "label": "US AGENCY MORTGAGES"
            },
            {
                "value": "E",
                "label": "U.S. EQUITY"
            },
            {
                "value": "E2",
                "label": "EQ ETF (EX SPDRS)"
            },
            {
                "value": "E3",
                "label": "EQ RS3000"
            },
            {
                "value": "E4",
                "label": "EQ RS1000"
            },
            {
                "value": "EUR.SE",
                "label": "DEFAULT"
            },
            {
                "value": "L",
                "label": "LENDING COLLATERAL"
            },
            {
                "value": "MB",
                "label": "MUNI BONDS"
            },
            {
                "value": "MB1",
                "label": "MUNICIPAL BONDS_B3/B- (+)"
            },
            {
                "value": "MB2",
                "label": "MUNICIPAL BONDS_BAA3/BBB-(+)"
            },
            {
                "value": "MB3",
                "label": "MUNICIPAL BONDS_A3/A- (+)"
            },
            {
                "value": "PCMO",
                "label": "PRIVATE LABEL PASS THROUGH"
            },
            {
                "value": "SNAT",
                "label": "SUPRANATIONAL"
            },
            {
                "value": "SOV",
                "label": "SOVEREIGN"
            },
            {
                "value": "SOV1",
                "label": "SOVGN CORE AAA"
            },
            {
                "value": "SOV2",
                "label": "SOVGN PERIPHERAL A"
            },
            {
                "value": "SOVEREIGN",
                "label": "SOVEREIGN DEBT USED BY SSGANONUS"
            },
            {
                "value": "UBG",
                "label": "UNSTRIPPED BRITISH GOVERNMENT STOCK (GILTS)"
            },
            {
                "value": "WL",
                "label": "WHOLE LOANS"
            }
        ],
        "gridData": {
            "count": 7690,
            "invVehicleCollAcctXRefDetails": [
                {
                    "SRCCTPYTXT": "DRES",
                    "CURRRECFLG": "Y",
                    "CTPYID": "G50644",
                    "VALIDFROMDT": "1980-01-01",
                    "SRCVEHICLETXT": "3HG2",
                    "ACTIVEFLG": "Y",
                    "LASTMODSIGNONDATE": "2006-06-02 00:00:00.0",
                    "TRIPARTYAGNTID": "EUROCLEAR",
                    "CTPYDMLNM": "COMMERZBANK AG",
                    "SOURCE": "SSGANONUS",
                    "LASTMODSIGNONID": "E416011",
                    "CTPYENTITYID": "006574",
                    "INVVEHINTERNALNM": "TEST",
                    "VALIDTODT": "2500-01-31",
                    "ROWID": "AABQHrAAQAAADWNAAA",
                    "COLLACCTID": "49905",
                    "SSGACOLLCD": "05"
                },
                {
                    "SRCCTPYTXT": "DRES",
                    "CURRRECFLG": "Y",
                    "CTPYID": "G50644",
                    "VALIDFROMDT": "1980-01-01",
                    "SRCVEHICLETXT": "3HG2",
                    "ACTIVEFLG": "Y",
                    "LASTMODSIGNONDATE": "2006-06-02 00:00:00.0",
                    "TRIPARTYAGNTID": "EUROCLEAR",
                    "CTPYDMLNM": "COMMERZBANK AG",
                    "SOURCE": "SSGANONUS",
                    "LASTMODSIGNONID": "E416011",
                    "CTPYENTITYID": "006574",
                    "INVVEHINTERNALNM": "SUOMEN PANKKI (FINLAND)",
                    "VALIDTODT": "2500-01-31",
                    "ROWID": "AABQHrAAQAAADWNAAA",
                    "COLLACCTID": "49905",
                    "SSGACOLLCD": "05"
                },
                {
                    "SRCCTPYTXT": "DRES",
                    "CURRRECFLG": "Y",
                    "CTPYID": "G50644",
                    "VALIDFROMDT": "1980-01-01",
                    "SRCVEHICLETXT": "3HG3",
                    "ACTIVEFLG": "Y",
                    "LASTMODSIGNONDATE": "2006-06-02 00:00:00.0",
                    "TRIPARTYAGNTID": "EUROCLEAR",
                    "CTPYDMLNM": "COMMERZBANK AG",
                    "SOURCE": "SSGANONUS",
                    "LASTMODSIGNONID": "E416011",
                    "CTPYENTITYID": "006574",
                    "VALIDTODT": "2500-01-31",
                    "ROWID": "AABQHrAAQAAADWNAAB",
                    "COLLACCTID": "49905",
                    "SSGACOLLCD": "05"
                },
                {
                    "SRCCTPYTXT": "DRES",
                    "CURRRECFLG": "Y",
                    "CTPYID": "G50644",
                    "VALIDFROMDT": "1980-01-01",
                    "SRCVEHICLETXT": "3HG4",
                    "ACTIVEFLG": "Y",
                    "LASTMODSIGNONDATE": "2006-06-02 00:00:00.0",
                    "TRIPARTYAGNTID": "EUROCLEAR",
                    "CTPYDMLNM": "COMMERZBANK AG",
                    "SOURCE": "SSGANONUS",
                    "LASTMODSIGNONID": "E416011",
                    "CTPYENTITYID": "006574",
                    "VALIDTODT": "2500-01-31",
                    "ROWID": "AABQHrAAQAAADWNAAC",
                    "COLLACCTID": "49905",
                    "SSGACOLLCD": "05"
                },
                {
                    "SRCCTPYTXT": "DRES",
                    "CURRRECFLG": "Y",
                    "CTPYID": "G50644",
                    "VALIDFROMDT": "1980-01-01",
                    "SRCVEHICLETXT": "3HG4",
                    "ACTIVEFLG": "Y",
                    "LASTMODSIGNONDATE": "2006-06-02 00:00:00.0",
                    "TRIPARTYAGNTID": "EUROCLEAR",
                    "CTPYDMLNM": "COMMERZBANK AG",
                    "SOURCE": "SSGANONUS",
                    "LASTMODSIGNONID": "E416011",
                    "CTPYENTITYID": "006574",
                    "INVVEHINTERNALNM": "CENTRAL BANK AND FINANCIAL SERVICES AUTHORITY OF IRELAND",
                    "VALIDTODT": "2500-01-31",
                    "ROWID": "AABQHrAAQAAADWNAAC",
                    "COLLACCTID": "49905",
                    "SSGACOLLCD": "05"
                },
                {
                    "SRCCTPYTXT": "DRES",
                    "CURRRECFLG": "Y",
                    "CTPYID": "G50644",
                    "VALIDFROMDT": "1980-01-01",
                    "SRCVEHICLETXT": "3HG5",
                    "ACTIVEFLG": "Y",
                    "LASTMODSIGNONDATE": "2006-06-02 00:00:00.0",
                    "TRIPARTYAGNTID": "EUROCLEAR",
                    "CTPYDMLNM": "COMMERZBANK AG",
                    "SOURCE": "SSGANONUS",
                    "LASTMODSIGNONID": "E416011",
                    "CTPYENTITYID": "006574",
                    "VALIDTODT": "2500-01-31",
                    "ROWID": "AABQHrAAQAAADWNAAD",
                    "COLLACCTID": "49905",
                    "SSGACOLLCD": "05"
                },
                {
                    "SRCCTPYTXT": "DRES",
                    "CURRRECFLG": "Y",
                    "CTPYID": "G50644",
                    "VALIDFROMDT": "1980-01-01",
                    "SRCVEHICLETXT": "3HG6",
                    "ACTIVEFLG": "Y",
                    "LASTMODSIGNONDATE": "2006-06-02 00:00:00.0",
                    "TRIPARTYAGNTID": "EUROCLEAR",
                    "CTPYDMLNM": "COMMERZBANK AG",
                    "SOURCE": "SSGANONUS",
                    "LASTMODSIGNONID": "E416011",
                    "CTPYENTITYID": "006574",
                    "VALIDTODT": "2500-01-31",
                    "ROWID": "AABQHrAAQAAADWNAAE",
                    "COLLACCTID": "49905",
                    "SSGACOLLCD": "05"
                },
                {
                    "SRCCTPYTXT": "DRES",
                    "CURRRECFLG": "Y",
                    "CTPYID": "G50644",
                    "VALIDFROMDT": "1980-01-01",
                    "SRCVEHICLETXT": "3HG6",
                    "ACTIVEFLG": "Y",
                    "LASTMODSIGNONDATE": "2006-06-02 00:00:00.0",
                    "TRIPARTYAGNTID": "EUROCLEAR",
                    "CTPYDMLNM": "COMMERZBANK AG",
                    "SOURCE": "SSGANONUS",
                    "LASTMODSIGNONID": "E416011",
                    "CTPYENTITYID": "006574",
                    "INVVEHINTERNALNM": "NATIONAL BANK OF KAZAKHSTAN",
                    "VALIDTODT": "2500-01-31",
                    "ROWID": "AABQHrAAQAAADWNAAE",
                    "COLLACCTID": "49905",
                    "SSGACOLLCD": "05"
                },
                {
                    "SRCCTPYTXT": "DRES",
                    "CURRRECFLG": "Y",
                    "CTPYID": "G50644",
                    "VALIDFROMDT": "1980-01-01",
                    "SRCVEHICLETXT": "3HG7",
                    "ACTIVEFLG": "Y",
                    "LASTMODSIGNONDATE": "2006-06-02 00:00:00.0",
                    "TRIPARTYAGNTID": "EUROCLEAR",
                    "CTPYDMLNM": "COMMERZBANK AG",
                    "SOURCE": "SSGANONUS",
                    "LASTMODSIGNONID": "E416011",
                    "CTPYENTITYID": "006574",
                    "VALIDTODT": "2500-01-31",
                    "ROWID": "AABQHrAAQAAADWNAAF",
                    "COLLACCTID": "49905",
                    "SSGACOLLCD": "05"
                },
                {
                    "SRCCTPYTXT": "DRES",
                    "CURRRECFLG": "Y",
                    "CTPYID": "G50644",
                    "VALIDFROMDT": "1980-01-01",
                    "SRCVEHICLETXT": "3HG7",
                    "ACTIVEFLG": "Y",
                    "LASTMODSIGNONDATE": "2006-06-02 00:00:00.0",
                    "TRIPARTYAGNTID": "EUROCLEAR",
                    "CTPYDMLNM": "COMMERZBANK AG",
                    "SOURCE": "SSGANONUS",
                    "LASTMODSIGNONID": "E416011",
                    "CTPYENTITYID": "006574",
                    "INVVEHINTERNALNM": "BANK OF ENGLAND",
                    "VALIDTODT": "2500-01-31",
                    "ROWID": "AABQHrAAQAAADWNAAF",
                    "COLLACCTID": "49905",
                    "SSGACOLLCD": "05"
                }
            ],
            "recPerPage": 10
        },
        "collAccData": [
            {
                "value": "105",
                "label": "Test Data1"
            },
            {
                "value": "106",
                "label": "Test Data 2"
            },
            {
                "value": "107",
                "label": "Test Data 3"
            }
        ],
        "entityData": [
            {
                "value": "105",
                "label": "Test Data1"
            },
            {
                "value": "106",
                "label": "Test Data2"
            },
            {
                "value": "107",
                "label": "Test Data3"
            }
        ]
};

export default data;