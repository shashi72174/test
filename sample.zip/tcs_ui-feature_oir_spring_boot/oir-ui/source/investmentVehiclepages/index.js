import React, { Component } from "react"
import PropTypes from 'prop-types'
import { Button, connectRest, AlertBanner, DataGrid } from 'ssc-cdt4'
import yup from 'yup'
import moment from 'moment'
import {FormComponent, ModalComponent} from './commonComponents';

// Constants
const now = moment()
const currentDate = (new Date().getMonth()+1)+"/"+(new Date().getDate())+"/"+(new Date().getFullYear())
let endDt = new Date("2500","0","31") 
const validEndDate = (endDt.getMonth()+1)+"/"+endDt.getDate()+"/"+endDt.getFullYear()
const activeflg = [{ value: '0', label: 'ALL' }, { value: 'Y', label: 'Y-Active' }, { value: 'N', label: 'N-inActive' }]
const modactiveflg = [{ value: 'Y', label: 'Y-Active' }, { value: 'N', label: 'N-inActive' }]
const temp = [{}]
const disabledBtn = true;
const assets = {
    "pageTitle": "Investment Vehicle to Collateral Account Cross Reference",
    "gridTitle": "Investment Vehicle to Collateral Account Cross Reference List",
    "createModalTitle": "Investment Vehicle to Collateral Account Cross Reference Detail-Create",
    "modifyModalTitle": "Investment Vehicle to Collateral Account Cross Reference Detail-Modify",
    "activeInactiveModalTitle": `Is this modification a correction to existing data, or a change to processing data? If it 
        is a change to processing data, please also include the effective date of the change.`,
    "dateModifyModalTitle": "You have modified the effective date; do you wish to proceed with this change",
    "effectiveDateModalTitle" : `Is this modification a correction to existing data, or a change to processing data? 
        If it is a change to processing data, please also include the effective date of the change`
};

let defaultStr = yup.string().default('')
let dateType = yup.object() 
    .required('Please Fill This Field')
    .test('is-format',
        'Enter Date in MM/DD/YYYY format',
        value => {
            if (value) {
                const today = moment()
                return today.isValid.call(value)
            }
            else {
                return true
            }
        })
const effectiveDate_Schema = yup.object({
    date_required: dateType.default(now)
});

// Page Schema for form data
let PageSchema = yup
    .object({
        source: defaultStr,
        triparty_agentfile: defaultStr,
        src_inv_veh_id: defaultStr,
        active_flag: defaultStr,
        fromdate_required:  yup
		    .date()
		    .default(new Date(currentDate))
		    .required('Please Fill This Field'),
	    todate_required: yup
		    .date()
		    .default(new Date(validEndDate))
		    .max(new Date(validEndDate), `To Date should be equal or earlier than ${validEndDate}`)
		    .required('Please Fill This Field'),
        collAcc: defaultStr,
        ctpy_entity_id: defaultStr,
        src_coll_code: defaultStr,
        lastModified: defaultStr,
        userId: defaultStr,
        iv_internm: defaultStr,
        dml_ctpynm: defaultStr,
        ctpysrc_id: defaultStr,
        dml_ctpyid: defaultStr
    })

    let CreatePageSchema = yup
    .object({
        source: yup.string(),
        triparty_agentfile: yup.string().required('Please Fill This Field'),
        src_inv_veh_id: yup.string().required('Please Fill This Field'),
        active_flag: defaultStr.required('Please Fill This Field'),
        fromdate_required: yup.date().default(new Date(currentDate)),
        todate_required: yup.date().default(new Date(validEndDate)),
        collAcc: yup.string().required('Please Fill This Field'),
        ctpy_entity_id: yup.string().nullable(),
        src_coll_code: yup.string().required('Please Fill This Field'),
        lastModified: defaultStr,
        userId: defaultStr,
        iv_internm: yup.string().nullable(),
        dml_ctpynm: yup.string().nullable(),
        ctpysrc_id: yup.string().required('Please Fill This Field'),
        dml_ctpyid: yup.string().nullable()
    }) 
    
    let UpdatePageSchema = yup
    .object({
        source: defaultStr,
        triparty_agentfile: defaultStr,
        src_inv_veh_id: defaultStr,
        active_flag: defaultStr,
        fromdate_required:  yup
		    .date()
		    .default(new Date(currentDate)),
		todate_required: yup
		    .date()
		    .default(new Date(validEndDate)),
        collAcc: defaultStr,
        ctpy_entity_id: defaultStr.nullable(),
        src_coll_code: defaultStr,
        lastModified: defaultStr.nullable(),
        userId: defaultStr.nullable(),
        iv_internm: defaultStr.nullable(),
        dml_ctpynm: defaultStr.nullable(),
        ctpysrc_id: defaultStr.nullable(),
        dml_ctpyid: defaultStr.nullable()
    }) 
// Grid columns
//investmentVehicleCollAcctXRefConfig
export const investmentVehicleCollAcctXRefConfig = [
    {
        dataKey: 'sourceVehicleText',
        label: 'SRCVEHICLETXT',
        width: 140,
        dataType: 'string',
        align:'left'
    },
    {
        dataKey: 'triPartyAgentId',
        label: 'TRIPARTYAGNTID',
        width: 150,
        dataType: 'string',
        align:'left'
    },
    {
        dataKey: 'sourceCtpytxt',
        label: 'SRCCTPYTXT',
        width: 120,
        dataType: 'string',
        align:'left'
    },
    {
        dataKey: 'ctpyEntityId',
        label: 'CTPYENTITYID',
        width: 120,
        dataType: 'string',
        align:'left'
    },
    {
        dataKey: 'sourceCode',
        label: 'SOURCE',
        width: 120,
        dataType: 'string',
        align:'left'
    },
    {
        dataKey: 'invVehInvestmentNM',
        label: 'INVVEHINTERNALNM',
        width: 210,
        dataType: 'string',
        align:'left'
    },
    {
        dataKey: 'ctpyId',
        label: 'CTPYID',
        width: 120,
        dataType: 'string',
        align:'left'
    },
    {
        dataKey: 'ctpyDMLNM',
        label: 'CTPYDMLNM',
        width: 200,
        dataType: 'string',
        align:'left'
    },
    {
        dataKey: 'ssgaCollCode',
        label: 'SSGACOLLCD',
        width: 120,
        dataType: 'string',
        align:'left'
    },
    {
        dataKey: 'collateralAcct',
        label: 'COLLACCTID',
        width: 120,
        dataType: 'string',
        align:'left'
    },
    {
        dataKey: 'validFromDate',
        label: 'VALIDFROMDT',
        width: 120,
        dataType: 'string',
        align:'left'
    },
    {
        dataKey: 'validToDate',
        label: 'VALIDTODT',
        width: 120,
        dataType: 'string',
        align:'left'
    },
    {
        dataKey: 'activeFlag',
        label: 'ACTIVEFLG',
        width: 120,
        dataType: 'string',
        align:'left'
    },
    {
        dataKey: 'lastModifiedId',
        label: 'LASTMODSIGNONID',
        width: 130,
        dataType: 'string',
        align:'left'
    },
    {
        dataKey: 'lastModifiedDate',
        label: 'LASTMODSIGNONDATE',
        width: 150,
        dataType: 'string',
        align:'left'
    }

];

@connectRest('InvestmentVehicleFilterList')
@connectRest('saveInvVehicleDetails')
@connectRest('populateCollatCodeList')
@connectRest('getInvVehicleAllDD')
export default class Template extends Component {
    constructor(props) {
        super(props);
        this.state = {
            source_DD: [],
            triparty_DD: [],
            validFrom: '',
            validTo: '',
            srcInvVehId_DD: [],
            srcCollCodes_DD: [],
            filterCriteria_FormValues : {},
            gridData: [],
            disableModifyBtn: true,
            gridRowSelected : {},
            showCreateModal: false,
            collAcc_DD: [],
            ctpyentity_id_DD: [],
            createModal_FormValues: {},
            pageError: false,
            recordsPerPage : 0,
            totalrecords : 0,
            filterCompChanges : {},
            nextPageValue : 0,
            prePageValue : 0,
            //ch-in
            showSelect: false,
            showModifyModal: false,
            all: 'ALL',
            disableModalSaveBtn: true,
            modalLevelError: false,
            modalLevelErrorMsg: "",
            showDateModifyModal: false,
            showActiveInactiveModal: false,
            DB_gridRowData: [],
            showEffectiveModal: false,
            effectiveChangedDate: "",
            disableBtn: false,
            nextModalLevelError: false, nextModalLevelErrorMsg:"",
            disabledNxtBtn: true,
            disabledPreBtn : true,
            isFormSubmitted: false,
            formSubmittedMessage: "",
            alertType: "",
            modalErrorType: '',
            showParentAlert: false
        };
        this.handleFilterComponentChange = this.handleFilterComponentChange.bind(this);
        this.handleClear = this.handleClear.bind(this);
        this.onCheckedGridRowClick = this.onCheckedGridRowClick.bind(this);
        this.showCreateModal = this.showCreateModal.bind(this);
        this.callTripartyChange = this.callTripartyChange.bind(this);
        this.hideCreateModal = this.hideCreateModal.bind(this);
        this.handleNextPagination = this.handleNextPagination.bind(this);
        this.handlePrePagination = this.handlePrePagination.bind(this);
        this.hideModifyModal = this.hideModifyModal.bind(this);
        this.showModifyModal = this.showModifyModal.bind(this);
        this.callCreateModalSave = this.callCreateModalSave.bind(this);
        this.callModifyModalSave = this.callModifyModalSave.bind(this);
        this.callModifyModalChange = this.callModifyModalChange.bind(this);
        this.callCreateModalChange = this.callCreateModalChange.bind(this);
        this.hideActiveInactiveModal = this.hideActiveInactiveModal.bind(this);
        this.hideDateModifyModal = this.hideDateModifyModal.bind(this);
        this.ontripartyCorrectionClick = this.ontripartyCorrectionClick.bind(this);
        this.onEffectiveDateChange = this.onEffectiveDateChange.bind(this);
        this.handleEffectiveDateChangeSubmit = this.handleEffectiveDateChangeSubmit.bind(this);
        this.hideEffectiveDateModal = this.hideEffectiveDateModal.bind(this);
        this.activeInactiveChangeOverlay =this.activeInactiveChangeOverlay.bind(this);
        this.activeInactiveCorrectionOverlay = this.activeInactiveCorrectionOverlay.bind(this);
        this.handleFilterSubmit = this.handleFilterSubmit.bind(this);
        this.handleValidFromDateChange = this.handleValidFromDateChange.bind(this);
        this.closeBanner = this.closeBanner.bind(this);

    }
    // Will execute before the component gets mounted to dom for the first time.
    componentDidMount = () => {
        let param = {}
        const {InvestmentVehicleFilterListActions,getInvVehicleAllDDActions}=this.props;
            getInvVehicleAllDDActions.list(param).then(res=>{
            	if(typeof this.props.getInvVehicleAllDD.error==='object' && this.props.getInvVehicleAllDD.error.errorMsg!='undefined'){
            		const type = 'warning'
            			AlertBanner.show(type,`Error processing request:please try after some time`)
            	}else{
            		this.setState({source_DD:this.props.getInvVehicleAllDD.data[0].sourceList})
            		this.setState({srcInvVehId_DD:this.props.getInvVehicleAllDD.data[0].invVehicleList})
            		this.setState({triparty_DD:this.props.getInvVehicleAllDD.data[0].tripartyList})
            		this.setState({srcCollCodes_DD:this.props.getInvVehicleAllDD.data[0].srcCollCode})
            	}
            	})
            
	    /*InvestmentVehicleFilterListActions.list({paginationType:'next',pageNo:1,searchTypeFlag:'1'}).
	    then(res => {
            if(typeof this.props.InvestmentVehicleFilterList.error==='object' && this.props.InvestmentVehicleFilterList.error.errorMsg!='undefined'){
            	const type = 'warning'
        			AlertBanner.show(type,`Error processing request:please try after some time`)
            }else{
	    	this.setState({gridData:this.props.InvestmentVehicleFilterList.data[0].investmentVehicleList})
	    	if(null!=this.props.InvestmentVehicleFilterList.data[0].totalRecords){
                this.setState({totalrecords:this.props.InvestmentVehicleFilterList.data[0].totalRecords})
                this.setState({recordsPerPage:this.props.InvestmentVehicleFilterList.data[0].recordsPerPage})
	    	if (JSON.stringify(this.props.InvestmentVehicleFilterList.data[0].totalRecords)>=10){
	    		this.setState({disabledNxtBtn : false, prePageValue : 1 ,nextPageValue : 2})}	
	        if ( this.props.InvestmentVehicleFilterList.data[0].isNextDisable === 'Y'){
    		    this.setState({disabledNxtBtn : true})}
	        }
            }
        });*/
            	this.loadGridData();
              
}
    loadGridData() {
    	const {InvestmentVehicleFilterListActions}=this.props;
    	InvestmentVehicleFilterListActions.list({paginationType:'next',pageNo:1,searchTypeFlag:'1'}).
	    then(res => {
            if(typeof this.props.InvestmentVehicleFilterList.error==='object' && this.props.InvestmentVehicleFilterList.error.errorMsg!='undefined'){
            	const type = 'warning'
        			AlertBanner.show(type,`Error processing request:please try after some time`)
            }else{
	    	this.setState({gridData:this.props.InvestmentVehicleFilterList.data[0].investmentVehicleList})
	    	if(null!=this.props.InvestmentVehicleFilterList.data[0].totalRecords){
                this.setState({totalrecords:this.props.InvestmentVehicleFilterList.data[0].totalRecords})
                this.setState({recordsPerPage:this.props.InvestmentVehicleFilterList.data[0].recordsPerPage})
	    	if (JSON.stringify(this.props.InvestmentVehicleFilterList.data[0].totalRecords)>=10){
	    		this.setState({disabledNxtBtn : false, prePageValue : 1 ,nextPageValue : 2})}	
	        if ( this.props.InvestmentVehicleFilterList.data[0].isNextDisable === 'Y'){
    		    this.setState({disabledNxtBtn : true})}
	        }
            }
        });
    }
    handleFilterComponentChange = (event) => {
        this.setState({'filterCompChanges' : event}); 
    }
    handleClear = () => {
        this.setState({'filterCompChanges' : PageSchema});
        this.loadGridData();
    }
    onCheckedGridRowClick = (event) => {
        if(event.length == 0) {
            this.setState({disableModifyBtn : true});
        }
        else if(event.length == 1) {
            this.setState({disableModifyBtn : false, gridRowSelected: event[0]});
        }
        else {
            this.setState({disableModifyBtn : true});
        }
    }
    showCreateModal(){
        this.setState({showCreateModal: true, showSelect: true});
    }
    showModifyModal(){
        let gridRowSelected = this.state.gridRowSelected;
        if(gridRowSelected.currentRecFlag === 'N'){
        	this.setState({
        		formSubmittedMessage: "You can only modify the most recent Valid From record.",
                alertType: "warning",
                showParentAlert: true
        	});
        }
        else {
        	if(this.state.gridRowSelected.activeFlag==='Y')
        		this.setState({gridRowSelected:{...gridRowSelected, activeFlag : 'Y-Active'}});
        	else if(this.state.gridRowSelected.activeFlag==='N')
        		this.setState({gridRowSelected:{...gridRowSelected, activeFlag : 'N-inActive'}});   
        	this.setState({showModifyModal: true, showSelect: true});
        }
    }
    callTripartyChange = (event) => {
        const { populateCollatCodeListActions }= this.props; 
        populateCollatCodeListActions.list({triPartyAgentId:event}).then(res => {this.setState({collAcc_DD:this.props.populateCollatCodeList.data}) })
    }
    formatDate(date) {
    	return date 
    		? `${date.getMonth()> 9?'':'0'}${date.getMonth()+1}/${date.getDate()> 9?'':'0'}${date.getDate()}/${date.getFullYear()}`
    		: ""
    }
    handleFilterSubmit = (event)=>{
        const { InvestmentVehicleFilterListActions }= this.props;
        this.setState({disabledNxtBtn : true, disabledPreBtn:true, prePageValue : 1 ,nextPageValue : 1});
        const { filterCompChanges } = this.state;
        const fromDate = filterCompChanges.fromdate_required 
        	? this.formatDate(new Date(filterCompChanges.fromdate_required))
        	: this.formatDate(new Date(event.fromdate_required));
        const toDate = filterCompChanges.todate_required 
    		? this.formatDate(new Date(filterCompChanges.todate_required))
            : this.formatDate(new Date(event.todate_required));
        InvestmentVehicleFilterListActions.list({paginationType:'next',pageNo:1,sourceCode:this.state.filterCompChanges.source,
        	triPartyAgentId:this.state.filterCompChanges.triparty_agentfile,ctpyEntityId:this.state.filterCompChanges.ctpy_entity_id,
        	sourceInvvehicleId:this.state.filterCompChanges.src_inv_veh_id,srcCollCode:this.state.filterCompChanges.src_coll_code,
        	collateralAcct:this.state.filterCompChanges.collAcc,validFromDate:fromDate,
        	validToDate:toDate,activeFlag:this.state.filterCompChanges.active_flag}).
        then(res => {this.setState({gridData:this.props.InvestmentVehicleFilterList.data[0].investmentVehicleList})
        if(null!=this.props.InvestmentVehicleFilterList.data[0].totalRecords){
                this.setState({totalrecords:this.props.InvestmentVehicleFilterList.data[0].totalRecords})
                this.setState({recordsPerPage:this.props.InvestmentVehicleFilterList.data[0].recordsPerPage})
        if (JSON.stringify(this.props.InvestmentVehicleFilterList.data[0].totalRecords)>=10){
                this.setState({disabledNxtBtn : false, disabledPreBtn:true,prePageValue : 1 ,nextPageValue : 2}) 
        }else{
                this.setState({disabledNxtBtn : true, disabledPreBtn:true,prePageValue : 1 ,nextPageValue : 2})
            } }	
        if (JSON.stringify(this.props.InvestmentVehicleFilterList.data[0].isNextDisable) === 'Y'){
            this.setState({disabledNxtBtn : true})
            }
        })
    }
    callCreateModalChange(event) {
        this.setState({modal_FormValues: event, disableModalSaveBtn: false, modalLevelError: false});
    }
    callModifyModalChange(event) {
        this.setState({modal_FormValues: event, disableModalSaveBtn: false, modalLevelError: false});
    }
    callModifyModalSave() {
    	this.setState({modalErrorType: ""});
        let showEffective = true;
        const { modal_FormValues, modalLevelError , modalLevelErrorMsg, showDateModifyModal, gridRowSelected } = this.state;
        let today = new Date();
        let validFrDate = new Date(modal_FormValues.fromdate_required);
        let gridValidFrmDate = new Date(gridRowSelected.validFromDate);
        let triPartyAgentId, collateralAcct, activeFlag;
        const compareDate = gridValidFrmDate.getFullYear()!==validFrDate.getFullYear() || 
        	(gridValidFrmDate.getMonth()+1)!==(validFrDate.getMonth()+1) || gridValidFrmDate.getDate()!==validFrDate.getDate();
    	this.state.triparty_DD.forEach((item) => {
    		if(item.label === gridRowSelected.triPartyAgentId) {
    			triPartyAgentId = item.value;
    		}
    	});
    	this.state.collAcc_DD.forEach((item) => {
    		if(item.label === gridRowSelected.collateralAcct) {
    			collateralAcct = item.value;
    		}
    	});
    	activeflg.forEach((item) => {
    		if(item.label === gridRowSelected.activeFlag) {
    			activeFlag = item.value;
    		}
    	});
    	if((modal_FormValues.triparty_agentfile === triPartyAgentId && modal_FormValues.collAcc === collateralAcct)
    			&& !compareDate && modal_FormValues.active_flag === activeFlag){
    		showEffective = false;
    		this.setState({
                modalLevelError: true,
                disableModalSaveBtn: true,
                modalLevelErrorMsg: `No Changes to update`,
                modalErrorType: 'confirmation'
            });
    	}
        if( modal_FormValues.triparty_agentfile!== triPartyAgentId || modal_FormValues.collAcc !== collateralAcct  ) {
            if(modal_FormValues.active_flag !== activeFlag ) {
                showEffective = false;
                this.setState({
                    modalLevelError: true,
                    disableModalSaveBtn: true,
                    modalLevelErrorMsg: `You cannot change data elements and the Active/Inactive flag at the same time. 
                        Please process data element change first.`
                });
            }
            if(compareDate) {
            	showEffective = false;
            	this.setState({
            		modalLevelError: true,
            		disableModalSaveBtn: true,
            		modalLevelErrorMsg: `You cannot change data elements and the Effective Date at the same time.
            			Please process the data element change first. If required, enter Effective Date when prompted.`
            	});
            }
            if(showEffective){
                this.setState({showEffectiveModal: true});
            }
            
        }
        else if(modal_FormValues.active_flag !== activeFlag && compareDate) {
        	this.setState({
        		modalLevelError: true,
        		disableModalSaveBtn: true,
        		modalLevelErrorMsg: `You cannot change data elements like  the Effective Date and the Active/Inactive flag at the same time.
        			Please process the data element change first. If required, enter Effective Date when prompted.`
        	});
        }
        else if(validFrDate !== gridValidFrmDate && validFrDate > today) {
            this.setState({
                modalLevelError: true,
                disableModalSaveBtn: true,
                modalLevelErrorMsg: "Effective Date cannot be greater than today"
            });
        }
        else if( modal_FormValues.active_flag !== activeFlag && !compareDate
        		&& (modal_FormValues.triparty_agentfile === triPartyAgentId 
        				|| modal_FormValues.collAcc === collateralAcct) ) {
            this.setState({showActiveInactiveModal: true});
        }
        else if(compareDate
        		&& (modal_FormValues.triparty_agentfile === triPartyAgentId 
        				|| modal_FormValues.collAcc === collateralAcct) && modal_FormValues.active_flag === activeFlag) {
            this.setState({showDateModifyModal: true});
        }
    }

    hideCreateModal(){
        this.setState({showCreateModal: false, showSelect: false, modal_FormValues: PageSchema, modalLevelError: false, disableModalSaveBtn : true, collAcc_DD : []});
    }
    hideModifyModal(){
        this.setState({showModifyModal: false, showSelect: false, modalErrorType: "",
            modal_FormValues: PageSchema, disableModalSaveBtn: true, modalLevelError: false, disableModalSaveBtn : true, collAcc_DD : []});
    }
    callCreateModalSave(event) {
        const { saveInvVehicleDetailsActions }= this.props;
        const { source, triparty_agentfile, src_inv_veh_id, 
            collAcc, ctpy_entity_id, src_coll_code, userId, iv_internm, 
                dml_ctpynm, ctpysrc_id, dml_ctpyid,fromdate_required } = this.state.modal_FormValues;
        let active_flag = 'Y'
        let fromdate = this.formatDate(new Date(fromdate_required));
        let todate_required = validEndDate;
        let today = new Date();
        let validFrDate = new Date(fromdate_required);
        if(validFrDate>today) {
            this.setState({
                modalLevelError: true,
                disableModalSaveBtn: true,
                modalLevelErrorMsg: "Valid From date cannot be greater than today."
            });
        }
        const addToDb = {
            isDateUpdated:'N',
            sourceCode: source,
            triPartyAgentId: triparty_agentfile,
            validFromDate: fromdate,
            sourceInvvehicleId: src_inv_veh_id, 
            validToDate: todate_required,
            collateralAcct: collAcc,
            ctpyEntityId: ctpy_entity_id,
            srcCollCode: src_coll_code,
            activeFlag: active_flag,
            userName: userId,
            invVehInvestmentNM: iv_internm,
            ctpyDMLNM: dml_ctpynm,
            sourceCtpytxt: ctpysrc_id,
            ctpyId: dml_ctpyid
        }
        !this.state.modalLevelError && saveInvVehicleDetailsActions.add(addToDb).then( res => {
            const { data } = this.props.saveInvVehicleDetails;
            if(null!=data[0].errorDesc){
               this.setState({modalLevelError: true, 
                    modalLevelErrorMsg: "Failed to save data  due to :"+data[0].errorDesc
                    , disableModalSaveBtn: true, collAcc_DD : []})
   	    	}
            else{
               this.setState({showCreateModal: false, 
                isFormSubmitted: true, formSubmittedMessage: "Data Saved Sucessfully", collAcc_DD : [], 
                alertType: "confirmation", disableModalSaveBtn: true, modal_FormValues: {}});
               this.handleClear();
           }
       });
    }
    hideActiveInactiveModal(){
        this.setState({showActiveInactiveModal: false, collAcc_DD : []});
    }
    hideDateModifyModal (){
        this.setState({showDateModifyModal: false, collAcc_DD : []});
    }

    handlePrePagination = () => {
        const { InvestmentVehicleFilterListActions }= this.props;
        const { filterCompChanges } = this.state;
        const fromDate = filterCompChanges.fromdate_required 
	    	? this.formatDate(new Date(filterCompChanges.fromdate_required))
	    	: filterCompChanges.fromdate_required;
	    const toDate = filterCompChanges.todate_required 
			? this.formatDate(new Date(filterCompChanges.todate_required))
	        : filterCompChanges.todate_required;
	    InvestmentVehicleFilterListActions.list({paginationType:'pre',pageNo:(this.state.prePageValue-1<=0 ? 1 : this.state.prePageValue-1),
	    	sourceCode:this.state.filterCompChanges.source,triPartyAgentId:this.state.filterCompChanges.triparty_agentfile,
	    	ctpyEntityId:this.state.filterCompChanges.ctpy_entity_id,sourceInvvehicleId:this.state.filterCompChanges.src_inv_veh_id,
	    	srcCollCode:this.state.filterCompChanges.src_coll_code,collateralAcct:this.state.filterCompChanges.collAcc,
	    	validFromDate:fromDate,validToDate:toDate,activeFlag:this.state.filterCompChanges.active_flag}).
	    then(res => {
	    	this.setState({gridData:this.props.InvestmentVehicleFilterList.data[0].investmentVehicleList})
                this.setState({prePageValue : JSON.stringify(this.props.InvestmentVehicleFilterList.data[0].prePageNo) ,
                    nextPageValue : JSON.stringify(this.props.InvestmentVehicleFilterList.data[0].nextPageNo), 
                    recordsPerPage: this.props.InvestmentVehicleFilterList.data[0].recordsPerPage})
                if ( this.props.InvestmentVehicleFilterList.data[0].isNextDisable === 'Y'){ 
                   this.setState({disabledNxtBtn : true})
                }
                if(this.props.InvestmentVehicleFilterList.data[0].pageNumber === 1) {
                    this.setState({disabledPreBtn: true})
                }

		     }) 
    }

    handleNextPagination = () => {     
        const { InvestmentVehicleFilterListActions }= this.props;
        const { filterCompChanges } = this.state;
        const fromDate = filterCompChanges.fromdate_required 
	    	? this.formatDate(new Date(filterCompChanges.fromdate_required))
	    	: filterCompChanges.fromdate_required;
	    const toDate = filterCompChanges.todate_required 
			? this.formatDate(new Date(filterCompChanges.todate_required))
	        : filterCompChanges.todate_required;
	    InvestmentVehicleFilterListActions.list({paginationType:'next',pageNo:this.state.nextPageValue,sourceCode:this.state.filterCompChanges.source,
	    	triPartyAgentId:this.state.filterCompChanges.triparty_agentfile,ctpyEntityId:this.state.filterCompChanges.ctpy_entity_id,
	    	sourceInvvehicleId:this.state.filterCompChanges.src_inv_veh_id,srcCollCode:this.state.filterCompChanges.src_coll_code,
	    	collateralAcct:this.state.filterCompChanges.collAcc,validFromDate:fromDate,
	    	validToDate:toDate,activeFlag:this.state.filterCompChanges.active_flag}).
	    then(res => {
	    	this.setState({gridData:this.props.InvestmentVehicleFilterList.data[0].investmentVehicleList, disabledPreBtn: false})
                this.setState({prePageValue : JSON.stringify(this.props.InvestmentVehicleFilterList.data[0].prePageNo) ,
                    nextPageValue : JSON.stringify(this.props.InvestmentVehicleFilterList.data[0].nextPageNo), 
                    recordsPerPage: this.props.InvestmentVehicleFilterList.data[0].recordsPerPage})
	    		 if ( this.props.InvestmentVehicleFilterList.data[0].isNextDisable === 'Y'){ 
                    this.setState({disabledNxtBtn : true})
	    		 }
		     }) 
    }
    ontripartyCorrectionClick() {
        const { saveInvVehicleDetailsActions }= this.props;
        const selectedGrid = this.state.gridRowSelected;
        let sourceCdVal = '';
        for(let i=0;i<this.state.source_DD.length;i++) {
            if(this.state.source_DD[i].label==this.state.gridRowSelected.sourceCode) {
                sourceCdVal = this.state.source_DD[i].value;
            }
        }
        let tripartyVal = '';
        for(let i=0;i<this.state.triparty_DD.length;i++) {
            if(this.state.triparty_DD[i].label==this.state.gridRowSelected.triPartyAgentId) {
                tripartyVal = this.state.triparty_DD[i].value;
            }
        }
        const addToService = {
            iModValue:"U",
            rowId: selectedGrid.rowId,
            sourceCode: sourceCdVal,
            triPartyAgentId: this.state.modal_FormValues.triparty_agentfile ? this.state.modal_FormValues.triparty_agentfile : tripartyVal,
            validFromDate: selectedGrid.validFromDate,
            invVehicleId: selectedGrid.sourceVehicleText, 
            validToDate: selectedGrid.validToDate,
            collateralAcct: this.state.modal_FormValues.collAcc ? this.state.modal_FormValues.collAcc : selectedGrid.collateralAcct,
            ctpyEntityId: selectedGrid.ctpyEntityId,
            srcCollCode: selectedGrid.ssgaCollCode,
            activeFlag: selectedGrid.activeFlag,
            userName: selectedGrid.userName,
            invVehInvestmentNM: selectedGrid.invVehInvestmentNM,
            ctpyDMLNM: selectedGrid.ctpyDMLNM,
            sourceCtpytxt: selectedGrid.sourceCtpytxt,
            ctpyId: selectedGrid.ctpyId
        };
	    saveInvVehicleDetailsActions.add(addToService).then(res => {
            const { data } = this.props.saveInvVehicleDetails;
            if(null !== data[0].errorDesc){
                this.setState({ modalLevelError: true, 
                    modalLevelErrorMsg: "Failed to update data  due to :"+data[0].errorDesc , collAcc_DD : [],
                    showEffectiveModal: false, modal_FormValues: PageSchema, disableModalSaveBtn: true})}
	    	else{ 
                this.setState({showEffectiveModal: false, isFormSubmitted: true, collAcc_DD : [], 
                    formSubmittedMessage: "Data Saved Sucessfully", alertType: "confirmation"})
                this.hideModifyModal();
                this.handleClear();
            }
	    });
    }
    onEffectiveDateChange(event){
        this.setState({modal_FormValues : event,effectiveChangedDate : event.date_required,nextModalLevelError : false, disableBtn: false});
    }
    handleEffectiveDateChangeSubmit() {
        const myDate = new Date(this.state.effectiveChangedDate);
        const today = new Date();
        const validFrDate = new Date(this.state.gridRowSelected.validFromDate);
        let sourceCdVal = '';
        for(let i=0;i<this.state.source_DD.length;i++) {
            if(this.state.source_DD[i].label==this.state.gridRowSelected.sourceCode) {
                sourceCdVal = this.state.source_DD[i].value;
            }
        }
        let tripartyVal = '';
        for(let i=0;i<this.state.triparty_DD.length;i++) {
            if(this.state.triparty_DD[i].label==this.state.gridRowSelected.triPartyAgentId) {
                tripartyVal = this.state.triparty_DD[i].value;
            }
        }
        if ( myDate > today ) { //future date
            this.setState({
                nextModalLevelError: true,
                effectiveChangedDate: "",
                nextModalLevelErrorMsg: "Effective Date cannot be greater than today"
            });
        }else if(myDate.setHours(0,0,0,0) == today.setHours(0,0,0,0)) {
            this.setState({
                nextModalLevelError: true,
                effectiveChangedDate: "",
                nextModalLevelErrorMsg: `Effective Date cannot be the equal to Current Valid From date 
                    for a change. It can only be a correction.`
            });
        }else if ( myDate < validFrDate ) { //entered date is less than today's date
            // alert('Effective Date should be greater than Current Valid From Date ');
            this.setState({
                nextModalLevelError: true,
                effectiveChangedDate: "",
                nextModalLevelErrorMsg: "Effective Date should be greater than Current Valid From Date"
            });
        }        
        const { saveInvVehicleDetailsActions }= this.props;
        if(!this.state.nextModalLevelError){
            const selectedGrid = this.state.gridRowSelected;
            const addToService = {
                iModValue:"C",
                rowId: selectedGrid.rowId,
				sourceCode: sourceCdVal,
				triPartyAgentId: this.state.modal_FormValues.triparty_agentfile ? this.state.modal_FormValues.triparty_agentfile : tripartyVal,
				validFromDate: (myDate.getMonth()+1)+"/"+myDate.getDate()+"/"+myDate.getFullYear(),
				invVehicleId: selectedGrid.sourceVehicleText, 
				validToDate: selectedGrid.validToDate,
				collateralAcct: this.state.modal_FormValues.collAcc ? this.state.modal_FormValues.collAcc : selectedGrid.collateralAcct,
				ctpyEntityId: selectedGrid.ctpyEntityId,
				srcCollCode: selectedGrid.ssgaCollCode,
				activeFlag: selectedGrid.activeFlag,
				userName: selectedGrid.userName,
				invVehInvestmentNM: selectedGrid.invVehInvestmentNM,
				ctpyDMLNM: selectedGrid.ctpyDMLNM,
				sourceCtpytxt: selectedGrid.sourceCtpytxt,
				ctpyId: selectedGrid.ctpyId
            };
            saveInvVehicleDetailsActions.add(addToService).then(res => {
                const data = this.props.saveInvVehicleDetails.data[0];
                
                if(null !== data.errorDesc){
                    this.setState({showEffectiveModal:false, modal_FormValues: {}, collAcc_DD : [],
                    modalLevelError: true, modalLevelErrorMsg: `Failed to update data  due to : ${data.errorDesc}`,
                    disableModalSaveBtn: true
                });
                }
                else { 
                    this.setState({showEffectiveModal:false,
                        isFormSubmitted: true, formSubmittedMessage: "Data Modified Sucessfully", collAcc_DD : [],
                        alertType: "confirmation"});
                    this.hideModifyModal();
                    this.handleClear();
                }
            });
        }
    }
    hideEffectiveDateModal(){
        this.setState({modal_FormValues: effectiveDate_Schema, 
            showEffectiveModal: false, nextModalLevelError: false, disableBtn: false, collAcc_DD : []});
    }

    activeInactiveChangeOverlay() {
        const { saveInvVehicleDetailsActions }= this.props;
        const selectedGrid = this.state.gridRowSelected; 
        let sourceCdVal = '';
        for(let i=0;i<this.state.source_DD.length;i++) {
            if(this.state.source_DD[i].label==this.state.gridRowSelected.sourceCode) {
                sourceCdVal = this.state.source_DD[i].value;
            }
        }
        let tripartyVal = '';
        for(let i=0;i<this.state.triparty_DD.length;i++) {
            if(this.state.triparty_DD[i].label==this.state.gridRowSelected.triPartyAgentId) {
                tripartyVal = this.state.triparty_DD[i].value;
            }
        }
        const addToService = {
            iModValue:"IC",
            rowId: selectedGrid.rowId,
            sourceCode: sourceCdVal,
            triPartyAgentId: tripartyVal,
            validFromDate: selectedGrid.validFromDate,
            invVehicleId: selectedGrid.sourceVehicleText, 
            validToDate: selectedGrid.validToDate,
            collateralAcct: selectedGrid.collateralAcct,
            ctpyEntityId: selectedGrid.ctpyEntityId,
            srcCollCode: selectedGrid.ssgaCollCode,
            activeFlag: this.state.modal_FormValues.active_flag ? this.state.modal_FormValues.active_flag : selectedGrid.activeFlag,
            userName: selectedGrid.userName,
            invVehInvestmentNM: selectedGrid.invVehInvestmentNM,
            ctpyDMLNM: selectedGrid.ctpyDMLNM,
            sourceCtpytxt: selectedGrid.sourceCtpytxt,
            ctpyId: selectedGrid.ctpyId
        };
	    saveInvVehicleDetailsActions.add(addToService).then(res => {
            const data = this.props.saveInvVehicleDetails.data[0];
            if(null !== data.errorDesc){
                this.setState({showActiveInactiveModal:false,
                modal_FormValues: PageSchema, modalLevelError: true, 
                modalLevelErrorMsg: `Failed to update data  due to : ${data.errorDesc}`,
                disableModalSaveBtn: true,collAcc_DD : []})
            }
	    	else{ 
                this.setState({isFormSubmitted: true, alertType: "confirmation",collAcc_DD : [],
                    showActiveInactiveModal:false, formSubmittedMessage: "Data Modified Sucessfully"});
                this.hideModifyModal();
                this.handleClear();
            }
	    });
    }

    activeInactiveCorrectionOverlay() { 
    	const { saveInvVehicleDetailsActions }= this.props;
        const selectedGrid = this.state.gridRowSelected;
        let sourceCdVal = '';
        for(let i=0;i<this.state.source_DD.length;i++) {
            if(this.state.source_DD[i].label==this.state.gridRowSelected.sourceCode) {
                sourceCdVal = this.state.source_DD[i].value;
            }
        }
        let tripartyVal = '';
        for(let i=0;i<this.state.triparty_DD.length;i++) {
            if(this.state.triparty_DD[i].label==this.state.gridRowSelected.triPartyAgentId) {
                tripartyVal = this.state.triparty_DD[i].value;
            }
        }
        const addToService = {
            iModValue:"I",
            rowId: selectedGrid.rowId,
            sourceCode: sourceCdVal,
            triPartyAgentId: tripartyVal,
            validFromDate: selectedGrid.validFromDate,
            invVehicleId: selectedGrid.sourceVehicleText, 
            validToDate: selectedGrid.validToDate,
            collateralAcct:selectedGrid.collateralAcct,
            ctpyEntityId: selectedGrid.ctpyEntityId,
            srcCollCode: selectedGrid.ssgaCollCode,
            activeFlag: this.state.modal_FormValues.active_flag ? this.state.modal_FormValues.active_flag : selectedGrid.activeFlag,
            userName: selectedGrid.userName,
            invVehInvestmentNM: selectedGrid.invVehInvestmentNM,
            ctpyDMLNM: selectedGrid.ctpyDMLNM,
            sourceCtpytxt: selectedGrid.sourceCtpytxt,
            ctpyId: selectedGrid.ctpyId
        };
	    saveInvVehicleDetailsActions.add(addToService).then(res => {
            const data = this.props.saveInvVehicleDetails.data[0];
            if(null !== data.errorDesc) {
                this.setState({showActiveInactiveModal:false, modalLevelError: true,collAcc_DD : [],
                    modalLevelErrorMsg: `Failed to update data  due to : ${data.errorDesc}`,
                    modal_FormValues: PageSchema, disableModalSaveBtn: true})}
	    	else { 
                this.setState({isFormSubmitted: true, alertType: "confirmation",collAcc_DD : [],
                    showActiveInactiveModal:false, formSubmittedMessage: "Data Modified Sucessfully"});
                this.hideModifyModal();
                this.handleClear();
            }
	    });
    }

    handleValidFromDateChange() {
        let myDate = new Date(this.state.modal_FormValues.fromdate_required);
        const { saveInvVehicleDetailsActions }= this.props;
        let sourceCdVal = '';
        for(let i=0;i<this.state.source_DD.length;i++) {
            if(this.state.source_DD[i].label==this.state.gridRowSelected.sourceCode) {
                sourceCdVal = this.state.source_DD[i].value;
            }
        }
        let tripartyVal = '';
        for(let i=0;i<this.state.triparty_DD.length;i++) {
            if(this.state.triparty_DD[i].label==this.state.gridRowSelected.triPartyAgentId) {
                tripartyVal = this.state.triparty_DD[i].value;
            }
        }
        const addToService = {
            iModValue:"V",
            rowId:this.state.gridRowSelected.rowId,
            sourceCode: sourceCdVal,
            triPartyAgentId:tripartyVal,
            validFromDate:(myDate.getMonth()+1)+"/"+myDate.getDate()+"/"+myDate.getFullYear(),
            invVehicleId:this.state.gridRowSelected.sourceVehicleText, 
            validToDate:this.state.gridRowSelected.validToDate,
            collateralAcct:this.state.gridRowSelected.collateralAcct,
            ctpyEntityId:this.state.gridRowSelected.ctpyEntityId,
            srcCollCode:this.state.gridRowSelected.ssgaCollCode,
            activeFlag:this.state.gridRowSelected.activeFlag,
            userName:this.state.gridRowSelected.userName,
            invVehInvestmentNM:this.state.gridRowSelected.invVehInvestmentNM,
            ctpyDMLNM:this.state.gridRowSelected.ctpyDMLNM,
            sourceCtpytxt:this.state.gridRowSelected.sourceCtpytxt,
            ctpyId:this.state.gridRowSelected.ctpyId
        };
	    saveInvVehicleDetailsActions.add(addToService).then(res => {
            const data = this.props.saveInvVehicleDetails.data[0];
            if(null !== data.errorDesc) {
                this.setState({showDateModifyModal:false, modalLevelError: true,collAcc_DD : [], 
                    modalLevelErrorMsg:`Failed to update data  due to : ${data.errorDesc}`,
                    modal_FormValues: PageSchema, disableModalSaveBtn: true})
            }
	    	else { 
                this.setState({showDateModifyModal:false, isFormSubmitted: true,collAcc_DD : [],
                formSubmittedMessage: "Data Modified Sucessfully", alertType: "confirmation"});
                this.hideModifyModal();
                this.handleClear();
            }
	    });
    }

    closeBanner(){
    	this.setState({isFormSubmitted: false, showParentAlert: false});
    }

    render() {
        const { filterCompChanges, modal_FormValues, gridRowSelected, modalLevelError, 
            modalLevelErrorMsg, nextModalLevelError, nextModalLevelErrorMsg, 
            isFormSubmitted, formSubmittedMessage, alertType, modalErrorType, showParentAlert } = this.state;
        const fetchValues = (type) => {
        	if(type==='modify'){
        		let source, triparty_agentfile, collAcc, active_flag;
        		this.state.source_DD.forEach((src) => {
        			if(src.label === gridRowSelected.sourceCode) source = src.value
        		});
        		this.state.triparty_DD.forEach((item) => {
        			if(item.label === gridRowSelected.triPartyAgentId) {
        				triparty_agentfile = item.value;
        			}
        		});
        		this.state.collAcc_DD.forEach((item) => {
        			if(item.label === gridRowSelected.collateralAcct) {
        				collAcc = item.value;
        			}
        		});
        		activeflg.forEach((item) => {
        			if(item.label === gridRowSelected.activeFlag) {
        				active_flag = item.value;
        			}
        		});
        		return {
        			source, 
        			triparty_agentfile,
        			fromdate_required: new Date(gridRowSelected.validFromDate),
        			src_inv_veh_id: gridRowSelected.sourceVehicleText,
        			collAcc,
        			todate_required: new Date(gridRowSelected.validToDate),
        			ctpy_entity_id: gridRowSelected.ctpyEntityId,
        			src_coll_code: gridRowSelected.ssgaCollCode,
        			active_flag,
        			iv_internm: gridRowSelected.invVehInvestmentNM,
        			dml_ctpynm: gridRowSelected.ctpyDMLNM,
        			ctpysrc_id: gridRowSelected.sourceCtpytxt,
        			dml_ctpyid: gridRowSelected.ctpyId,
        			userId: gridRowSelected.lastModifiedId,
        			lastModified: this.formatDate(new Date(gridRowSelected.lastModifiedDate))
        		};
        	}
        };
        const generateGenericFormData = (type)=> {
            return {
                id: `investmentVehicle-${type}`, 
                schema: type==="effectiveDate" ? effectiveDate_Schema: type==="default" ? PageSchema : type==="create" ? CreatePageSchema : UpdatePageSchema, 
                value: type ==='default'
                    	? {
                    		fromdate_required: moment(),
                    		todate_required: new Date(validEndDate), 
                    		...filterCompChanges } 
                		: type === 'modify' 
                			? {...fetchValues('modify'), ...modal_FormValues}
                			: type === 'create' 
                				? {
                            		fromdate_required: moment(),
                            		todate_required: new Date(validEndDate), 
                            		...modal_FormValues }
                				: modal_FormValues ,
                style: { width: '100%', border: 'single' }, 
                "margin-top":'0px', "padding-top":'0px',
                height:  type ==='default'? '400px' : type ==='create'|| type ==="modify" ? '425px': '425px', 
                horizontal: true,
                fieldWidth: '400px', 
                labelWidth:type ==='default'? '150px' :'180px', 
                onChange: type ==='default'
                    ? this.handleFilterComponentChange 
                    : type ==='create' 
                        ? this.callCreateModalChange
                        : type ==="modify" 
                            ? this.callModifyModalChange
                            : this.onEffectiveDateChange, 
                onSubmit: type ==='default'
                    ? this.handleFilterSubmit
                    : type ==='create' 
                        ? this.callCreateModalSave
                        : type === "modify" 
                            ? this.callModifyModalSave
                            : this.handleEffectiveDateChangeSubmit,
                noScrollbar : true,
                defaultValue : type === "effectiveDate" ? {date_required:moment()} : null,
                formatMessage : this.formatMessage
            };
        };
        const genericFormFields = (type="default") => {
            return [
                {name:'source', type:'select', title:"Source:", options:this.state.source_DD, 
                    placeholder: this.state.all, noValidate:true, disabled: type==="modify" ? true : false},
                {name:'triparty_agentfile', type:'select', title:"Triparty Agnt File:", 
                    options:this.state.triparty_DD, placeholder: 'ALL',
                    onChange:  type === "create" || type==="modify" ? this.callTripartyChange : null},
                {title:"Valid From:", type:"datepicker", name:'fromdate_required', 
                    placeholder: type==="create" ? currentDate : null},
                {name:'src_inv_veh_id', type:'select', title:"Src Inv Veh Id:", placeholder : 'ALL',
                    options:this.state.srcInvVehId_DD,  disabled: type==="modify" ? true : false},
                {name:"collAcc", title:"Collateral Acct:", type: type === "create" || type === "modify" ? 'select': '',
                    options: type === "create" || type === "modify" ? this.state.collAcc_DD : null},
                {title:"Valid To:", type:"datepicker", name:'todate_required', disabled: type==="default" ? false : true,
                    placeholder: type==="create" ? validEndDate : null},
                {name:"ctpy_entity_id", title:"Ctpy Entity Id:", disabled: type==="modify" ? true : false},
                {name:'src_coll_code', type:'select', title:"Src Coll Codes:", options: this.state.srcCollCodes_DD, 
                    disabled: type==="modify" ? true : false, placeholder: 'ALL'},
                /*{name: 'active_flag', type:'select', title:"Active/Inactive:", options: type==="default" ? activeflg : modactiveflg, 
                    placeholder : type === "create" ? "Y-Active" : "ALL",disabled : type==="create" ? true : false}*/
                 {name: 'active_flag', type:'select', title:"Active/Inactive:", options: type==="default" ? activeflg : modactiveflg, 
                            placeholder : type === "create" ? "select" : "ALL",disabled :false}
            ];
        };
        const gridButtons = [
            {btnLbl: "Create",bsSize:"small",style: { float: 'right' , marginRight: '25px' ,width:'100px', height:'35px' }, onClick: this.showCreateModal},
            {btnLbl: "Modify",bsSize:"small",style: {float: 'right' , marginRight: '25px' ,width:'100px', height:'35px' }, disabled: this.state.disableModifyBtn, 
                onClick: this.showModifyModal, bsStyle:"primary"},
            {btnLbl: "Next",bsSize:"small",style:{ float: 'right' , marginRight: '25px' ,width:'100px', height:'35px' }, disabled: this.state.disabledNxtBtn, 
                onClick:this.handleNextPagination, bsStyle: "primary"},
            {btnLbl: "Prev",bsSize:"small",style:{ float: 'right' , marginRight: '25px' ,width:'100px', height:'35px' }, disabled: this.state.disabledPreBtn, 
                onClick: this.handlePrePagination, bsStyle: "primary"}
        ];

        const filterCriteriaFormButton = [
            {type: 'submit', bsStyle: "primary" , style:{ float: 'left', marginLeft: '50px',width:'100px', height:'35px'  }, btnLabel: "Refresh",bsSize:"small"},
            {type: 'button', bsStyle:"primary" , style:{ float: 'left', marginRight: '25px',width:'100px', height:'35px'  }, onClick: this.handleClear, 
                btnLabel: "Clear",bsSize:"small"}
        ];
        const createModalData = {
            animation : false,
            show: this.state.showCreateModal,
            onHide: this.hideCreateModal
        };
        const modalFormField = (type) => {
            return [...genericFormFields(type),
                {name: 'iv_internm', title: "Invest Vehicle Internal Nm", disabled: type ==="modify" ? true: false},
                {name: 'dml_ctpynm', title: "Primary DML Ctpy Nm", disabled: type ==="modify" ? true: false},
                {name: 'ctpysrc_id', title: "Src Ctpy Id",disabled: type ==="modify" ? true: false},
                {name: 'dml_ctpyid', title: "Primary DML Ctpy Id",disabled: type ==="modify" ? true: false},
                {name: 'userId', title: "UserId"},
                {name: 'lastModified', title: "Last Modified",disabled: true}
            ];
        };
        const createModalFormButton = [
            {type: 'submit',bsSize:"small",style:{width:'100px', height:'35px'  }, bsStyle: "primary", btnLabel: "Save", disabled: this.state.disableModalSaveBtn},
            {type: 'button',bsSize:"small",style:{width:'100px', height:'35px'  }, bsStyle:"primary", onClick: this.hideCreateModal, btnLabel: "Cancel"}
        ];
        const createModalFormProps ={
            modalFormFieldDatas: modalFormField('create'),
            modalFormData: generateGenericFormData('create'), 
            modalFormBtnProps: createModalFormButton,
            addClass: {
                margin: '20px 0',
                textAlign: 'center'
            }
        };
        const modifyModalData = {
            animation : false, show: this.state.showModifyModal, onHide: this.hideModifyModal
        };
        const modifyModalFormButton = [
            {type: 'submit',style:{width:'100px', height:'35px'  },bsSize:"small", bsStyle: "primary", btnLabel: "Save", disabled: this.state.disableModalSaveBtn},
            {type: 'button',style:{width:'100px', height:'35px'  },bsSize:"small", bsStyle:"primary", onClick: this.hideModifyModal, btnLabel: "Cancel"}
        ];
        const modifyModalFormProps = {
            modalFormFieldDatas: modalFormField('modify'),
            modalFormData: generateGenericFormData('modify'), 
            modalFormBtnProps: modifyModalFormButton,
            addClass: {
                margin: '20px 0',
                textAlign: 'center'
            }
        };
        const activeInactiveModalData = {
            animation : false, show: this.state.showActiveInactiveModal, onHide: this.hideActiveInactiveModal
        };
        const activeInactiveModalButtons = [
            {bsStyle: "primary",style:{width:'100px', height:'35px'  },bsSize:"small", onClick: this.activeInactiveChangeOverlay, btnLbl:"Change"},
            {bsStyle: "primary",style:{width:'100px', height:'35px'  },bsSize:"small", onClick: this.activeInactiveCorrectionOverlay, btnLbl: "Correction"},
            {bsStyle: "primary",style:{width:'100px', height:'35px'  },bsSize:"small", onClick:this.hideActiveInactiveModal, btnLbl: "Cancel"}
        ];
        const dateModifyModalData = {
            animation : false, show: this.state.showDateModifyModal, onHide: this.hideDateModifyModal
        };
        const dateModifyModalButtons = [
            {bsStyle: "primary",style:{width:'100px', height:'35px'  },bsSize:"small", onClick: this.handleValidFromDateChange, btnLbl:"Ok"},
            {bsStyle: "primary",style:{width:'100px', height:'35px'  },bsSize:"small", onClick:this.hideDateModifyModal, btnLbl: "Cancel"}
        ];
        const effectiveDateModalData = {
            animation : false, show: this.state.showEffectiveModal, onHide: this.hideEffectiveDateModal
        };
        const effectiveDateModalButtons = [
            {bsStyle: "primary",style:{width:'100px', height:'35px'  },bsSize:"small",type:'submit', btnLabel:"Change", disabled: this.state.effectiveChangedDate ? false : true},
            {type: 'button', style:{width:'100px', height:'35px'  },bsSize:"small",onClick: this.ontripartyCorrectionClick, bsStyle: "primary", btnLabel: "Correction"},
            {type: 'button',style:{width:'100px', height:'35px'  },bsSize:"small", bsStyle: "primary", onClick:this.hideEffectiveDateModal, btnLabel: "Cancel"}
        ];
        const effectiveDateFormProps = {
            modalFormFieldDatas: [{title:"Effective Date", type:"datepicker", name:'date_required'}],
            modalFormData: generateGenericFormData('effectiveDate'), 
            modalFormBtnProps: effectiveDateModalButtons
        };
        const { pageTitle, gridTitle, createModalTitle, modifyModalTitle, 
            activeInactiveModalTitle, dateModifyModalTitle, effectiveDateModalTitle } = assets;
        
        return (
            
            <div className="form-example" style={{ width: '100%' }}>              
                {
                    isFormSubmitted || showParentAlert
                        ? <div style={{marginBottom: '10px'}}>
                            <AlertBanner type={alertType} label={formSubmittedMessage} 
                            	onClose={this.closeBanner} rootClose= {true} />
                        </div>
                        : null
                }
                <FormComponent formData ={generateGenericFormData('default')} fieldDatas={genericFormFields()} 
                    formButtonProps ={filterCriteriaFormButton} type="filterCriteria" parentClass = {{'marginTop': '30px'}}/>
                <div style={{ position: 'right', height: 30, width: '100%' }}>
                    {gridButtons.length > 0 && gridButtons.map((gridBtn, i)=> {
                        const { btnLbl, ...btnProp } = gridBtn;
       	                return <Button {...btnProp} key={`gridnavBtn-${i}`}>{btnLbl}</Button>;                      
                    })}
                    <p style={{ float: 'right' , marginright: '24pt',color:'blue'  }} >
                        {this.state.recordsPerPage} of {this.state.totalrecords} 
                    </p>
                </div>
                <br/>                
                <div style={{ position: 'relative', height: 500, width: '100%' }}>
                    <DataGrid
                        columns={investmentVehicleCollAcctXRefConfig} onCheckedChange={this.onCheckedGridRowClick} 
                        keyFieldName="id" data={this.state.gridData}  hasCheckbox 
                        clearSelectionOnRefresh title={gridTitle}/>
                </div>
                <ModalComponent isFormAvailable={true} modalData ={createModalData}
                    title={createModalTitle}
                    formProps = {createModalFormProps}
                    modalType="iv-create" modalLevelError={modalLevelError} modalLevelErrorMsg={modalLevelErrorMsg} />
                <ModalComponent isFormAvailable={true} modalData ={modifyModalData}
                    title={modifyModalTitle}
                    formProps = {modifyModalFormProps} modalLevelErrorType = {modalErrorType}
                    modalType="iv-modify" modalLevelError={modalLevelError} modalLevelErrorMsg={modalLevelErrorMsg} />
                <ModalComponent isFormAvailable={false} modalData ={activeInactiveModalData}
                    title="Active/Inactive Change"
                    modalType="iv-activeInactive" modalSubheader={activeInactiveModalTitle}
                    modalButtons={activeInactiveModalButtons} modalLevelError={nextModalLevelError} 
                        modalLevelErrorMsg={nextModalLevelErrorMsg}  />
                <ModalComponent isFormAvailable={false} modalData ={dateModifyModalData}
                    title="Date Modify" modalType="iv-dateModify" 
                    modalSubheader={dateModifyModalTitle}
                    modalButtons={dateModifyModalButtons} modalLevelError={nextModalLevelError} 
                    modalLevelErrorMsg={nextModalLevelErrorMsg} />
                <ModalComponent isFormAvailable={true} modalData ={effectiveDateModalData}
                    title="Effective Date Change" formProps={effectiveDateFormProps}
                    modalType="iv-effectiveDateChanges" modalSubheader={effectiveDateModalTitle} 
                    modalLevelError={nextModalLevelError} modalLevelErrorMsg={nextModalLevelErrorMsg}/>
            </div>

        )
    }
}
Template.propTypes = {
}
