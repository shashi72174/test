import React, {  Component } from "react"
import PropTypes from 'prop-types'
import { Form, Button,connectRest,AlertBanner,DataGrid,Modal } from 'ssc-cdt4'
import yup from 'yup'
import moment from 'moment'
import {FormGroup, ControlLabel, FormControl} from 'react-bootstrap';
// Constants
const now =moment()
const currentDate = (new Date().getMonth()+1)+"/"+(new Date().getDate())+"/"+(new Date().getFullYear())
let endDt = new Date("2500","0","31") 
const validEndDate = (endDt.getMonth()+1)+"/"+endDt.getDate()+"/"+endDt.getFullYear()
const activeflg=[{ value: '0', label: 'ALL' },{ value: 'Y', label: 'Y-Active' }, { value: 'N', label: 'N-inActive' }]
const modactiveflg = [{ value: 'Y', label: 'Y-Active' }, { value: 'N', label: 'N-inActive' }]
const temp=[{}]
const disabledBtn=true;	
let defaultStr = yup.string().default('')
let dateType = yup.object()
.required('Please Fill This Field')
.test('is-format',
 'Enter Date in MM/DD/YYYY format',
  value => {
    if(value){
      const today = moment()
      return today.isValid.call(value)
    }
    else{
      return true
    }
  })
  const effectiveDate_Schema = yup.object({
  date_required: dateType.default(now)
});

// Page Schema for form data
let PageSchema = yup
  .object({
    collcode:defaultStr,
    triparty_agentfile:defaultStr,
    house_id:defaultStr,
    active_flag: defaultStr,
    fromdate_required: yup
	    .date()
	    .default(new Date(currentDate))
	    .required('Please Fill This Field'),
    todate_required: yup
	    .date()
	    .default(new Date(validEndDate))
	    .max(new Date(validEndDate), `To Date should be equal or earlier than ${validEndDate}`)
	    .required('Please Fill This Field'),
    collAcc:defaultStr,
    ctpyId:defaultStr,
    lastModified:defaultStr,
    userId:defaultStr,
    datefrom:defaultStr,
    dateto:defaultStr
	  
  })


  const CreatePageSchema = yup
  .object({
    collcode:yup.string().required('Please Fill This Field'),
    triparty_agentfile:yup.string().required('Please Fill This Field'),
    house_id:yup.string().required('Please Fill This Field'),
    active_flag:defaultStr,
    fromdate_required: yup.date().default(new Date(currentDate)),
	todate_required: yup.date().default(new Date(validEndDate)),
    collAcc:yup.string().required('Please Fill This Field'),
    ctpyId:yup.string().required('Please Fill This Field'),
    lastModified:defaultStr,
    userId:defaultStr,
    datefrom:defaultStr,
    dateto:defaultStr

  })

  const UpdatePageSchema = yup
  .object({
    collcode:defaultStr,
    triparty_agentfile:defaultStr,
    house_id:defaultStr,
    active_flag:defaultStr,
    fromdate_required: yup.date().default(new Date(currentDate)),
    todate_required: yup.date().default(new Date(validEndDate)),
    collAcc:defaultStr,
    ctpyId:defaultStr,
    lastModified:defaultStr,
    userId:defaultStr,
    datefrom:defaultStr,
    dateto:defaultStr

  })
// Grid columns
export const dmlCollAcctXRefConfig = [
	  {
	    dataKey: 'collateralCode',
	    label: 'Collateral Code',
	    width: 300,
	    dataType: 'string',
	    align:'left'
	  },
	  {
	    dataKey: 'houseAcctId',
	    label: 'House Acct ID',
	    width: 180,
	    dataType: 'string',
		align:'left'
	  },
	  {
	    dataKey: 'counterPartyId',
	    label: 'CTPY ID',
	    width: 180,
	    dataType: 'string',
		align:'left'
	  },
	  {
	    dataKey: 'triPartyAgentId',
	    label: 'Triparty Agnt Id',
	    width: 180,
	    dataType: 'string',
		align:'left'
	  },
	  {
	    dataKey: 'collateralAcct',
	    label: 'Collateral Acct',
	    width: 180,
	    dataType: 'string',
		align:'left'

	  },
	  {
	    dataKey: 'validFromDate',
	    label: 'ValidFromDt',
	    width: 160,
	    dataType: 'string',
		align:'left'
	  },
	  {
	    dataKey: 'validToDate',
	    label: 'ValidToDt',
	    width: 160,
	    dataType: 'string',
		align:'left'
	  },
	  {
	    dataKey: 'activeFlag',
	    label: 'ActiveFlg',
	    width: 160,
	    dataType: 'string',
		align:'left'
	  },
	  {
	    dataKey: 'lastModifiedId',
	    label: 'LastModSignOnId',
	    width: 180,
	    dataType: 'string',
		align:'left'
	  }, 
	  {
	    dataKey: 'lastModifiedDate',
	    label: 'LastModSignOnDate',
	    width: 160,
	    dataType: 'string',
		align:'left'
	  }
	  
	];
@connectRest('DmlDDList')
@connectRest('CollateralCrossReflist')
@connectRest('SaveAccountCrossRefDetails')
@connectRest('CollateralAccountList')
@connectRest('AccountCrossRefList')
export default class Template extends Component {
	constructor(props){
    super(props);
    this.state={
    		rowId:'',disabledNxtBtn : true, disabledPreBtn:true,
    		FilterComponentChanges:{},ccData_DD:[],triparty_DD:[],houseId_DD:[], gridData:[],collAcc_DD:[],
    		open: true, show: false,createupdate_changeValue1:{},DB_gridRowData:[],ctpyId_DD:[],act_flag:0,modFlag:0,
    		triparty_temp:[],houseId_temp:[],gridRowSelected:[],showModifyModalWindow:false,disabledBtn: true,totalrecords:0,all:'ALL',
    		isActiveFlagUpdated:0,isTripartyUpdated:0,isCollateralUpdated:0,isDateUpdated1:0,showDateFlagwindow:false, 
    		showActiveInactiveFlagWindow:false,effectiveFromDate:'',showEffectiveFromdate:false,disableModalSaveBtn: true,
    		prePageValue: 0, nextPageValue: 0, alertType: '' , alertMessage: '', showAlert: false, showParentAlert: false
 };
	this.handleFilterComponentChange = this.handleFilterComponentChange.bind(this);
	this.handleSubmit = this.handleSubmit.bind(this);
	this.handleSave = this.handleSave.bind(this);
	this.handleUpdate=this.handleUpdate.bind(this);
	this.createUpdateModalWindowChange=this.createUpdateModalWindowChange.bind(this);
	this.handleModifyButton = this.handleModifyButton.bind(this);
	this.handlePrePagination = this.handlePrePagination.bind(this);
	this.handleNextPagination = this.handleNextPagination.bind(this);
	this.tripartyAgentOnChange = this.tripartyAgentOnChange.bind(this);
	this.handleTriPartyChangeSubmit=this.handleTriPartyChangeSubmit.bind(this);
	this.handleActiveinactivechange=this.handleActiveinactivechange.bind(this);
	this.handleActiveinactivecorrection=this.handleActiveinactivecorrection.bind(this);
	this.handleEffectiveFromDateOk=this.handleEffectiveFromDateOk.bind(this);
	this.onClose = this.onClose.bind(this);
	this.cancel = this.cancel.bind(this);
  }
  // Will execute on page load
  componentDidMount = () => {
	let param = {}
	  const {DmlDDListActions,CollateralCodeDDListActions,HouseDetailsDDListActions,TriPartyAgentDDListActions,DMLCtpylistActions,AccountCrossRefListActions}=this.props;
	  DmlDDListActions.list(param).then(res=>{
		  this.setState({DmlDD_data:this.props.DmlDDList.data})
		  if(typeof this.props.DmlDDList.error==='object' && this.props.DmlDDList.error.errorMsg!='undefined' ){
			  const type = 'warning'
			  AlertBanner.show(
					  type,
					  `Error processing request:please try after some time`
					)
		  }
		  else{
			  if(this.props.DmlDDList.data!='' && this.props.DmlDDList.data!='undefined'){
			  this.setState({ccData_DD:this.props.DmlDDList.data[0].collCodeData})
			  this.setState({houseId_DD:this.props.DmlDDList.data[0].houseDetailsData})
			  this.setState({triparty_DD:this.props.DmlDDList.data[0].tripartyData})
			  this.setState({ctpyId_DD:this.props.DmlDDList.data[0].ctpyData})
		  }
		  }
	  })
	   
	  //pagenation on load 
	  /*AccountCrossRefListActions.list({paginationType:'next',pageNo:1,searchTypeFlag:'1'}).
	  then(res => {
		  if(typeof this.props.AccountCrossRefList.error==='object' && this.props.AccountCrossRefList.error.errorMsg!='undefined' ){
			  const type = 'warning'
			  AlertBanner.show(
					  type,
					  `Error processing request:please try after some time`
					)
		  }	else{
		  this.setState({gridData:this.props.AccountCrossRefList.data[0]})
		  }
		  if(null!=this.props.AccountCrossRefList.data[0].totalRecords){
			  this.setState({totalrecords:this.props.AccountCrossRefList.data[0].totalRecords})
		  if (JSON.stringify(this.props.AccountCrossRefList.data[0].totalRecords)>=10){
			  this.setState({disabledNxtBtn : false,prePageValue : 1 ,nextPageValue : 2})}	
	  if ( this.props.AccountCrossRefList.data[0].isNextDisable === 'Y'){
		  this.setState({disabledNxtBtn : true})}
	  }
	  })*/
	  this.loadGridData();
	 
}
  loadGridData() {
	  const { AccountCrossRefListActions }=this.props;
	  AccountCrossRefListActions.list({paginationType:'next',pageNo:1,searchTypeFlag:'1'}).
	  then(res => {
		  if(typeof this.props.AccountCrossRefList.error==='object' && this.props.AccountCrossRefList.error.errorMsg!='undefined' ){
			  const type = 'warning'
			  AlertBanner.show(
					  type,
					  `Error processing request:please try after some time`
					)
		  }	else{
		  this.setState({gridData:this.props.AccountCrossRefList.data[0]})
		  }
		  if(null!=this.props.AccountCrossRefList.data[0].totalRecords){
			  this.setState({totalrecords:this.props.AccountCrossRefList.data[0].totalRecords})
		  if (JSON.stringify(this.props.AccountCrossRefList.data[0].totalRecords)>=10){
			  this.setState({disabledNxtBtn : false,prePageValue : 1 ,nextPageValue : 2})}	
	  if ( this.props.AccountCrossRefList.data[0].isNextDisable === 'Y'){
		  this.setState({disabledNxtBtn : true})}
	  }
	  })
  }
 //Load collatAcc dd based on selection of triparty dd
  tripartyAgentOnChange(event){ this.setState({collAcc_DD:[]})
	  		const { CollateralAccountListActions }= this.props; 
	  		CollateralAccountListActions.list({triPartyAgentId:event}).then(res => {this.setState({collAcc_DD:this.props.CollateralAccountList.data}) })   
  }
  // ModalWindow Changes..................................
  showModal = () => {this.setState({ show: true }) }
  showEffectiveFromdateWindow=()=>{this.setState({showEffectiveFromdate:false})
	 }
  hideCreateModal = () => {  this.setState({ show: false, showAlert: false, createupdate_changeValue1: {},
	  modFlag:0, disableModalSaveBtn : true, collAcc_DD: []});
  }
  hideModifyModal= () => {
	this.setState({createupdate_changeValue1:{}, showAlert: false})
	//this.setState({gridRowSelected:[]})
	this.setState({DB_gridRowData:{}})
	this.setState({modFlag:0})
	this.setState({ showModifyModalWindow: false  })
	this.setState({ isActiveFlagUpdated: 0  })
	this.setState({ isTripartyUpdated: 0  })
	this.setState({ isCollateralUpdated: 0  })
	this.setState({ isdateUpdated: 0  })
	this.setState({disableModalSaveBtn : true, DB_gridRowData: {}, collAcc_DD: []})
  }
  hideDateFlagwindow=()=>{this.setState({showDateFlagwindow:false, isActiveFlagUpdated:"0", isDateUpdated1:"0", 
  	isTripartyUpdated:"0", isCollateralUpdated:"0", createupdate_changeValue1: {}, DB_gridRowData: this.state.dbGrid})
		//this.setState({ showModifyModalWindow: false  })
  
  }
  hideActiveInactiveFlagWindow=()=>{
	  this.setState({showActiveInactiveFlagWindow:false, isActiveFlagUpdated:"0",
	  	isDateUpdated1:"0", isTripartyUpdated:"0", isCollateralUpdated:"0", createupdate_changeValue1: {}, DB_gridRowData: this.state.dbGrid})
		//this.setState({ showModifyModalWindow: false  })
  
  }
  handleFilterComponentChange(event){
	this.setState({FilterComponentChanges:event})}
  hideEffectiveFromdateWindow=()=>{this.setState({showEffectiveFromdate:false, isActiveFlagUpdated:"0", 
  	isDateUpdated1:"0", isTripartyUpdated:"0", isCollateralUpdated:"0", createupdate_changeValue1: {}, DB_gridRowData: this.state.dbGrid});
		//this.setState({ showModifyModalWindow: false  })
  
  }
  handleSubmit=(event)=>{
	const { AccountCrossRefListActions }= this.props;
	this.setState({disabledNxtBtn : true, disabledPreBtn:true, prePageValue : 1 ,nextPageValue : 1});
	const {FilterComponentChanges} = this.state;
	const fromDate = FilterComponentChanges.fromdate_required 
		? this.formatDate(new Date(FilterComponentChanges.fromdate_required))
		: this.formatDate(new Date(event.fromdate_required));
	const toDate = FilterComponentChanges.todate_required
		? this.formatDate(new Date(FilterComponentChanges.todate_required))
		: this.formatDate(new Date(event.todate_required))
	AccountCrossRefListActions.list({paginationType:'next',pageNo:1,colTypeCode:'',collateralCode:this.state.FilterComponentChanges.collcode,houseAcctId:this.state.FilterComponentChanges.house_id,
		counterPartyId:this.state.FilterComponentChanges.ctpyId,triPartyAgentId:this.state.FilterComponentChanges.triparty_agentfile,
		collateralAcct:this.state.FilterComponentChanges.collAcc,validFromDate:fromDate ,
		validToDate:toDate,activeFlag:this.state.FilterComponentChanges.active_flag}).
	then(res => {this.setState({gridData:this.props.AccountCrossRefList.data[0]})
	if(null!=this.props.AccountCrossRefList.data[0].totalRecords){
			  this.setState({totalrecords:this.props.AccountCrossRefList.data[0].totalRecords})
	if (JSON.stringify(this.props.AccountCrossRefList.data[0].totalRecords)>=10){
			  this.setState({disabledNxtBtn : false, prePageValue : 1 ,nextPageValue : 2}) 
	 }else{
			  this.setState({disabledNxtBtn : true, disabledPreBtn:true,prePageValue : 1 ,nextPageValue : 2})
		  } }	
	  if (JSON.stringify(this.props.AccountCrossRefList.data[0].isNextDisable) === 'Y'){
		  this.setState({disabledNxtBtn : true})
		  }
	  })
	  }
  handleSave=(event)=>{	
	const { SaveAccountCrossRefDetailsActions }= this.props;
	const {createupdate_changeValue1} = this.state;
	const fromDate = createupdate_changeValue1.fromdate_required 
		? this.formatDate(new Date(createupdate_changeValue1.fromdate_required))
		: this.formatDate(new Date(event.fromdate_required));
	const toDate = createupdate_changeValue1.todate_required
		? this.formatDate(new Date(createupdate_changeValue1.todate_required))
		: this.formatDate(new Date(event.todate_required))
	let today = new Date();
    let validFrDate = new Date(createupdate_changeValue1.fromdate_required);
    if(validFrDate>today) {
		this.setState({
			showAlert: true,
			disableModalSaveBtn: true,
			alertMessage: "Valid From date cannot be greater than today.",
			alertType: 'warning'
		});
	}	
	!this.state.showAlert && SaveAccountCrossRefDetailsActions.add({isDateUpdated:'N',colTypeCode:this.state.createupdate_changeValue1.collcode,
	collateralCode:this.state.createupdate_changeValue1.collcode,houseAcctId:this.state.createupdate_changeValue1.house_id,
	counterPartyId:this.state.createupdate_changeValue1.ctpyId,triPartyAgentId:this.state.createupdate_changeValue1.triparty_agentfile,
	collateralAcct:this.state.createupdate_changeValue1.collAcc,validFromDate:fromDate,
	validToDate:toDate,activeFlag:this.state.createupdate_changeValue1.active_flag,userName:this.state.createupdate_changeValue1.userId}).
    then( res => {
           if(null!=this.props.SaveAccountCrossRefDetails.data[0].errorDesc){
        	   this.setState({ disableModalSaveBtn : true, showAlert: true, 
				   alertMessage: `Failed to save data  due to : ${this.props.SaveAccountCrossRefDetails.data[0].errorDesc}`,
				   alertType: 'warning'});
//			   alert("Failed to save data  due to :"+this.props.SaveAccountCrossRefDetails.data[0].errorDesc);
   	    	}
           else{
        	   this.setState({gridData:this.props.SaveAccountCrossRefDetails.data[0]})
        	//    alert("Data Saved Sucessfullyy....");
        	   this.setState({ show: false, showAlert: false, showParentAlert: true,createupdate_changeValue1 : {},
        		   alertMessage: "Data Saved Sucessfully", alertType: "confirmation"})
           }
	   });
	  this.setState({gridRowSelected:[]})
	  this.setState({DB_gridRowData:[]})

  }

  
  // *****Modify functionality*** start*******
  onCheckedGridRowClick= (event) =>{
	  if(typeof(event[0]) === 'undefined'){ 
          this.setState({disabledBtn :true})   
   	}else{ 
          if(event.length === 1){
             this.setState({gridRowSelected: {...event[0], isDateUpdated: 'N'}, disabledBtn :this.props.false  })      
          }else{
                 this.setState({disabledBtn :true}) 
          }
          } 
 }
 handleModifyButton= (event) =>{
	  const { CollateralCrossReflistActions }= this.props;
	  CollateralCrossReflistActions.list({rowId:this.state.gridRowSelected.rowId,triPartyAgentId:this.state.gridRowSelected.triPartyAgentId,houseAcctId:this.state.gridRowSelected.houseAcctId,collateralAcct:this.state.gridRowSelected.collateralAcct,counterPartyId:this.state.gridRowSelected.counterPartyId,activeFlag:this.state.gridRowSelected.activeFlag}).
	  then(res => {		 
	   this.setState({DB_gridRowData:this.props.CollateralCrossReflist.data[0], dbGrid: this.props.CollateralCrossReflist.data[0]})
	   if(this.state.DB_gridRowData.currentRecFlag==='N') {
			this.setState({showActiveInactiveFlagWindow:false, showParentAlert: true, alertType: "warning", createupdate_changeValue1: {}, DB_gridRowData: this.state.dbGrid,
			alertMessage: `You can only modify the most recent Valid From record.`})
	   }else {
			this.state.DB_gridRowData.isDateUpdated='N'
				if(this.state.DB_gridRowData.activeFlag =='Y'){
					this.setState({gridRowSelected: {...this.state.gridRowSelected, activeFlag: 'Y-Active' }});
				}else{
					this.setState({gridRowSelected: {...this.state.gridRowSelected, activeFlag: 'N-inActive' }});
				}
				this.setState({modFlag:1})
				this.setState({ showModifyModalWindow: true })
		}
}) }

  // changing previous values with selected values in Modify pop-up
  	createUpdateModalWindowChange(event){
		this.setState({showAlert: false, createupdate_changeValue1:event});
	  	if(event)
			this.setState({disableModalSaveBtn : false})
		const { createupdate_changeValue1 } = this.state;
	   	if(this.state.modFlag=="1"){			   
			if(typeof(JSON.stringify(event.datefrom)) !== 'undefined' && this.formatDate(new Date(event.datefrom)) !== this.state.DB_gridRowData.validFromDate)
				this.setState({isDateUpdated : 'Y',isDateUpdated1 : 1})	
			else
				this.setState({isDateUpdated : 'N', isDateUpdated1 : 0})
			if(typeof(JSON.stringify(event.collAcc)) !== 'undefined' && event.collAcc!== this.state.DB_gridRowData.collateralAcct) 
				this.setState({isCollateralUpdated : 1});
			else
				this.setState({isCollateralUpdated : 0})
			if(typeof(JSON.stringify(event.triparty_agentfile)) !== 'undefined' && event.triparty_agentfile!== this.state.DB_gridRowData.triPartyAgentId)
				this.setState({isTripartyUpdated : 1});
			else
				this.setState({isTripartyUpdated : 0})
			if(typeof(JSON.stringify(event.active_flag)) !== 'undefined' && event.active_flag != this.state.DB_gridRowData.activeFlag)
				this.setState({isActiveFlagUpdated : 1})
			else
				this.setState({isActiveFlagUpdated : 0})
		}
	}
handleUpdate=(event)=>{
let activeOk=0,dateOk=0,CollOk=0;
const { createupdate_changeValue1, showDateModifyModal, gridRowSelected } = this.state;
let today = new Date();
let validFrDate = new Date(createupdate_changeValue1.datefrom);
let gridValidFrmDate = new Date(gridRowSelected.validFromDate);

 //Validation
 if((this.state.isTripartyUpdated == 0 && this.state.isCollateralUpdated == 0) && 
 	(this.state.isActiveFlagUpdated == 0 && this.state.isDateUpdated1 == 0 )) {
		this.setState({
			showAlert: true,
			createupdate_changeValue1: {},
			alertType: 'confirmation',
			alertMessage: "No Changes to update",
			disableModalSaveBtn: true
		});
	}
if((this.state.isTripartyUpdated=="1" || this.state.isCollateralUpdated=="1")&& this.state.isActiveFlagUpdated=="1") {
	this.setState({
		showAlert: true,
		createupdate_changeValue1: {},
		DB_gridRowData: this.state.dbGrid,
		alertType: 'warning',
		alertMessage: "You cannot change data elements and the Active/Inactive flag at the same time. Please process data element change first."
	});
}
//	 alert("You cannot change data elements and the Active/Inactive flag at the same time.\n\n Please process data element change first.")		}
else if((this.state.isTripartyUpdated=="1" || this.state.isCollateralUpdated=="1") && this.state.isDateUpdated1=="1") {
	this.setState({
		showAlert: true,
		alertType: 'warning',
		DB_gridRowData: this.state.dbGrid,
		createupdate_changeValue1: {},
		alertMessage: "You cannot change data elements and the Effective Date at the same time. Please process the data element change first. If required, Enter effective Date when prompted."
	});	
}
else if((this.state.isActiveFlagUpdated===1 && this.state.isDateUpdated1===1)) {
	this.setState({
		showAlert: true,
		createupdate_changeValue1: {},
		DB_gridRowData: this.state.dbGrid,
		alertType: 'warning',
		alertMessage: "You cannot change data elements like  the Effective Date and the Active/Inactive flag at the same time.Please process the data element change first. If required, enter Effective Date when prompted."
	});
}
else if(validFrDate !== gridValidFrmDate && validFrDate > today) {
    this.setState({
        showAlert: true,
		disableModalSaveBtn: true,
		alertType: 'warning',
        alertMessage: "Effective Date cannot be greater than today"
    });
}
//	alert("You cannot change data elements \nand the Effective Date at the same\ntime. \n\nPlease process the data element\nchange first. If required, enter\nEffective Date when prompted.")	}
else if(this.state.isTripartyUpdated===1 || this.state.isCollateralUpdated===1 ){
	this.setState({DB_gridRowData : {...this.state.DB_gridRowData, collateralAcct: createupdate_changeValue1.collAcc, triPartyAgentId: createupdate_changeValue1.triparty_agentfile}})
	CollOk=1
} 
else if(this.state.isActiveFlagUpdated===1){
	if(createupdate_changeValue1.active_flag=='Y-Active') 
		this.setState({DB_gridRowData: {...this.state.DB_gridRowData, activeFlag: 'Y'}});
	else 
		this.setState({DB_gridRowData: {...this.state.DB_gridRowData, activeFlag: 'N'}});
	activeOk=1
}
else if(this.state.isDateUpdated1===1){
	this.setState({DB_gridRowData: {...this.state.DB_gridRowData,validFromDate: this.formatDate(validFrDate)}})
	dateOk=1}
//end of validation......
 if(activeOk==1){
	 this.setState({showActiveInactiveFlagWindow:true})
 }
 else if(CollOk===1){
	 this.setState({showDateFlagwindow:true})
 }else if(dateOk===1){
	 this.setState({showEffectiveFromdate:true})
 }
 this.setState({isActiveFlagUpdated:"0"})
 this.setState({isDateUpdated1:"0"})
 this.setState({isTripartyUpdated:"0"})
 this.setState({isCollateralUpdated:"0"})
 this.setState({disableModalSaveBtn : true})
}
handleEffectiveFromDateOk=(event)=>{
	let myDate = new Date(this.state.createupdate_changeValue1.datefrom);
	const { SaveAccountCrossRefDetailsActions }= this.props;
	SaveAccountCrossRefDetailsActions.add({iModValue:"V",rowId:this.state.DB_gridRowData.rowId,colTypeCode:this.state.DB_gridRowData.colTypeCode,collateralCode:this.state.DB_gridRowData.collateralCode,houseAcctId:this.state.DB_gridRowData.houseAcctId,counterPartyId:this.state.DB_gridRowData.counterPartyId,triPartyAgentId:this.state.DB_gridRowData.triPartyAgentId,collateralAcct:this.state.DB_gridRowData.collateralAcct,validFromDate:(myDate.getMonth()+1)+"/"+myDate.getDate()+"/"+myDate.getFullYear(),validToDate:this.state.DB_gridRowData.validToDate,isDateUpdated:this.state.DB_gridRowData.isDateUpdated,activeFlag:this.state.DB_gridRowData.activeFlag,userName:this.state.DB_gridRowData.lastModifiedId}).	    
    then(res => {if(null !== this.props.SaveAccountCrossRefDetails.data[0].errorDesc){
					this.setState({showAlert: true, alertType: "warning", showEffectiveFromdate: false, createupdate_changeValue1: {}, DB_gridRowData: this.state.dbGrid,
						alertMessage: `Failed to update data  due to : ${this.props.SaveAccountCrossRefDetails.data[0].errorDesc}`						
					});
				}
    	        //    alert("Failed to update data  due to :"+this.props.SaveAccountCrossRefDetails.data[0].errorDesc); }
    	else{ this.setState({showAlert: true, alertType: "warning", showEffectiveFromdate: false,
				 alertMessage:"Data Saved Sucessfully"});
				 this.cancel();
				this.hideModifyModal();
    	}
	});
 this.setState({isDateUpdated1:"0"})

}
onEffectiveDateChange=(event)=>{
	this.setState({effectiveFromDate:event.date_required})
}
ontripartyCorrectionClick=(event)=>{
	const { SaveAccountCrossRefDetailsActions }= this.props; 
    SaveAccountCrossRefDetailsActions.add({iModValue:"U",rowId:this.state.DB_gridRowData.rowId,colTypeCode:this.state.DB_gridRowData.colTypeCode,collateralCode:this.state.DB_gridRowData.collateralCode,houseAcctId:this.state.DB_gridRowData.houseAcctId,counterPartyId:this.state.DB_gridRowData.counterPartyId,triPartyAgentId:this.state.DB_gridRowData.triPartyAgentId,collateralAcct:this.state.DB_gridRowData.collateralAcct,validFromDate:this.state.DB_gridRowData.validFromDate,validToDate:this.state.DB_gridRowData.validToDate,isDateUpdated:this.state.DB_gridRowData.isDateUpdated,activeFlag:this.state.DB_gridRowData.activeFlag,userName:this.state.DB_gridRowData.lastModifiedId}).	    
    then(res => {if(null !== this.props.SaveAccountCrossRefDetails.data[0].errorDesc){
//    	           alert("Failed to update data  due to :"+this.props.SaveAccountCrossRefDetails.data[0].errorDesc); 
    	           this.setState({showDateFlagwindow:false, showAlert: true, alertType: "warning", createupdate_changeValue1: {}, DB_gridRowData: this.state.dbGrid,
    	        	   alertMessage: `Failed to update data  due to : ${this.props.SaveAccountCrossRefDetails.data[0].errorDesc}`})}
    	 else{
    		 this.setState({gridData:this.props.SaveAccountCrossRefDetails.data[0], 
    			 showDateFlagwindow:false, showAlert: false, showParentAlert: true, 
    			 alertMessage: "Data Saved Sucessfully", alertType: "confirmation"});
			this.cancel();  
			this.hideModifyModal();
//    	alert("Data update Sucessfullyy....");
    	}
    });
}
handleTriPartyChangeSubmit=(event)=>{
	const myDate = new Date(this.state.effectiveFromDate ? this.state.effectiveFromDate : currentDate);
	const today = new Date();
	const validFrDate = new Date(this.state.gridRowSelected.validFromDate);
	if ( myDate > today ) { //future date
		this.setState({
			showAlert: true,
			effectiveFromDate: "",
			alertType: "warning",
			alertMessage: "Effective Date cannot be greater than today"
		});
	}else if(myDate.setHours(0,0,0,0) == today.setHours(0,0,0,0)) {
		this.setState({
			showAlert: true,
			effectiveFromDate: "",
			alertType: "warning",
			alertMessage: `Effective Date cannot be the equal to Current Valid From date 
				for a change. It can only be a correction.`
		});
	}else if ( myDate < validFrDate ) { //entered date is less than today's date
		// alert('Effective Date should be greater than Current Valid From Date ');
		this.setState({
			showAlert: true,
			effectiveFromDate: "",
			alertType: "warning",
			alertMessage: "Effective Date should be greater than Current Valid From Date"
		});
	}
	if(this.state.effectiveFromDate==''||this.state.effectiveFromDate==null)
		this.setState({effectiveFromDate:this.state.DB_gridRowData.validFromDate})
	const { SaveAccountCrossRefDetailsActions }= this.props; 
	if(this.state.effectiveFromDate!=''||this.state.effectiveFromDate!="undefined"){
	!this.state.showAlert && SaveAccountCrossRefDetailsActions.add({iModValue:"C",rowId:this.state.DB_gridRowData.rowId,colTypeCode:this.state.DB_gridRowData.colTypeCode,collateralCode:this.state.DB_gridRowData.collateralCode,houseAcctId:this.state.DB_gridRowData.houseAcctId,counterPartyId:this.state.DB_gridRowData.counterPartyId,triPartyAgentId:this.state.DB_gridRowData.triPartyAgentId,collateralAcct:this.state.DB_gridRowData.collateralAcct,validFromDate:(myDate.getMonth()+1)+"/"+myDate.getDate()+"/"+myDate.getFullYear(),validToDate:this.state.DB_gridRowData.validToDate,isDateUpdated:"Y",activeFlag:this.state.DB_gridRowData.activeFlag,userName:this.state.DB_gridRowData.lastModifiedId}).	    
	    then(res => {if(null !== this.props.SaveAccountCrossRefDetails.data[0].errorDesc ){
	           this.setState({showDateFlagwindow:false, showAlert: true, alertType: "warning",  createupdate_changeValue1: {}, DB_gridRowData: this.state.dbGrid,
	        	   alertMessage: `Failed to update data  due to : ${this.props.SaveAccountCrossRefDetails.data[0].errorDesc}`})         
//	    	alert("Failed to update data  due to :"+this.props.SaveAccountCrossRefDetails.data[0].errorDesc); 
	        }
	    	 else{ 
	    		 this.setState({gridData:this.props.SaveAccountCrossRefDetails.data[0], showDateFlagwindow:false,
	    			 showAlert: false, showParentAlert: true, 
	    			 alertMessage: "Data Saved Sucessfully", alertType: "confirmation"})
				this.cancel(); 
				this.hideModifyModal(); 
	    	 }
	    });
	}
}

handleActiveinactivechange=(event)=>{
	const { SaveAccountCrossRefDetailsActions }= this.props; 
	 SaveAccountCrossRefDetailsActions.add({iModValue:"IC",rowId:this.state.DB_gridRowData.rowId,colTypeCode:this.state.DB_gridRowData.colTypeCode,collateralCode:this.state.DB_gridRowData.collateralCode,houseAcctId:this.state.DB_gridRowData.houseAcctId,counterPartyId:this.state.DB_gridRowData.counterPartyId,triPartyAgentId:this.state.DB_gridRowData.triPartyAgentId,collateralAcct:this.state.DB_gridRowData.collateralAcct,validFromDate:this.state.DB_gridRowData.validFromDate,validToDate:this.state.DB_gridRowData.validToDate,isDateUpdated:this.state.DB_gridRowData.isDateUpdated,activeFlag:this.state.createupdate_changeValue1.active_flag,userName:this.state.DB_gridRowData.lastModifiedId}).	    
	    then(res => {if(null !== this.props.SaveAccountCrossRefDetails.data[0].errorDesc){
//	    	           alert("Failed to update data  due to :"+this.props.SaveAccountCrossRefDetails.data[0].errorDesc); 
	    	           this.setState({showActiveInactiveFlagWindow:false, showAlert: true, alertType: "warning", createupdate_changeValue1: {}, DB_gridRowData: this.state.dbGrid,
	    	        	   alertMessage: `Failed to update data  due to : ${this.props.SaveAccountCrossRefDetails.data[0].errorDesc}`})}
	    	 else{ this.setState({gridData:this.props.SaveAccountCrossRefDetails.data[0]})
	           this.setState({showActiveInactiveFlagWindow:false, showAlert: false, showParentAlert: true, 
	    			 alertMessage: "Data Saved Sucessfully", alertType: "confirmation"});
				this.cancel();
				this.hideModifyModal();
	    	 }
	    });
 
}
handleActiveinactivecorrection=(event)=>{
	const { SaveAccountCrossRefDetailsActions }= this.props;
	 SaveAccountCrossRefDetailsActions.add({iModValue:"I",rowId:this.state.DB_gridRowData.rowId,colTypeCode:this.state.DB_gridRowData.colTypeCode,collateralCode:this.state.DB_gridRowData.collateralCode,houseAcctId:this.state.DB_gridRowData.houseAcctId,counterPartyId:this.state.DB_gridRowData.counterPartyId,triPartyAgentId:this.state.DB_gridRowData.triPartyAgentId,collateralAcct:this.state.DB_gridRowData.collateralAcct,validFromDate:this.state.DB_gridRowData.validFromDate,validToDate:this.state.DB_gridRowData.validToDate,isDateUpdated:this.state.DB_gridRowData.isDateUpdated,activeFlag:this.state.createupdate_changeValue1.active_flag,userName:this.state.DB_gridRowData.lastModifiedId}).	    
	    then(res => {if(null !== this.props.SaveAccountCrossRefDetails.data[0].errorDesc){
//	    	           alert("Failed to update data  due to :"+this.props.SaveAccountCrossRefDetails.data[0].errorDesc); 
	    	           this.setState({showActiveInactiveFlagWindow:false, showAlert: true, alertType: "warning",  createupdate_changeValue1: {}, DB_gridRowData: this.state.dbGrid,
	    	        	   alertMessage: `Failed to update data  due to : ${this.props.SaveAccountCrossRefDetails.data[0].errorDesc}`})}
	    	 else{
	    		 this.setState({gridData:this.props.SaveAccountCrossRefDetails.data[0], showActiveInactiveFlagWindow:false,
	    		 showAlert: false, showParentAlert: true, alertMessage: "Data Saved Sucessfully", alertType: "confirmation"});
				 this.cancel(); 
				 this.hideModifyModal();	 
	    	}
	    });
 
}

// ******* Modify **** ends****

  handlePrePagination=(event) =>{
	  if(this.state.prePageValue !== 1){
	    const { AccountCrossRefListActions }= this.props; 
	    const { FilterComponentChanges } = this.state;
	    const fromDate = FilterComponentChanges.fromdate_required 
			? this.formatDate(new Date(FilterComponentChanges.fromdate_required))
			: FilterComponentChanges.fromdate_required ;
		const toDate = FilterComponentChanges.todate_required
			? this.formatDate(new Date(FilterComponentChanges.todate_required))
			: FilterComponentChanges.todate_required;
	    AccountCrossRefListActions.list({paginationType:'pre',pageNo:(this.state.prePageValue-1<=0 ? 1 : this.state.prePageValue-1),colTypeCode:'',
	    	collateralCode:this.state.FilterComponentChanges.collcode,houseAcctId:this.state.FilterComponentChanges.house_id,
	    	counterPartyId:this.state.FilterComponentChanges.ctpyId,triPartyAgentId:this.state.FilterComponentChanges.triparty_agentfile,
	    	collateralAcct:this.state.FilterComponentChanges.collAcc,validFromDate:fromDate,
	    	validToDate:toDate,activeFlag:this.state.FilterComponentChanges.active_flag}).
		    then(res => {
		    	this.setState({gridData:this.props.AccountCrossRefList.data[0]})
		    	this.setState({prePageValue : JSON.stringify(this.props.AccountCrossRefList.data[0].prePageNo) ,nextPageValue : JSON.stringify(this.props.AccountCrossRefList.data[0].nextPageNo)})
		    	if ( this.props.AccountCrossRefList.data[0].isNextDisable === 'N'){ 
			    		 this.setState({disabledNxtBtn : false}) 
			    }
		    	if(this.props.AccountCrossRefList.data[0].pageNumber == 1) this.setState({disabledPreBtn: true});

			     })       	
 	  }
  }

  handleNextPagination=(event) =>{
	    const { AccountCrossRefListActions }= this.props;
	    const { FilterComponentChanges } = this.state;
	    const fromDate = FilterComponentChanges.fromdate_required 
			? this.formatDate(new Date(FilterComponentChanges.fromdate_required))
			: FilterComponentChanges.fromdate_required ;
		const toDate = FilterComponentChanges.todate_required
			? this.formatDate(new Date(FilterComponentChanges.todate_required))
			: FilterComponentChanges.todate_required;
	    AccountCrossRefListActions.list({paginationType:'next',pageNo:this.state.nextPageValue,colTypeCode:'',
	    	collateralCode:this.state.FilterComponentChanges.collcode,houseAcctId:this.state.FilterComponentChanges.house_id,
	    	counterPartyId:this.state.FilterComponentChanges.ctpyId,triPartyAgentId:this.state.FilterComponentChanges.triparty_agentfile,
	    	collateralAcct:this.state.FilterComponentChanges.collAcc,validFromDate:fromDate,
	    	validToDate:toDate,activeFlag:this.state.FilterComponentChanges.active_flag}).
	    then(res => {
	    	this.setState({prePageValue : JSON.stringify(this.props.AccountCrossRefList.data[0].prePageNo) ,
    			nextPageValue : JSON.stringify(this.props.AccountCrossRefList.data[0].nextPageNo),
				disabledPreBtn: false, gridData:this.props.AccountCrossRefList.data[0],
				gridData:this.props.AccountCrossRefList.data[0]})
			 if ( this.props.AccountCrossRefList.data[0].isNextDisable === 'Y'){ 
	    		 this.setState({disabledNxtBtn : true})
			 }
	    });
  }

  cancel = () => { 
	this.setState({FilterComponentChanges : PageSchema});
	this.loadGridData();
  }
  onClose = () => {
	  this.setState({showParentAlert: false, showAlert :  false});
  }

  formatDate(date) {
	  return date 
	  	? `${date.getMonth()> 9?'':'0'}${date.getMonth()+1}/${date.getDate()> 9?'':'0'}${date.getDate()}/${date.getFullYear()}`
	  	: ""
  }
	  
  render() {
	const showAlertBanner = (bannerProp) => {
		const { type, label, inline = true } = bannerProp;
		return (
			<div style={{marginBottom: '10px'}}>
			<AlertBanner type={type} label={label} onClose={this.onClose} inline={inline} rootClose={true}/>
			</div>
		);
	};
	const { gridRowSelected } = this.state;
	let collcode, triparty, houseId, collAct, activeFlage;
	this.state.ccData_DD.forEach((item) => {
		if(item.label === gridRowSelected.collateralCode) collcode = item.value;
	})
	this.state.triparty_DD.forEach((item) => {
	if(item.label === gridRowSelected.triPartyAgentId) triparty = item.value;
	})
	this.state.houseId_DD.forEach((item) => {
		if(item.label === gridRowSelected.houseAcctId) houseId = item.value;
	})
	this.state.collAcc_DD.forEach((item) => {
		if(item.label === gridRowSelected.counterPartyId) collAct = item.value;
	})
	activeflg.forEach((item) => {
		if(item.label === gridRowSelected.activeFlag) activeFlage = item.value;
	})

	  const modifyModalValues = {
		collcode: collcode,
		triparty_agentfile: triparty,
		datefrom: new Date(this.state.gridRowSelected.validFromDate),
		house_id: houseId,
		collAcc: collAct,
		dateto: this.formatDate(new Date(this.state.gridRowSelected.validToDate)),
		ctpyId: this.state.gridRowSelected.counterPartyId,
		active_flag:activeFlage,
		userId: this.state.gridRowSelected.lastModifiedId,
		lastModified: this.state.gridRowSelected.lastModifiedDate
	};
      return (
      <div className="form-example" style={{ position: 'absolute', width: '100%'}}>
      {this.state.showParentAlert ? showAlertBanner({type: this.state.alertType, label: this.state.alertMessage, inline: false}) : null}
     
      <Form  
      id="Filter"
	  schema={PageSchema}
      value={{fromdate_required: moment(),todate_required: new Date(validEndDate),
		  ...this.state.FilterComponentChanges}}
      style={{ width: '100%',border:'single'}}
      margin-top='0px'
      padding-top='0px'
      height='400px'
      horizontal
      fieldWidth='400px'
      labelWidth='150px'
    onChange={this.handleFilterComponentChange}  
      onSubmit={this.handleSubmit}
      >
          <Form.Field  name='collcode' type='select' title="Collateral Code:" options={this.state.ccData_DD}  placeholder={this.state.all}    noValidate  />
          <Form.Field  name='triparty_agentfile' type='select' title="Triparty Agnt File:" options={this.state.triparty_DD}   placeholder='ALL'  />	
          <Form.Field title="Valid From:*" type="datepicker" name='fromdate_required'style={{width:'230px'}}/> 
          <Form.Field   name='house_id'type='select' title="House Id:" options={this.state.houseId_DD} placeholder='ALL'  />
          <Form.Field ref="refCollCode"    name="collAcc" title="Collateral Acct:" />
          <Form.Field title="Valid To:*" type="datepicker" name='todate_required' style={{width:'230px'}} />
          <Form.Field name="ctpyId"   title=" DML Ctpy Id:" />
          <Form.Field  name='active_flag' type='select' title="Active/Inactive:" options={activeflg} placeholder='ALL' />
          <br/><br/>
         <Form.Button type='submit' bsStyle="primary" bsSize="small" style={{ float: 'left' ,marginLeft: '50px' ,width:'100px', height:'35px'}} > Refresh </Form.Button>
         <Form.Button type='button' bsStyle="primary" bsSize="small"  style={{ float: 'left' , marginRight: '50px',width:'100px' ,height:'35px'  }} onClick={this.cancel}> Clear </Form.Button>
       </Form>
       <div style={{ position: 'right', height: 30, width: '100%' }}>
       	<Button  style={{ float: 'right' , marginRight: '25px',width:'100px', height:'35px'  }} onClick={this.showModal} bsSize="small">Create</Button>	
       	<Button  style={{ float: 'right' , marginRight: '25px' ,width:'100px', height:'35px' }} disabled={this.state.disabledBtn}  bsSize="small" onClick={this.handleModifyButton}  bsStyle="primary">Modify</Button>		
        <Button  style={{ float: 'right' , marginRight: '25px' ,width:'100px', height:'35px' }} disabled={this.state.disabledNxtBtn}  onClick={this.handleNextPagination}    bsSize="small"   bsStyle="primary">Next</Button>	
        <Button  style={{ float: 'right' , marginRight: '25px',width:'100px', height:'35px'  }}   disabled={this.state.disabledPreBtn} onClick={this.handlePrePagination}    bsSize="small"   bsStyle="primary">Pre</Button>
        <p style={{ float: 'right' , marginright: '24pt',color:'blue'  }} >{this.state.gridData.recordsPerPage} of {this.state.gridData.totalRecords} </p>
        <input type='text' name="Total records" hidden value={this.state.prePageValue || ''}/>
       </div>
	   <br/>
	   <br/>
       <div style={{ position: 'relative', height: 500, width: '100%' }}>
	    	<DataGrid showBorders={true}
	         columns={dmlCollAcctXRefConfig} onCheckedChange={this.onCheckedGridRowClick} 
	    	 keyFieldName="id" data={this.state.gridData.accountCrossRefVOList}  hasCheckbox clearSelectionOnRefresh
	    	 
	    	title="DML Collateral Account Cross Reference List" 
	    	/>
	   </div>
	   <Modal animation={false} show={this.state.show}  onHide={this.hideCreateModal}>
	     <Modal.Header>
         	<Modal.Title>DML Collateral Account Cross Reference Detail-Create</Modal.Title>
         </Modal.Header>
         <Modal.Body>
         {this.state.showAlert ? showAlertBanner({type: this.state.alertType, label: this.state.alertMessage}) : null}
        <Form id="Filter" schema={CreatePageSchema} style={{ width: '100%',border:'single'}}
        	value = {{ fromdate_required: moment(), todate_required: new Date(validEndDate), ...this.state.createupdate_changeValue1}}
			margin-top='0px' padding-top='0px'  height='425px'  horizontal fieldWidth='400px'labelWidth='150px' 
			onChange={this.createUpdateModalWindowChange}   onSubmit={this.handleSave} >
        	<Form.Field  name='collcode' type='select' title="Collateral Code:" options={this.state.ccData_DD}  noValidate  />
        	<Form.Field  name='triparty_agentfile' type='select' title="Triparty Agnt File:"  onChange={this.tripartyAgentOnChange} options={this.state.triparty_DD}   />
        	<Form.Field title="Valid From:*" type="datepicker" name='fromdate_required'style={{width:'230px'}} /> 
        			<Form.Field   name='house_id'type='select' title="House Id:" options={this.state.houseId_DD}   />
        			<Form.Field   name="collAcc" type='select' title="Collateral Acct:" options={this.state.collAcc_DD} />
        			<Form.Field title="Valid To:*" type="datepicker" name='todate_required' style={{width:'230px'}} disabled/>
        			<Form.Field name="ctpyId"  type='select' title="Primary DML Ctpy Id:"  options={this.state.ctpyId_DD}/>
        			<Form.Field  name='active_flag' type='select' title="Active/Inactive:" options={activeflg} placeholder="Y-Active" disabled/>
        			<Form.Field name="userId"   title="User Id:" disabled/>
        			<Form.Field name="lastModified"   title="Last Modified" disabled/>
          	<br/>
				<div align="center">
         <Form.Button type='submit' bsStyle="primary" bsSize="small" disabled={this.state.disableModalSaveBtn}>Save</Form.Button>
         <Form.Button type='button' bsStyle="primary" bsSize="small" onClick={this.hideCreateModal}>Cancel</Form.Button>
		</div>

         </Form>
        </Modal.Body>
       
    </Modal>
    <Modal animation={false} show={this.state.showModifyModalWindow}  onHide={this.hideModifyModal}>
    <Modal.Header>
    	<Modal.Title>Edit Collateral Account Cross Reference Detail-Modify</Modal.Title>
    </Modal.Header>
    <Modal.Body>
    {this.state.showAlert ? showAlertBanner({type: this.state.alertType, label: this.state.alertMessage}) : null}
   <Form id="Filter" schema={UpdatePageSchema}   style={{ width: '100%',border:'single'}} 
	   margin-top='0px' padding-top='0px'  height='425px'  horizontal
	   value = {{...modifyModalValues, ...this.state.createupdate_changeValue1}}
	   fieldWidth='400px'labelWidth='150px' onChange={this.createUpdateModalWindowChange} 
	   onSubmit={this.handleUpdate} >
   	<Form.Field  name='collcode' type='select' title="Collateral Code:" options={this.state.ccData_DD}  placeholder={this.state.gridRowSelected.collateralCode} noValidate disabled  />
   	<Form.Field  name='triparty_agentfile' type='select' title="Triparty Agnt File:" options={this.state.triparty_DD} onChange={this.tripartyAgentOnChange} placeholder={this.state.gridRowSelected.triPartyAgentId} />
   	<Form.Field title="Valid From:*" type="datepicker" name='datefrom' style={{width:'230px'}} placeholder={this.state.gridRowSelected.validFromDate}/> 
   			<Form.Field   name='house_id'type='select' title="House Id:" options={this.state.houseId_DD} placeholder={this.state.gridRowSelected.houseAcctId} disabled />
   			<Form.Field   name="collAcc" type='select' title="Collateral Acct:" options={this.state.collAcc_DD} placeholder={this.state.gridRowSelected.collateralAcct} />
   			<Form.Field title="Valid To:*"  name='dateto' style={{width:'230px'}} placeholder={this.state.gridRowSelected.validToDate} disabled />
   			<Form.Field name="ctpyId"   title="Primary DML Ctpy Id:" placeholder={this.state.gridRowSelected.counterPartyId} disabled/>
   			<Form.Field  name='active_flag' type='select' title="Active/Inactive:" options={modactiveflg} placeholder={this.state.gridRowSelected.activeFlag} />
   			<Form.Field name="userId"   title="User Id:" placeholder={this.state.gridRowSelected.lastModifiedId} disabled/>
   			<Form.Field name="lastModified"   title="Last Modified" placeholder={this.state.gridRowSelected.lastModifiedDate} disabled/>
     	<br/>
		<div style= {{"textAlign": "center", marginTop: "30px"}}>
    <Form.Button type='submit' bsStyle="primary" bsSize="small"  disabled={this.state.disableModalSaveBtn}>Save</Form.Button>
    <Form.Button type='button' bsStyle="primary" bsSize="small"  onClick={this.hideModifyModal}>Cancel</Form.Button> 
		</div>
    </Form>
   </Modal.Body>
  
</Modal>

<Modal animation={false} show={this.state.showDateFlagwindow}  onHide={this.hideDateFlagwindow}>
<Modal.Header><Modal.Title>Effective Date Change</Modal.Title></Modal.Header>
<Modal.Body>
{this.state.showAlert ? showAlertBanner({type: this.state.alertType, label: this.state.alertMessage}) : null}
	<div >
	<p>Is this modification a correction to existing data, or a change to processing data? If it is a change to processing data, please also
	include the effective date of the change </p>
	<Form id="Filter"  style={{ width: '100%',border:'single'}} margin-top='0px' padding-top='0px'  height='425px' 
		schema={effectiveDate_Schema} defaultValue={{date_required:moment()}} horizontal fieldWidth='400px'labelWidth='150px' onChange={this.onEffectiveDateChange}   onSubmit={this.handleTriPartyChangeSubmit} >
	<Form.Field title="Effective Date" type="datepicker" name='date_required' /> 
			<br/>
   <Form.Button type='button' bsStyle="primary" style={{ float: 'left'  }} onClick={this.ontripartyCorrectionClick}>Correction</Form.Button>
   <Form.Button type='submit' bsStyle="primary" style={{ float: 'left'  }}>Change</Form.Button>
   <Form.Button type='button'  style={{ float: 'left'  }} onClick={this.hideDateFlagwindow}>Cancel</Form.Button>
   </Form>
   </div>
</Modal.Body>
 </Modal>
 
 <Modal animation={false} show={this.state.showActiveInactiveFlagWindow}  onHide={this.hideActiveInactiveFlagWindow}>
 <Modal.Header><Modal.Title>Active/Inactive Change</Modal.Title></Modal.Header>
 <Modal.Body>
 	<div >
 	<p>Is this modification a correction to existing data, or a change to processing data? If it is a change to processing data, please also
 	include the effective date of the change </p>
 	 <Button bsStyle="primary" bsSize="small" style={{width:'100px', height:'35px'  }} onClick={this.handleActiveinactivechange}> Change </Button>  
 	 <Button bsStyle="primary" bsSize="small" style={{width:'100px', height:'35px'  }} onClick={this.handleActiveinactivecorrection}> Correction </Button>  
 	 <Button bsStyle="primary" bsSize="small" style={{width:'100px', height:'35px'  }} onClick={this.hideActiveInactiveFlagWindow}> Cancel </Button>  

    </div>
 </Modal.Body>
  </Modal>
  
	<Modal animation={false} show={this.state.showEffectiveFromdate}  onHide={this.hideEffectiveFromdateWindow}>
	 <Modal.Header><Modal.Title>DateModify</Modal.Title></Modal.Header>
	 <Modal.Body>
	 	<div >
	 	<p>You have modified the effective date; do you wish to proceed with this change?</p>
	 	 <Button bsStyle="primary" bsSize="small" style={{width:'100px', height:'35px'  }} onClick={this.handleEffectiveFromDateOk}> ok </Button>  
	 	 <Button bsStyle="primary" bsSize="small" style={{width:'100px', height:'35px'  }} onClick={this.hideEffectiveFromdateWindow}> Cancel </Button>  
	    </div>
	 </Modal.Body>
	  </Modal>
  </div>
    
  )}
}
Template.propTypes =  {
		  CollateralAccountCrossRefActions:PropTypes.any,
		  CollateralCodeDDListActions:PropTypes.any,
		  HouseDetailsDDListActions:PropTypes.any,
		  TriPartyAgentDDListActions:PropTypes.any,
		  DMLCtpylistActions:PropTypes.any,
		  CollateralCrossReflistActions:PropTypes.any,
		  SaveAccountCrossRefDetailsActions:PropTypes.any,
		  CollateralAccountListActions:PropTypes.any,
		  AccountCrossRefListActions:PropTypes.any,
		  CollateralAccountCrossRef:PropTypes.any,
		  CollateralCodeDDList:PropTypes.any,
		  HouseDetailsDDList:PropTypes.any,
		  TriPartyAgentDDList:PropTypes.any,
		  DMLCtpylist:PropTypes.any,
		  HouseDetailsDDList:PropTypes.any,
		  CollateralCrossReflist:PropTypes.any,
		  SaveAccountCrossRefDetails:PropTypes.any,
		  CollateralAccountList:PropTypes.any,
		  AccountCrossRefList:PropTypes.any,
		  DmlDDList:PropTypes.any,
		  DmlDDListActions:PropTypes.any
}