import React from "react"
import PropTypes from 'prop-types'

export default class WelcomePage extends React.Component {
	render() {
		return(
			<h1 style= {{ 'textAlign': 'center'}}>Welcome to State Street Corp. </h1>
		)
	}
}