import React from "react"
import PropTypes from 'prop-types'
import {GlobalNavigation, SecondaryNavigation}from 'ssc-cdt4'
import { Redirect, Route, IndexRedirect,Switch,withRouter } from 'react-router-dom';
import classNames from 'classnames'
import inv from '../investmentVehiclepages/index';
import oir from '../oirPages/welcomePage'
import dml from '../sldpage/FilterCriteria'

const ProfileMenu = [ 
    {id:0, label:'My Account'},  
    {id:1, label:'Settings'},  
    {id:2, label:'Help'},  
    {id:3, label:'Client View'},  
    {id:4, label:'Log Out'}
]

class AppContainer extends React.Component {
    constructor(props) {
        super(props)
        
        const defaultKey = props.location.pathname.slice(1)
        this.state =  {
            navTop:false, 
            defaultKey:defaultKey?defaultKey:'WelcomePage',
            routes: [],
            isDmlEnabled: false,
            isInvEnabled: false
        }
    }
    componentDidMount() {
        //This can be replaced when we implement user login security feature
        const isDmlEnabled = true;
        const isInvEnabled = true;
        let children = [];
        this.setState({isDmlEnabled: isDmlEnabled, isInvEnabled: isInvEnabled});
        if(isDmlEnabled) {
            const child = {
                key: 'dml',
                title:'DML Page'
            };
            children.push(child);
        }
        if(isInvEnabled) {
            const child = {
                key: 'inv',
                title:'INV Page'
            };
            children.push(child);
        }
        if(children.length > 0) {
            this.setState({routes: [
                {key: 'home', title:'OIR Home', children: children}
            ]});
        }
        else this.setState({routes: [{key: 'home', title:'OIR Home'}]});


    }
    componentWillReceiveProps(nextProps) {
        const defaultKey = nextProps.location.pathname.slice(1)
        this.setState( {defaultKey:defaultKey?defaultKey:'WelcomePage'})
      }
    selectMenu = (e) => {
        this.props.history.push(`${e.key}`)
    }
    render() {
        const {children} = this.props 
        const {defaultKey} = this.state 
        
        return ( 
            < div style =  {{height:'100%'}} >  
                < GlobalNavigation
                    profileMenu =  {ProfileMenu}
                    userName = "User"
                   // productName = "Design2.0 Showcase"
                />  
                < SecondaryNavigation 
                    data =  {this.state.routes}
                    defaultSelectedKey =  {defaultKey}
                    className = 'templateSideNav'
                    autoLink =  {false}
                    onSelect =  {this.selectMenu}
                />  
                <Switch>
                    <Route path="/" exact component={oir} />
                    <Route path="/home" exact component={oir} />
                    {this.state.isDmlEnabled && <Route path="/dml" component={dml}/>}
                    {this.state.isInvEnabled && <Route path="/inv" component={inv}/>}     
                </Switch>
            </div > 
        )
    }
}

AppContainer.propTypes =  {
    children:PropTypes.node, 
    router:PropTypes.object, 
    location:PropTypes.object,
    history:PropTypes.any
}

AppContainer.contextTypes = {
    router: PropTypes.object
}
export default withRouter(AppContainer)