import React from "react"
import PropTypes from 'prop-types'
import { Provider } from 'react-redux';
import { createStore, applyMiddleware, combineReducers } from 'redux';
import {restMiddleware, restReducer} from 'ssc-cdt4';
import {BrowserRouter, Route } from 'react-router-dom';
import {IntlProvider} from 'react-intl';
import AppContainer from './AppContainer'
import reactIntlFormat from "./ReactIntlBaseFormats";
const reducers = {
  restReducer
  };
let store

export default class RestApp extends React.Component {

  constructor(props) {
    super(props);
    const middleware = restMiddleware(this.props.contextPath);
    const rootReducer = combineReducers(reducers);
    store = createStore(
      rootReducer,
      applyMiddleware(middleware)
    );
  }

  render() {
    return (
      <IntlProvider locale={'en-US'} formats={reactIntlFormat}>
        <Provider store={store}>
          <BrowserRouter
					basename={this.props.contextPath}
          >
					<Route path={'/'} component={AppContainer}/>
					</BrowserRouter>
        </Provider>
      </IntlProvider>
    );
  }
}
RestApp.propTypes =  {
  contextPath:PropTypes.string
}