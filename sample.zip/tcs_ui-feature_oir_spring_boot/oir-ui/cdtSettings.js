import {CDTConsoleLogHandler, CDTELKLogHandler, eventLogHandler, appConfig} from 'cdt-core';



/**
 * Custom Error handler by the consumer app
 * @return Object of handler functions
 */
export const consoleLogHandler = {
    logError: function(message, errorCode){
        console.error(message);
    },
    logWarning: function(message){
        console.warning(message);
    },
    logInformation: function(message){
        console.info(message);
    },
    logDebug: function(message){
        console.debug(message);
    }
}

/**
 * Export setting variable
 */
function callBack(params){

    console.log("inside call back - app",params);
    return params;
}
export const cdtSettings = {
    configEndPoints:[],
    logHandlers: [ consoleLogHandler /*, CDTELKLogHandler */],
    eventLogHandler : [/*eventLogHandler*/],
    eventCallBack : '',
    errorPage : 'http://localhost:8000/error-page',
    logObjCallback : callBack

};
