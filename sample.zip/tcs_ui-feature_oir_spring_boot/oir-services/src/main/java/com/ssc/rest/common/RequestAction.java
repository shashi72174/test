package com.ssc.rest.common;

public interface RequestAction {
	
    public static final String ADD = "add";
	public static final String UPDATE = "update";
	public static final String DELETE = "delete";
	public static final String LOAD = "load";
	public static final String LIST = "list";
	public static final String RESPONSE_TYPE_FAILURE = null;
	public static final String COLLATERAL_CODE_LIST = "ggg";
	

	
}
