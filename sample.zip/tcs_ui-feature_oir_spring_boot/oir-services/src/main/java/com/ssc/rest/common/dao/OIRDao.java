package com.ssc.rest.common.dao;

import com.ssc.rest.common.entity.OIRFilterDropdowndetails;

public interface OIRDao {

	public OIRFilterDropdowndetails getOIRFilterDropdowndetails();
	
	public final String COLLATERAL_LIST_QUERY="select codevalue,codelongdescription from slid.refcode_actvcollateralcd_v";
	
	public final String HOUSE_LIST_QUERY="select codevalue,codevalue from SLID.REFCODE_HOUSE_ID_V";
	
	public final String TRIPARTY_LIST_QUERY="select codevalue,codelongdescription from SLID.REFCODE_TPAGENTID_V";
	
	public final String DMLCTPY_LIST_QUERY="select codevalue,codelongdescription from SLID.refcode_actvdmlctpy_v";
	
	

}
