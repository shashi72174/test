package com.ssc.rest.inv.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssc.rest.common.RequestAction;
import com.ssc.rest.inv.entity.InvestVehicleRefVO;
import com.ssc.rest.inv.entity.InvestmentvehiclerefDetails;
import com.ssc.rest.inv.service.InvestmentvehicleService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(value = "/saveInvVehicleDetails", tags = "SaveInvVehicleDetails Account Api")
@RequestMapping(value = "/api/saveInvVehicleDetails")
public class SaveInvVehicleDetailsController {
	@Autowired
	InvestmentvehicleService investmentvehicleService;
	private static final Logger log=Logger.getLogger(SaveInvVehicleDetailsController.class);
	public final String DEFAULT_USERNAME="ANONYMOUS";
	/**
	 * http://localhost:8080/cloudservices/api/saveInvVehicleDetails/add Used to
	 * save newly created records or Modified records to table
	 * 
	 * Content-Type: application/json request body object is mandatory {} return
	 * AccountCrossRefDetails object (data as response if sucess or error data
	 * from storeproc in obj) as response
	 * 
	 * @param bo
	 * @return
	 */
	@RequestMapping(value = RequestAction.ADD, method = { RequestMethod.POST })
	@ApiOperation(value = "saveInvVehiclerefDetails", notes = " saveInvVehicleDetails", httpMethod = "POST", response = InvestVehicleRefVO.class, responseContainer = "Object")
	public InvestmentvehiclerefDetails saveInvVehicleDetails(@RequestBody InvestVehicleRefVO vo) {
		log.info("saveInvVehicleDetails obj is:"+vo.toString());
		if(null==vo.getUserName() || vo.getUserName().isEmpty()){
		vo.setUserName(DEFAULT_USERNAME);
		}
		return investmentvehicleService.saveinvVehicleDetails(vo);
	}

}
