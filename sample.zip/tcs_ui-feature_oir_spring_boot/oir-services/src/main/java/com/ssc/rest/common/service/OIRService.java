package com.ssc.rest.common.service;

import com.ssc.rest.common.entity.OIRFilterDropdowndetails;

public interface OIRService
{

    public OIRFilterDropdowndetails getCollDDData();
    
   
}
