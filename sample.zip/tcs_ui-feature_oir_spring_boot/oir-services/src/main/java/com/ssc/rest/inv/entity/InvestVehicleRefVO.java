package com.ssc.rest.inv.entity;

import java.io.Serializable;

public class InvestVehicleRefVO implements Serializable{
	private static final long serialVersionUID = 1L;

	private String sourceCode;    
    private String triPartyAgentId;    
    private String validFromDate;    
    private String sourceInvvehicleId;    
    private String collateralAcct;   
    private String primaryDMLCtpyId;
    private String validToDate;    
    private String ctpyId;  
    private String ctpyEntityId;  
    private String ctpyDMLNM;
    private String srcCollCode;    
    private String activeFlag;    
    private String lastModifiedId;    
    private String lastModifiedDate;   
    private String currentRecFlag;
    private String ssgaCollCode;
    private String sourceVehicleText;
    private String sourceCtpytxt;
    private String invVehInvestmentNM;
    private String rowId;
    private String userName;
    private int pageNo;
    private String paginationType;
    private String searchTypeFlag;
    private String isDateUpdated;
    private String iModValue;
    private String invVehicleId;
    
    
	public String getSourceCode() {
		return sourceCode;
	}
	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}
	public String getTriPartyAgentId() {
		return triPartyAgentId;
	}
	public void setTriPartyAgentId(String triPartyAgentId) {
		this.triPartyAgentId = triPartyAgentId;
	}
	public String getValidFromDate() {
		return validFromDate;
	}
	public void setValidFromDate(String validFromDate) {
		this.validFromDate = validFromDate;
	}
	public String getSourceInvvehicleId() {
		return sourceInvvehicleId;
	}
	public void setSourceInvvehicleId(String sourceInvvehicleId) {
		this.sourceInvvehicleId = sourceInvvehicleId;
	}
	public String getCollateralAcct() {
		return collateralAcct;
	}
	public void setCollateralAcct(String collateralAcct) {
		this.collateralAcct = collateralAcct;
	}
	public String getValidToDate() {
		return validToDate;
	}
	public void setValidToDate(String validToDate) {
		this.validToDate = validToDate;
	}
	public String getCtpyId() {
		return ctpyId;
	}
	public void setCtpyId(String ctpyId) {
		this.ctpyId = ctpyId;
	}
	public String getSrcCollCode() {
		return srcCollCode;
	}
	public void setSrcCollCode(String srcCollCode) {
		this.srcCollCode = srcCollCode;
	}
	public String getActiveFlag() {
		return activeFlag;
	}
	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}
	public String getLastModifiedId() {
		return lastModifiedId;
	}
	public void setLastModifiedId(String lastModifiedId) {
		this.lastModifiedId = lastModifiedId;
	}
	public String getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getCurrentRecFlag() {
		return currentRecFlag;
	}
	public void setCurrentRecFlag(String currentRecFlag) {
		this.currentRecFlag = currentRecFlag;
	}
	public String getRowId() {
		return rowId;
	}
	public void setRowId(String rowId) {
		this.rowId = rowId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getPageNo() {
		return pageNo;
	}
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	public String getPaginationType() {
		return paginationType;
	}
	public void setPaginationType(String paginationType) {
		this.paginationType = paginationType;
	}
	public String getSearchTypeFlag() {
		return searchTypeFlag;
	}
	public void setSearchTypeFlag(String searchTypeFlag) {
		this.searchTypeFlag = searchTypeFlag;
	}
	public String getIsDateUpdated() {
		return isDateUpdated;
	}
	public void setIsDateUpdated(String isDateUpdated) {
		this.isDateUpdated = isDateUpdated;
	}
	public String getiModValue() {
		return iModValue;
	}
	public void setiModValue(String iModValue) {
		this.iModValue = iModValue;
	}
	public String getPrimaryDMLCtpyId() {
		return primaryDMLCtpyId;
	}
	public void setPrimaryDMLCtpyId(String primaryDMLCtpyId) {
		this.primaryDMLCtpyId = primaryDMLCtpyId;
	}
	public String getCtpyEntityId() {
		return ctpyEntityId;
	}
	public void setCtpyEntityId(String ctpyEntityId) {
		this.ctpyEntityId = ctpyEntityId;
	}
	public String getCtpyDMLNM() {
		return ctpyDMLNM;
	}
	public void setCtpyDMLNM(String ctpyDMLNM) {
		this.ctpyDMLNM = ctpyDMLNM;
	}
	public String getSsgaCollCode() {
		return ssgaCollCode;
	}
	public void setSsgaCollCode(String ssgaCollCode) {
		this.ssgaCollCode = ssgaCollCode;
	}
	public String getSourceVehicleText() {
		return sourceVehicleText;
	}
	public void setSourceVehicleText(String sourceVehicleText) {
		this.sourceVehicleText = sourceVehicleText;
	}
	public String getSourceCtpytxt() {
		return sourceCtpytxt;
	}
	public void setSourceCtpytxt(String sourceCtpytxt) {
		this.sourceCtpytxt = sourceCtpytxt;
	}
	public String getInvVehInvestmentNM() {
		return invVehInvestmentNM;
	}
	public void setInvVehInvestmentNM(String invVehInvestmentNM) {
		this.invVehInvestmentNM = invVehInvestmentNM;
	}
	public String getInvVehicleId() {
		return invVehicleId;
	}
	public void setInvVehicleId(String invVehicleId) {
		this.invVehicleId = invVehicleId;
	}
	@Override
	public String toString()
	{
	    return "values are: "+sourceCode+triPartyAgentId+validFromDate+sourceInvvehicleId+collateralAcct+primaryDMLCtpyId+validToDate+ctpyId+ctpyEntityId+ctpyDMLNM+srcCollCode+activeFlag+lastModifiedId+lastModifiedDate+currentRecFlag+ssgaCollCode+sourceVehicleText+sourceCtpytxt+invVehInvestmentNM+rowId+userName+pageNo;
	}
    
}
