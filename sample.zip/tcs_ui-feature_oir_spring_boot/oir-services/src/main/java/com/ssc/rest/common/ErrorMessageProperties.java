package com.ssc.rest.common;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

@Component
public class ErrorMessageProperties
{
    
    private Map<String, String> map = new HashMap<String, String>();
    
    @PostConstruct
    private void populateData(){
	map.put("20403", "Triparty Agnt Id/Collateral Acct Id/Collateral Code Combination not found."); 
	map.put("-20403", "Triparty Agnt Id/Collateral Acct Id/Collateral Code Combination not found."); 
	
	map.put("20404", "Triparty Agnt Id/Collateral Acct Id/Collateral Code Combination is Inactive during this period."); 
	map.put("-20404", "Triparty Agnt Id/Collateral Acct Id/Collateral Code/Collateral Ccy Code Combination is Inactive during this period.");
	
	map.put("20405", "Triparty Agnt Id/Collateral Acct Id/Collateral Code Combination not found during this period.");
	map.put("-20405", "Triparty Agnt Id/Collateral Acct Id/Collateral Code Combination not found during this period.");
								
	map.put("20358", "House Id  not found.");
	map.put("-20358", "House Id  not found.");
	
	map.put("20352", "Ctpy Id not found.");
	map.put("-20352", "Ctpy Id not found.");				
	
	map.put("20354", "Ctpy Id not found during this period."); 
	map.put("-20354", "Ctpy Id not found during this period.");
	
	map.put("20353","Ctpy Id is Inactive during this period.");
	map.put("-20353","Ctpy Id is Inactive during this period.");
	
	map.put("20533","Duplicate information found:\n    DML Collateral Account Cross Reference with\n    this House Id and Primary DML Ctpy Id already\n    exists. ");
	
	map.put("20345","Valid From date cannot be greater than today.");
	map.put("-20345","Valid From date cannot be greater than today.");
	
	map.put("20417","As Of Date cannot be greater than today.");
	
	map.put("20342","Invalid Valid From Date not allowed.");
	map.put("-20342","Invalid Valid From Date not allowed.");
	
	map.put("22000","The same day change is not allowed, choose correction option.");
	map.put("-22000","The same day change is not allowed, choose correction option.");
				
	
	map.put("20303","Error occured while Inserting record. ");
	map.put("-20303","Error occured while Inserting record. ");
	map.put("success","Data Saved Successfully. ");
	map.put("NoChanges", "No changes to save");
	
	//added new entries for investment vehicle to collateral account cross reference on 25th-dec-2018
	
	map.put("20346","Duplicate information found:\n    Invest Vehicle to Collateral Account Cross Reference with\n    this Source, Source Coll Code, Source Invest Vehicle ID and Source Ctpy Id already\n    exists. ");
		
	map.put("20345","Valid From date cannot be greater than today.");
	map.put("-20345","Valid From date cannot be greater than today.");
	
	map.put("20342","Invalid Valid From Date not allowed.");
	map.put("-20342","Invalid Valid From Date not allowed.");
	
	map.put("20343","Invalid Effective Date. ");
	map.put("-20343","Invalid Effective Date.");
	
	map.put("20386","Investment Vehicle does not exist during this period");
	map.put("-20386","Investment Vehicle does not exist during this period");
	
	map.put("20414","Reinvestment Vehicle is inactive during this period");
	map.put("-20414","Reinvestment Vehicle is inactive during this period");
	
	map.put("20387","Investment Vehicle is inactive during this period");
	map.put("-20387","Investment Vehicle is inactive during this period");
	
	map.put("20385","Investment Vehicle does not exist");
	map.put("-20385","Investment Vehicle does not exist");
	
	map.put("20388","Src Ctpy does not exist");
	map.put("-20388","Src Ctpy does not exist");
	
	map.put("20389","Src Ctpy does not exist during this period");
	map.put("-20389","Src Ctpy does not exist during this period");
	
	map.put("20390","Src Ctpy is inactive during this period");
	map.put("-20390","Src Ctpy is inactive during this period");
	
	map.put("20366","Triparty Collateral Account does not exist");
	map.put("-20366","Triparty Collateral Account does not exist");
	
	map.put("20367","Triparty Collateral Account does not exist during this period");
	map.put("-20367","Triparty Collateral Account does not exist during this period");
	
	map.put("20368","Triparty Collateral Account is inactive during this period.");
	map.put("-20368","Triparty Collateral Account is inactive during this period."); //20530
    }

    public String getErrorMessage(String errorCode){
	return map.get(errorCode);
    }
}
