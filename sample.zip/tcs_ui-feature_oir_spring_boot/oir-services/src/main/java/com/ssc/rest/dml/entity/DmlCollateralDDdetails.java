package com.ssc.rest.dml.entity;

import java.util.List;

public class DmlCollateralDDdetails {
	private List<Collateral> collCodeData;
	private List<Collateral> houseDetailsData;
	private List<Collateral> tripartyData;
	private List<Collateral> ctpyData;

	public List<Collateral> getCollCodeData() {
		return collCodeData;
	}

	public void setCollCodeData(List<Collateral> collCodeData) {
		this.collCodeData = collCodeData;
	}

	public List<Collateral> getHouseDetailsData() {
		return houseDetailsData;
	}

	public void setHouseDetailsData(List<Collateral> houseDetailsData) {
		this.houseDetailsData = houseDetailsData;
	}

	public List<Collateral> getTripartyData() {
		return tripartyData;
	}

	public void setTripartyData(List<Collateral> tripartyData) {
		this.tripartyData = tripartyData;
	}

	public List<Collateral> getCtpyData() {
		return ctpyData;
	}

	public void setCtpyData(List<Collateral> ctpyData) {
		this.ctpyData = ctpyData;
	}
}
