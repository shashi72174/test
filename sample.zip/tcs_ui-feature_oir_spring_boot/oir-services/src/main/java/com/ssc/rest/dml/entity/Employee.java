package com.ssc.rest.dml.entity;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ssc.rest.common.JsonDateSerializer;
import com.ssc.rest.common.JsonDateTimeSerializer;

public class Employee implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6245737084644764316L;
	private String id;
	private String name;
	private String department;
	private Date onBoarding;
	private Date createTime;
	
	
	
	
	
	@JsonSerialize(using=JsonDateTimeSerializer.class)
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	@JsonSerialize(using=JsonDateSerializer.class)
	public Date getOnBoarding() {
		return onBoarding;
	}
	public void setOnBoarding(Date onBoarding) {
		this.onBoarding = onBoarding;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", department=" + department + ", onBoarding=" + onBoarding
				+ ", createTime=" + createTime + "]";
	}
 
	
	
}
