package com.ssc.rest.dml.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ssc.rest.dml.dao.CollateralDao;
import com.ssc.rest.dml.entity.AccountCrossRefDetails;
import com.ssc.rest.dml.entity.AccountCrossRefVO;
import com.ssc.rest.dml.entity.CollatAccDetails;

@Component
public class CollateralServiceImpl implements CollateralService {

	private static final Logger log = Logger.getLogger(CollateralServiceImpl.class);
	
	@Autowired
	CollateralDao collateralDao;

	public void setCollateralDao(CollateralDao collateralDao) {
		this.collateralDao = collateralDao;
	}

	

	public AccountCrossRefDetails getAccountCrossRefDetails(AccountCrossRefVO vo) throws Exception {
		AccountCrossRefDetails obj = collateralDao.getAllDMLCollateralAcctXRef(vo);
		return obj;
	}

	public AccountCrossRefDetails saveCrossRefDetails(AccountCrossRefVO vo) {

		AccountCrossRefDetails obj = collateralDao.saveCrossRefDetails(vo);
		return obj;
	}

	/*public DmlCollateralDDdetails getCollDDData() {

		return collateralDao.getDmlCollatDDList();
	}*/

	public List<CollatAccDetails> getCollatAccList(AccountCrossRefVO vo) {
		return collateralDao.getCollatAccList(vo);
	}

	public AccountCrossRefVO getCollateralAcctXRefDetails(AccountCrossRefVO vo) {
		return collateralDao.getCollateralAcctXRefDetails(vo);
	}

}
