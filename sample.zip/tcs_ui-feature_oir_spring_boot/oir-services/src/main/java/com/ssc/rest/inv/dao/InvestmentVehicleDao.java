package com.ssc.rest.inv.dao;

import java.util.List;

import com.ssc.rest.inv.entity.InvestVehicleRefVO;
import com.ssc.rest.inv.entity.InvestmentVehicleDD_Data;
import com.ssc.rest.inv.entity.InvestmentvehicleList;
import com.ssc.rest.inv.entity.InvestmentvehiclerefDetails;

public interface InvestmentVehicleDao {

	public List<InvestmentvehicleList> getCollCodeList(InvestVehicleRefVO objInvestVehicleRefVO);

	public InvestmentvehiclerefDetails getInvestmentVehiceFilterDetails(InvestVehicleRefVO vo) throws Exception;
	
    public InvestVehicleRefVO getInvVehicleRowDetails(InvestVehicleRefVO vo);

	public InvestmentvehiclerefDetails saveInvVehicleDetails(InvestVehicleRefVO vo);

	public InvestmentVehicleDD_Data getInvVehAllDDList();
	
	public final String SOURCE_LIST_QUERY="select codevalue,codelongdescription from SLID.REFCODE_SOURCETRIPARTY_V";
		
	public final String TRIPARTY_LIST_QUERY="select codevalue,codelongdescription from SLID.REFCODE_TPAGENTID_V";
	
	public final String INVVEHICLE_LIST_QUERY="select codevalue,codelongdescription from SLID.REFCODE_A_ALL_INVEST_VEHICLE_V";
	
	public final String SRCCOLLCODE_LIST_QUERY="select codevalue,codelongdescription from SLID.REFCODE_ACTV_SRCCOLL_CODE_V";
	
	public final String ICOLLCODE_LIST_QUERY="select t.coll_acct_id,t.coll_acct_nm from oir.triparty_coll_acct t where t.curr_rec_flg = ? and t.source_sq=? order by t.coll_acct_id";
	
	public final String INVVEH_ROWREF_QUERY = "SELECT * FROM (SELECT UPPER(invColl.p_activeInactive), invColl.p_investVehicleID, invColl.p_triPartyAgentId, invColl.p_validFrom, invColl.p_ssgaCollCode, invColl.p_source, invColl.p_validTo, invColl.p_sourcectpycd, UPPER(invColl.userID), invColl.lastModified, invColl.p_collateralAccount, invColl.p_ctpyEntityId, UPPER(invColl.p_dmlctpynm), invColl.p_dmlctpyid, UPPER(invColl.p_investVehicleNm), invColl.p_currRec, invColl.rowIden, ROWNUM AS rn FROM (SELECT UPPER(riv.ACTIVE_FLG) AS p_activeInactive, riv.SOURCE_VEHICLE_TXT AS p_investVehicleID, SM.source_sq AS p_triPartyAgentId, TO_CHAR(riv.VALID_FROM_DT, 'mm/dd/yyyy') AS p_validFrom, riv.SOURCE_COLL_CD AS p_ssgaCollCode, v.codevalue AS p_source, TO_CHAR(riv.VALID_TO_DT, 'mm/dd/yyyy') AS p_validTo, riv.SOURCE_CTPY_TXT AS p_sourcectpycd, UPPER(riv.LAST_MOD_SIGNON_ID) AS userID, riv.LAST_MOD_DATE_TIME AS lastModified, riv.coll_acct_id AS p_collateralAccount, ctpdet.ctpy_entity_id AS p_ctpyEntityId, UPPER(ctpdet.CTPY_DML_NM) AS p_dmlctpynm, ctpdet.ctpy_id AS p_dmlctpyid, UPPER(refinvdet.INVEST_VEHICLE_INTERNAL_NM) AS p_investVehicleNm, riv.curr_rec_flg AS p_currRec, riv.ROWID AS rowIden, ROWNUM AS rn FROM OIR.REPO_COLL_ACCT_XREF riv LEFT OUTER JOIN (SELECT ctpdet.ctpy_entity_id, ctpdet.ctpy_short_nm, ctxref.ctpy_id, ctxref.source_sq, ctpdet.CTPY_DML_NM, ctxref.source_ctpy_cd, ctxref.valid_from_dt ctxref_valid_from_dt, ctxref.valid_to_dt ctxref_valid_to_dt, ctpdet.valid_from_dt ctpdet_valid_from_dt, ctpdet.valid_to_dt ctpdet_valid_to_dt FROM OIR.ctpy_xref ctxref, OIR.ctpy_det ctpdet WHERE ctxref.ctpy_id = ctpdet.ctpy_id) ctpdet ON (ctpdet.source_sq = riv.source_sq AND ctpdet.source_ctpy_cd = riv.source_ctpy_txt AND SLID.fn_derived_dt(riv.valid_to_dt) BETWEEN ctxref_valid_from_dt AND ctxref_valid_to_dt AND SLID.fn_derived_dt(riv.valid_to_dt) BETWEEN ctpdet_valid_from_dt AND ctpdet_valid_to_dt) LEFT OUTER JOIN OIR.ref_invest_vehicle_det refinvdet ON (refinvdet.invest_vehicle_id = riv.source_vehicle_txt AND SLID.fn_derived_dt(riv.valid_to_dt) BETWEEN refinvdet.valid_from_dt AND refinvdet.valid_to_dt), OIR.SOURCE_MAP SM, SLID.REFCODE_SOURCETRIPARTY_V v WHERE RIV.TRIPARTY_AGENT_ID = SM.TRIPARTY_AGENT_ID AND riv.SOURCE_SQ = v.codevalue and sm.triparty_agent_id=?) invColl WHERE  invColl.p_activeInactive = ? and invColl.rowiden = ? and invColl.p_investVehicleID = ? and invColl.p_ssgaCollCode = ? and invColl.p_sourcectpycd = ? and invColl.p_collateralAccount = ?)";

}
