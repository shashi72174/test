package com.ssc.rest.dml.entity;

import java.io.Serializable;

public class AccountCrossRefVO implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String colTypeCode;    
    private String collateralCode;    
    private String houseAcctId;    
    private String counterPartyId;    
    private String triPartyAgentId;    
    private String collateralAcct;    
    private String validFromDate;    
    private String validToDate;    
    private String activeFlag;    
    private String lastModifiedId;    
    private String lastModifiedDate;   
    private String currentRecFlag;
    private String rowId;
    private String userName;
    private int pageNo;
    private String paginationType;
    private String searchTypeFlag;
    private String isDateUpdated;
    private String iModValue;
    
    public String getIsDateUpdated()
    {
        return isDateUpdated;
    }
    public void setIsDateUpdated(String isDateUpdated)
    {
        this.isDateUpdated = isDateUpdated;
    }
    public int getPageNo()
    {
        return pageNo;
    }
    public void setPageNo(int pageNo)
    {
        this.pageNo = pageNo;
    }
    public String getPaginationType()
    {
        return paginationType;
    }
    public void setPaginationType(String paginationType)
    {
        this.paginationType = paginationType;
    }
    public String getColTypeCode()
    {
        return colTypeCode;
    }
    public void setColTypeCode(String colTypeCode)
    {
        this.colTypeCode = colTypeCode;
    }
    public String getCollateralCode()
    {
        return collateralCode;
    }
    public void setCollateralCode(String collateralCode)
    {
        this.collateralCode = collateralCode;
    }
    public String getHouseAcctId()
    {
        return houseAcctId;
    }
    public void setHouseAcctId(String houseAcctId)
    {
        this.houseAcctId = houseAcctId;
    }
    public String getCounterPartyId()
    {
        return counterPartyId;
    }
    public void setCounterPartyId(String counterPartyId)
    {
        this.counterPartyId = counterPartyId;
    }
    public String getTriPartyAgentId()
    {
        return triPartyAgentId;
    }
    public void setTriPartyAgentId(String triPartyAgentId)
    {
        this.triPartyAgentId = triPartyAgentId;
    }
    public String getCollateralAcct()
    {
        return collateralAcct;
    }
    public void setCollateralAcct(String collateralAcct)
    {
        this.collateralAcct = collateralAcct;
    }
    public String getValidFromDate()
    {
        return validFromDate;
    }
    public void setValidFromDate(String validFromDate)
    {
        this.validFromDate = validFromDate;
    }
    public String getValidToDate()
    {
        return validToDate;
    }
    public void setValidToDate(String validToDate)
    {
        this.validToDate = validToDate;
    }
    public String getActiveFlag()
    {
        return activeFlag;
    }
    public void setActiveFlag(String activeFlag)
    {
        this.activeFlag = activeFlag;
    }
    public String getLastModifiedId()
    {
        return lastModifiedId;
    }
    public void setLastModifiedId(String lastModifiedId)
    {
        this.lastModifiedId = lastModifiedId;
    }
    public String getLastModifiedDate()
    {
        return lastModifiedDate;
    }
    public void setLastModifiedDate(String lastModifiedDate)
    {
        this.lastModifiedDate = lastModifiedDate;
    }
    public String getCurrentRecFlag()
    {
        return currentRecFlag;
    }
    public void setCurrentRecFlag(String currentRecFlag)
    {
        this.currentRecFlag = currentRecFlag;
    }
    public String getRowId()
    {
        return rowId;
    }
    public void setRowId(String rowId)
    {
        this.rowId = rowId;
    }
    
    public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getSearchTypeFlag() {
		return searchTypeFlag;
	}
	public void setSearchTypeFlag(String searchTypeFlag) {
		this.searchTypeFlag = searchTypeFlag;
	}
	
	public String getiModValue() {
		return iModValue;
	}
	public void setiModValue(String iModValue) {
		this.iModValue = iModValue;
	}
	@Override
    public String toString()
    {
	return "AccountCrossRefVO [colTypeCode=" + colTypeCode + ", collateralCode=" + collateralCode + ", houseAcctId="
		+ houseAcctId + ", counterPartyId=" + counterPartyId + ", triPartyAgentId=" + triPartyAgentId + ", collateralAcct="
		+ collateralAcct + ", validFromDate=" + validFromDate + ", validToDate=" + validToDate + ", activeFlag="
		+ activeFlag + ", lastModifiedId=" + lastModifiedId + ", lastModifiedDate=" + lastModifiedDate + ", currentRecFlag="
		+ currentRecFlag + ", rowId=" + rowId + ", searchTypeFlag='+searchTypeFlag+']";
    }
    

    
     
   

}
