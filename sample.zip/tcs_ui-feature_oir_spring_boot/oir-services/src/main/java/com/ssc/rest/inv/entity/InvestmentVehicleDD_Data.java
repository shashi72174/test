package com.ssc.rest.inv.entity;

import java.util.List;

public class InvestmentVehicleDD_Data {
	private List<InvestmentvehicleList> sourceList;
	private List<InvestmentvehicleList> TripartyList;
	private List<InvestmentvehicleList> invVehicleList;
	private List<InvestmentvehicleList> srcCollCode;


	public List<InvestmentvehicleList> getSourceList() {
		return sourceList;
	}

	public void setSourceList(List<InvestmentvehicleList> sourceList) {
		this.sourceList = sourceList;
	}

	public List<InvestmentvehicleList> getTripartyList() {
		return TripartyList;
	}

	public void setTripartyList(List<InvestmentvehicleList> tripartyList) {
		TripartyList = tripartyList;
	}

	public List<InvestmentvehicleList> getInvVehicleList() {
		return invVehicleList;
	}

	public void setInvVehicleList(List<InvestmentvehicleList> invVehicleList) {
		this.invVehicleList = invVehicleList;
	}
	
	public List<InvestmentvehicleList> getSrcCollCode() {
		return srcCollCode;
	}

	public void setSrcCollCode(List<InvestmentvehicleList> srcCollCode) {
		this.srcCollCode = srcCollCode;
	}

	@Override
	public String toString()
	{
		return "source"+sourceList+"trpartyList"+TripartyList+"invvehi"+invVehicleList;
	}
}
