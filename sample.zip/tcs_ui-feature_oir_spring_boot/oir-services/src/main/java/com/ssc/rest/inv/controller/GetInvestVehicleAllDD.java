package com.ssc.rest.inv.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssc.rest.common.RequestAction;
import com.ssc.rest.inv.entity.InvestmentVehicleDD_Data;
import com.ssc.rest.inv.entity.InvestmentvehicleList;
import com.ssc.rest.inv.service.InvestmentvehicleService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(value = "/getInvVehicleAllDD", tags = "getInvVehicleAllDD Dropdown Api")
@RequestMapping(value = "/api/getInvVehicleAllDD")
public class GetInvestVehicleAllDD {
	
	@Autowired
	InvestmentvehicleService investmentvehicleService;

	/**
	 * http://localhost:8080/cloudservices/api/populateSourceList/list Used to
	 * fetch populateSourceList details
	 * 
	 * Content-Type: application/json request body object is mandatory {} return
	 * list as response
	 * 
	 * @param bo
	 * @return
	 */
	@RequestMapping(value = RequestAction.LIST, method = RequestMethod.POST)
	@ApiOperation(value = "getInvVehicleAllDDList", notes = "get getInvVehicleAllDDList dropdown list", httpMethod = "POST", response = InvestmentvehicleList.class, responseContainer = "List")
	public InvestmentVehicleDD_Data getSourceDDList() {

		return investmentvehicleService.getInvVehAllDDList();
		

	}

}
