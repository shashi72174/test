package com.ssc.rest.inv.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.ssc.rest.common.ErrorMessageProperties;
import com.ssc.rest.common.RequestAction;
import com.ssc.rest.config.AppConfig;
import com.ssc.rest.inv.entity.InvestVehicleRefVO;
import com.ssc.rest.inv.entity.InvestmentVehicleDD_Data;
import com.ssc.rest.inv.entity.InvestmentvehicleList;
import com.ssc.rest.inv.entity.InvestmentvehiclerefDetails;

@Component
public class InvestmentvehicleDaoImpl implements InvestmentVehicleDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	ErrorMessageProperties props;
	
	@Autowired
	AppConfig appConfig;
	
	String searchSql = "select * from (SELECT UPPER(invColl.p_activeInactive), invColl.p_investVehicleID,invColl.p_triPartyAgentId,invColl.p_validFrom ,invColl.p_ssgaCollCode,invColl.p_source, invColl.p_validTo,invColl.p_sourcectpycd,UPPER(invColl.userID),invColl.lastModified, invColl.p_collateralAccount,invColl.p_ctpyEntityId,UPPER(invColl.p_dmlctpynm),invColl.p_dmlctpyid, UPPER(invColl.p_investVehicleNm),invColl.p_currRec,invColl.rowIden,rownum as rn  FROM (SELECT UPPER(riv.ACTIVE_FLG) as p_activeInactive, riv.SOURCE_VEHICLE_TXT AS p_investVehicleID,SM.triparty_agent_id as p_triPartyAgentId,to_char(riv.VALID_FROM_DT,'mm/dd/yyyy') as p_validFrom ,riv.SOURCE_COLL_CD as p_ssgaCollCode,v.codelongdescription as p_source, to_char(riv.VALID_TO_DT,'mm/dd/yyyy') as p_validTo,riv.SOURCE_CTPY_TXT as p_sourcectpycd,UPPER(riv.LAST_MOD_SIGNON_ID) as userID,riv.LAST_MOD_DATE_TIME as lastModified, riv.coll_acct_id as p_collateralAccount,ctpdet.ctpy_entity_id as p_ctpyEntityId,UPPER(ctpdet.CTPY_DML_NM) as p_dmlctpynm,ctpdet.ctpy_id as p_dmlctpyid, UPPER(refinvdet.INVEST_VEHICLE_INTERNAL_NM) AS p_investVehicleNm,riv.curr_rec_flg as p_currRec,riv.rowid as rowIden,rownum as rn FROM OIR.REPO_COLL_ACCT_XREF riv LEFT OUTER JOIN ( SELECT ctpdet.ctpy_entity_id, ctpdet.ctpy_short_nm,ctxref.ctpy_id, ctxref.source_sq,ctpdet.CTPY_DML_NM, ctxref.source_ctpy_cd, ctxref.valid_from_dt ctxref_valid_from_dt, ctxref.valid_to_dt ctxref_valid_to_dt, ctpdet.valid_from_dt ctpdet_valid_from_dt, ctpdet.valid_to_dt ctpdet_valid_to_dt FROM OIR.ctpy_xref ctxref, OIR.ctpy_det ctpdet WHERE ctxref.ctpy_id = ctpdet.ctpy_id ) ctpdet ON ( ctpdet.source_sq = riv.source_sq AND ctpdet.source_ctpy_cd = riv.source_ctpy_txt AND SLID.fn_derived_dt (riv.valid_to_dt) BETWEEN ctxref_valid_from_dt AND ctxref_valid_to_dt AND SLID.fn_derived_dt (riv.valid_to_dt) BETWEEN ctpdet_valid_from_dt AND ctpdet_valid_to_dt ) LEFT OUTER JOIN OIR.ref_invest_vehicle_det refinvdet ON ( refinvdet.invest_vehicle_id=riv.source_vehicle_txt AND SLID.fn_derived_dt (riv.valid_to_dt) BETWEEN refinvdet.valid_from_dt AND refinvdet.valid_to_dt ), OIR.SOURCE_MAP SM,SLID.REFCODE_SOURCETRIPARTY_V v where RIV.TRIPARTY_AGENT_ID=SM.TRIPARTY_AGENT_ID and riv.SOURCE_SQ=v.codevalue ";
	private static final Logger log = Logger.getLogger(InvestmentvehicleDaoImpl.class);
	
	/*
	 private int appConfig.getPageSize();

	public int getappConfig.getPageSize()() {
		return appConfig.getPageSize();
	}

	public void setappConfig.getPageSize()(int appConfig.getPageSize()) {
		this.appConfig.getPageSize() = appConfig.getPageSize();
	}

	public void setDataSource(DataSource dataSource) {
		log.info("datasoure" + dataSource);
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	*/
	/**
	 * To populate Source Dropdown list
	 */

	public List<InvestmentvehicleList> getSourceDDList() {
		try {
			return this.jdbcTemplate.query(SOURCE_LIST_QUERY,
					new PopulateSourceMapper());
		} catch (Exception e) {
			log.error("exception occurred ",e);
			throw e;
		}
	}

	public static final class PopulateSourceMapper implements RowMapper<InvestmentvehicleList> {

		public InvestmentvehicleList mapRow(ResultSet rs, int rowNum) throws SQLException {
			InvestmentvehicleList obj = new InvestmentvehicleList();

			obj.setValue(rs.getString("codevalue"));
			obj.setLabel(rs.getString("codelongdescription"));
			return obj;
		}
	}

	/**
	 * To populate triparty details dropdown list
	 */
	public List<InvestmentvehicleList> getTripartyDetailsList() {
		try {
			return this.jdbcTemplate.query(TRIPARTY_LIST_QUERY,
					new PopulateTriPartyMapper());
		} catch (Exception e) {
			log.error("exception occurred ",e);
			throw e;
		}
	}

	private static final class PopulateTriPartyMapper implements RowMapper<InvestmentvehicleList> {

		public InvestmentvehicleList mapRow(ResultSet rs, int rowNum) throws SQLException {
			InvestmentvehicleList obj = new InvestmentvehicleList();
			obj.setValue(rs.getString("codevalue"));
			obj.setLabel(rs.getString("codelongdescription"));
			return obj;
		}
	}

	/**
	 * To populate Investment vehile dopdown list
	 */
	public List<InvestmentvehicleList> getInvVehicleList() {
		try {
			return this.jdbcTemplate.query(
					INVVEHICLE_LIST_QUERY,
					new PopulateInvVehicleMapper());
		} catch (Exception e) {
			log.error("exception occurred ",e);
			throw e;
		}
	}

	private static final class PopulateInvVehicleMapper implements RowMapper<InvestmentvehicleList> {

		public InvestmentvehicleList mapRow(ResultSet rs, int rowNum) throws SQLException {
			InvestmentvehicleList obj = new InvestmentvehicleList();

			obj.setValue(rs.getString("codevalue"));
			obj.setLabel(rs.getString("codevalue") + "-" + rs.getString("codelongdescription"));
			return obj;
		}
	}

	/**
	 * To populate getSourcecollCodeList
	 */
	public List<InvestmentvehicleList> getSourcecollCodeList() {
		try {
			return this.jdbcTemplate.query(SRCCOLLCODE_LIST_QUERY,
					new PopulateCollCodeMapper());
		} catch (Exception e) {
			log.error("exception occurred ",e);
			throw e;
		}
	}

	private static final class PopulateCollCodeMapper implements RowMapper<InvestmentvehicleList> {

		public InvestmentvehicleList mapRow(ResultSet rs, int rowNum) throws SQLException {
			InvestmentvehicleList obj = new InvestmentvehicleList();
			obj.setValue(rs.getString("codevalue"));
			obj.setLabel(rs.getString("codevalue") + "-" + rs.getString("codelongdescription"));
			return obj;
		}
	}

	/**
	 * To populate collateralAccountcode Dropdown data
	 */
	@Override
	public List<InvestmentvehicleList> getCollCodeList(InvestVehicleRefVO objInvestVehicleRefVO) {
		List<InvestmentvehicleList> collAccList = new ArrayList<InvestmentvehicleList>();
		if(Integer.parseInt(objInvestVehicleRefVO.getTriPartyAgentId())!=0) {
			try{
				collAccList = this.jdbcTemplate
					.query(ICOLLCODE_LIST_QUERY, new Object[] {"Y",objInvestVehicleRefVO.getTriPartyAgentId()}, new PopulatecollAccCodeMapper());
			}catch(Exception e){
				log.error("exception occurred ",e);
				throw e;
			}
		}
		return collAccList;
	}

	private static final class PopulatecollAccCodeMapper implements RowMapper<InvestmentvehicleList> {

		public InvestmentvehicleList mapRow(ResultSet rs, int rowNum) throws SQLException {
			InvestmentvehicleList obj = new InvestmentvehicleList();
			obj.setLabel(rs.getString(1) + " " + rs.getString(2));
			obj.setValue(rs.getString(1) + "-" + rs.getString(2));
			return obj;
		}
	}

	/**
	 * To fetch data on refresh
	 * 
	 * @throws Exception
	 */
	@Override
	public InvestmentvehiclerefDetails getInvestmentVehiceFilterDetails(InvestVehicleRefVO vo) throws Exception {
		
		List<InvestVehicleRefVO> list = new ArrayList<InvestVehicleRefVO>();
		InvestmentvehiclerefDetails obj = new InvestmentvehiclerefDetails();
		Date CurrentDate=new Date();
		SqlOutParameter tSize = new SqlOutParameter("tSize", java.sql.Types.NUMERIC);
		SqlOutParameter errCode = new SqlOutParameter("errCode", java.sql.Types.NUMERIC);
		SqlOutParameter errMsg = new SqlOutParameter("errMsg", java.sql.Types.VARCHAR);
		SqlOutParameter errType = new SqlOutParameter("errType", java.sql.Types.VARCHAR);
		SqlOutParameter curDerivedVol = new SqlOutParameter("curDerivedVol", oracle.jdbc.OracleTypes.CURSOR);
		
		List<SqlParameter> sqlParamList = new ArrayList<SqlParameter>();
		sqlParamList.add(new SqlParameter(java.sql.Types.VARCHAR));//1
		sqlParamList.add(new SqlParameter(java.sql.Types.VARCHAR));//2
		sqlParamList.add(new SqlParameter(java.sql.Types.VARCHAR));//3
		sqlParamList.add(new SqlParameter(java.sql.Types.VARCHAR));//4
		sqlParamList.add(new SqlParameter(java.sql.Types.DATE));//5
		sqlParamList.add(new SqlParameter(java.sql.Types.VARCHAR));//6
		sqlParamList.add(new SqlParameter(java.sql.Types.DATE));//7
		sqlParamList.add(new SqlParameter(java.sql.Types.VARCHAR));//8
		sqlParamList.add(new SqlParameter(java.sql.Types.VARCHAR));//9
		sqlParamList.add(new SqlParameter(java.sql.Types.VARCHAR));//10
		sqlParamList.add(new SqlParameter(java.sql.Types.INTEGER));//11
		sqlParamList.add(new SqlParameter(java.sql.Types.VARCHAR));//12
		sqlParamList.add(new SqlParameter(java.sql.Types.INTEGER));//13
		sqlParamList.add(new SqlParameter(java.sql.Types.INTEGER));//14
		sqlParamList.add(tSize);//15
		sqlParamList.add(errCode);//16
		sqlParamList.add(errMsg);//17
		sqlParamList.add(errType);//18
		sqlParamList.add(curDerivedVol);//19
		
		Map<String,Object> resultMap = jdbcTemplate.call(new CallableStatementCreator(){

			@Override
			public CallableStatement createCallableStatement(Connection con) throws SQLException {
				// TODO Auto-generated method stub
				CallableStatement cstmt = con.prepareCall("{call SLID.PKG_OIR_COLLATERAL.SP_OIR_InvestAccCollAccXref(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
				if (!StringUtils.isEmpty(vo.getSourceInvvehicleId()) && !vo.getSourceInvvehicleId().equals("0"))
					cstmt.setString(1, vo.getSourceInvvehicleId());
				else
					cstmt.setNull(1, java.sql.Types.VARCHAR);
				
				if(!StringUtils.isEmpty(vo.getTriPartyAgentId()) && !vo.getTriPartyAgentId().equals("0")) 
					cstmt.setString(2, vo.getTriPartyAgentId());
				else
					cstmt.setNull(2, java.sql.Types.VARCHAR);
				
				if(!StringUtils.isEmpty(vo.getCtpyEntityId())) 
					cstmt.setString(3, vo.getCtpyEntityId());
				else
					cstmt.setNull(3, java.sql.Types.VARCHAR);
				
				if (!StringUtils.isEmpty(vo.getSourceCode()) && !vo.getSourceCode().equals("0"))
					cstmt.setString(4, vo.getSourceCode());
				else
					cstmt.setNull(4, java.sql.Types.VARCHAR);
				if(null!=vo.getSearchTypeFlag() && vo.getSearchTypeFlag().equalsIgnoreCase("1")){			
					DateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY");
					cstmt.setDate(5, new java.sql.Date(new Date(dateFormat.format(CurrentDate)).getTime()));
					cstmt.setDate(7, new java.sql.Date(new Date("01/31/2500").getTime()));
					//System.out.println("param 5"+new java.sql.Date(new Date(dateFormat.format(CurrentDate)).getTime()));
					//System.out.println("param 7 is"+new java.sql.Date(new Date("01/31/2500").getTime()));
				}else{
				if(!StringUtils.isEmpty(vo.getValidFromDate()))
					cstmt.setDate(5, new java.sql.Date(new Date(vo.getValidFromDate()).getTime()));
				else
					cstmt.setNull(5, java.sql.Types.DATE);
				
				if(!StringUtils.isEmpty(vo.getValidToDate())) 
					cstmt.setDate(7, new java.sql.Date(new Date(vo.getValidToDate()).getTime()));
				else
					cstmt.setNull(7, java.sql.Types.DATE);
	
				}
				if (!StringUtils.isEmpty(vo.getSrcCollCode()) && !vo.getSrcCollCode().equals("0")) 
					cstmt.setString(6, vo.getSrcCollCode());
				else
					cstmt.setNull(6, java.sql.Types.VARCHAR);
				
				if(!StringUtils.isEmpty(vo.getCurrentRecFlag()) ) 
					cstmt.setString(8, vo.getCurrentRecFlag());
				else
					cstmt.setNull(8, java.sql.Types.VARCHAR);
				
				if(!StringUtils.isEmpty(vo.getActiveFlag()) &&  !vo.getActiveFlag().equals("0") ) 
					cstmt.setString(9, vo.getActiveFlag());
				else
					cstmt.setNull(9, java.sql.Types.VARCHAR);
				if (!StringUtils.isEmpty(vo.getCollateralAcct()))
					cstmt.setString(10, vo.getCollateralAcct());
				else
					cstmt.setNull(10, java.sql.Types.VARCHAR);
				
				cstmt.setNull(11, java.sql.Types.INTEGER);
				cstmt.setNull(12, java.sql.Types.VARCHAR);
				cstmt.setInt(13, ((vo.getPageNo()-1)*appConfig.getPageSize())+1);
				cstmt.setInt(14, vo.getPageNo()*appConfig.getPageSize());
				cstmt.registerOutParameter(15, java.sql.Types.NUMERIC);
				cstmt.registerOutParameter(16, java.sql.Types.NUMERIC);
				cstmt.registerOutParameter(17, java.sql.Types.VARCHAR);
				cstmt.registerOutParameter(18, java.sql.Types.VARCHAR);
				cstmt.registerOutParameter(19, oracle.jdbc.OracleTypes.CURSOR);
				return cstmt;
				
				
			}
			
		},  sqlParamList);
		DateFormat inFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		DateFormat outFormat = new SimpleDateFormat("MM/dd/yyyy");
		List resultList = ((ArrayList)resultMap.get("curDerivedVol"));
		for(int i=0;i<resultList.size();i++) {
			Map rowMap = (Map)resultList.get(i);
			//System.out.println(rowMap);
			InvestVehicleRefVO investVehicleRefVO = new InvestVehicleRefVO();
			investVehicleRefVO.setTriPartyAgentId(rowMap.get("P_TRIPARTYAGENTID").toString());
			investVehicleRefVO.setCollateralAcct((String)rowMap.get("P_COLLATERALACCOUNT"));
			investVehicleRefVO.setCtpyEntityId((String)rowMap.get("P_CTPYENTITYID"));
			investVehicleRefVO.setCtpyDMLNM(rowMap.get("UPPER(INVCOLL.P_DMLCTPYNM)")!= null ? rowMap.get("UPPER(INVCOLL.P_DMLCTPYNM)").toString() : null);
			investVehicleRefVO.setCtpyId((String)rowMap.get("P_DMLCTPYID"));
			investVehicleRefVO.setValidFromDate(outFormat.format(inFormat.parse(((Timestamp)rowMap.get("P_VALIDFROM")).toString())));
			investVehicleRefVO.setValidToDate(outFormat.format(inFormat.parse(((Timestamp)rowMap.get("P_VALIDTO")).toString())));
			investVehicleRefVO.setSourceVehicleText(rowMap.get("P_INVESTVEHICLEID").toString());
			investVehicleRefVO.setSsgaCollCode(rowMap.get("P_SSGACOLLCODE").toString());
			investVehicleRefVO.setSourceCode(rowMap.get("P_SOURCE").toString());
			investVehicleRefVO.setSourceCtpytxt(rowMap.get("P_SOURCECTPYCD").toString());
			investVehicleRefVO.setActiveFlag(rowMap.get("UPPER(INVCOLL.P_ACTIVEINACTIVE)").toString());
			investVehicleRefVO.setLastModifiedId(rowMap.get("UPPER(INVCOLL.USERID)").toString());
			investVehicleRefVO.setLastModifiedDate(outFormat.format(inFormat.parse(((Timestamp)rowMap.get("LASTMODIFIED")).toString())));
			investVehicleRefVO.setInvVehInvestmentNM(rowMap.get("UPPER(INVCOLL.P_INVESTVEHICLENM)") != null ? rowMap.get("UPPER(INVCOLL.P_INVESTVEHICLENM)").toString() : null);
			investVehicleRefVO.setCurrentRecFlag(rowMap.get("P_CURRREC").toString());
			investVehicleRefVO.setRowId(rowMap.get("ROWIDEN").toString());
			list.add(investVehicleRefVO);
		}
		obj.setTotalRecords(((BigDecimal)resultMap.get("tSize")).intValue());
		obj.setPageNumber(vo.getPageNo());
		obj.setPrePageNo(vo.getPageNo());
		obj.setNextPageNo(vo.getPageNo() + 1);
		if ((vo.getPaginationType().equals("pre") && vo.getPageNo() > 1)
				|| (list.size() < appConfig.getPageSize() && vo.getPaginationType().equals("next"))) {
			// System.out.println("=============prepppppp");
			obj.setPrePageNo(vo.getPageNo() - 1);
			obj.setNextPageNo(vo.getPageNo());
		}

		obj.setInvestmentVehicleList(list);
		
		obj.setRecordsPerPage(appConfig.getPageSize() * vo.getPageNo());
		obj.setIsNextDisable("N");
		if ((appConfig.getPageSize() * vo.getPageNo()) >= obj.getTotalRecords()) {
			obj.setIsNextDisable("Y");
			obj.setRecordsPerPage(obj.getTotalRecords());
		}
		
		/*String searchSql = "select * from (SELECT UPPER(invColl.p_activeInactive), invColl.p_investVehicleID,invColl.p_triPartyAgentId,invColl.p_validFrom ,invColl.p_ssgaCollCode,invColl.p_source, invColl.p_validTo,invColl.p_sourcectpycd,UPPER(invColl.userID),invColl.lastModified, invColl.p_collateralAccount,invColl.p_ctpyEntityId,UPPER(invColl.p_dmlctpynm),invColl.p_dmlctpyid, UPPER(invColl.p_investVehicleNm),invColl.p_currRec,invColl.rowIden,rownum as rn  FROM (SELECT UPPER(riv.ACTIVE_FLG) as p_activeInactive, riv.SOURCE_VEHICLE_TXT AS p_investVehicleID,SM.triparty_agent_id as p_triPartyAgentId,to_char(riv.VALID_FROM_DT,'mm/dd/yyyy') as p_validFrom ,riv.SOURCE_COLL_CD as p_ssgaCollCode,v.codelongdescription as p_source, to_char(riv.VALID_TO_DT,'mm/dd/yyyy') as p_validTo,riv.SOURCE_CTPY_TXT as p_sourcectpycd,UPPER(riv.LAST_MOD_SIGNON_ID) as userID,riv.LAST_MOD_DATE_TIME as lastModified, riv.coll_acct_id as p_collateralAccount,ctpdet.ctpy_entity_id as p_ctpyEntityId,UPPER(ctpdet.CTPY_DML_NM) as p_dmlctpynm,ctpdet.ctpy_id as p_dmlctpyid, UPPER(refinvdet.INVEST_VEHICLE_INTERNAL_NM) AS p_investVehicleNm,riv.curr_rec_flg as p_currRec,riv.rowid as rowIden,rownum as rn FROM OIR.REPO_COLL_ACCT_XREF riv LEFT OUTER JOIN ( SELECT ctpdet.ctpy_entity_id, ctpdet.ctpy_short_nm,ctxref.ctpy_id, ctxref.source_sq,ctpdet.CTPY_DML_NM, ctxref.source_ctpy_cd, ctxref.valid_from_dt ctxref_valid_from_dt, ctxref.valid_to_dt ctxref_valid_to_dt, ctpdet.valid_from_dt ctpdet_valid_from_dt, ctpdet.valid_to_dt ctpdet_valid_to_dt FROM OIR.ctpy_xref ctxref, OIR.ctpy_det ctpdet WHERE ctxref.ctpy_id = ctpdet.ctpy_id ) ctpdet ON ( ctpdet.source_sq = riv.source_sq AND ctpdet.source_ctpy_cd = riv.source_ctpy_txt AND SLID.fn_derived_dt (riv.valid_to_dt) BETWEEN ctxref_valid_from_dt AND ctxref_valid_to_dt AND SLID.fn_derived_dt (riv.valid_to_dt) BETWEEN ctpdet_valid_from_dt AND ctpdet_valid_to_dt ) LEFT OUTER JOIN OIR.ref_invest_vehicle_det refinvdet ON ( refinvdet.invest_vehicle_id=riv.source_vehicle_txt AND SLID.fn_derived_dt (riv.valid_to_dt) BETWEEN refinvdet.valid_from_dt AND refinvdet.valid_to_dt ), OIR.SOURCE_MAP SM,SLID.REFCODE_SOURCETRIPARTY_V v where RIV.TRIPARTY_AGENT_ID=SM.TRIPARTY_AGENT_ID and riv.SOURCE_SQ=v.codevalue";
		String endSql = "", countSql = "";
		InvestmentvehiclerefDetails obj = new InvestmentvehiclerefDetails();
		int limit = 0, offset = 0;
		List paramList = new ArrayList();
		try {
			log.info("recors per page is" + appConfig.getPageSize());
			// Set end sql
			limit = vo.getPageNo() * appConfig.getPageSize();
			offset = (vo.getPageNo() - 1) * appConfig.getPageSize();
			endSql = " and rownum<=?) invColl where rn>=?)";
			if (!StringUtils.isEmpty(vo.getSourceCode()) && !vo.getSourceCode().equals("0")) {
				searchSql = searchSql + " and v.codevalue = ?";
				paramList.add(vo.getSourceCode().toString());
			}
			if (!StringUtils.isEmpty(vo.getTriPartyAgentId()) && !vo.getTriPartyAgentId().equals("0")) {
				searchSql = searchSql + " and sm.source_sq = ?";
				paramList.add(vo.getTriPartyAgentId().toString());
			}
			if (!StringUtils.isEmpty(vo.getSourceInvvehicleId()) && !vo.getSourceInvvehicleId().equals("0")) {
				searchSql = searchSql + " and riv.SOURCE_VEHICLE_TXT = ?";
				paramList.add(vo.getSourceInvvehicleId());
			}
			if (!StringUtils.isEmpty(vo.getCollateralAcct())) {
				searchSql = searchSql + " and riv.coll_acct_id = ?";
				paramList.add(vo.getCollateralAcct());
			}
			if (!StringUtils.isEmpty(vo.getCtpyEntityId())) {
				searchSql = searchSql + " and ctpdet.ctpy_entity_id = ?";
				paramList.add(vo.getCtpyEntityId());
			}
			if (!StringUtils.isEmpty(vo.getSrcCollCode()) && !vo.getSrcCollCode().equals("0")) {
				searchSql = searchSql + " and riv.SOURCE_COLL_CD = ?";
				paramList.add(vo.getSrcCollCode());
			}
			if (!StringUtils.isEmpty(vo.getActiveFlag()) && vo.getActiveFlag().equalsIgnoreCase("N")) {
				searchSql = searchSql + " and riv.ACTIVE_FLG = ?";
				paramList.add("N");
			} else if (!StringUtils.isEmpty(vo.getActiveFlag()) && vo.getActiveFlag().equalsIgnoreCase("Y")) {
				searchSql = searchSql + " and riv.ACTIVE_FLG = ?";
				paramList.add("Y");
			}
			SimpleDateFormat inDateFormat = new SimpleDateFormat("MM/dd/yyyy");
			SimpleDateFormat outDateFormat = new SimpleDateFormat("dd-MMM-yyyy");

			if (!StringUtils.isEmpty(vo.getValidFromDate()) && !StringUtils.isEmpty(vo.getValidToDate())) {
				Date uiFromDate = inDateFormat.parse(vo.getValidFromDate().toString());
				Date uiToDate = inDateFormat.parse(vo.getValidToDate().toString());
				String sqlFromDate = outDateFormat.format(uiFromDate);
				String sqlToDate = outDateFormat.format(uiToDate);
				searchSql = searchSql + " and ((( '"+ sqlFromDate + "' BETWEEN riv.VALID_FROM_DT and '"+sqlToDate+"') AND ('"+sqlToDate+"' BETWEEN '"+sqlFromDate+"' and riv.VALID_TO_DT))" 
						+"or ((riv.VALID_FROM_DT BETWEEN '"+sqlFromDate+"' and '"+sqlToDate+"') AND (riv.VALID_TO_DT BETWEEN riv.VALID_FROM_DT and '"+sqlToDate+"'))" 
						+"or ((riv.VALID_FROM_DT BETWEEN '"+sqlFromDate+"' and '"+sqlToDate+"') AND ('"+sqlToDate+"' BETWEEN riv.VALID_FROM_DT and riv.VALID_TO_DT))	or (('"
						+sqlFromDate+"'BETWEEN riv.VALID_FROM_DT and riv.VALID_TO_DT) AND (riv.VALID_TO_DT BETWEEN '"+sqlFromDate+"' and '"+sqlToDate+"')))";

			}
			countSql = searchSql.replace("*", "COUNT(*) AS totalCount ") + " )invColl)";
			obj.setTotalRecords(getTotalCountOfAcctXref(countSql, paramList.toArray()));
			searchSql = searchSql + endSql;
			paramList.add(limit);
			paramList.add(offset);
			log.info("Search query is..." + searchSql);
			List<InvestVehicleRefVO> list = this.jdbcTemplate.query(searchSql, paramList.toArray(), new InvestmentVehicleRefListMapper());
			obj.setPageNumber(vo.getPageNo());
			obj.setPrePageNo(vo.getPageNo());
			obj.setNextPageNo(vo.getPageNo() + 1);
			if ((vo.getPaginationType().equals("pre") && vo.getPageNo() > 1)
					|| (list.size() < appConfig.getPageSize() && vo.getPaginationType().equals("next"))) {
				// System.out.println("=============prepppppp");
				obj.setPrePageNo(vo.getPageNo() - 1);
				obj.setNextPageNo(vo.getPageNo());
			}

			obj.setInvestmentVehicleList(list);
			
			obj.setRecordsPerPage(appConfig.getPageSize() * vo.getPageNo());
			obj.setIsNextDisable("N");
			if ((appConfig.getPageSize() * vo.getPageNo()) >= obj.getTotalRecords()) {
				obj.setIsNextDisable("Y");
				obj.setRecordsPerPage(obj.getTotalRecords());
			}
		} catch (Exception e) {
			log.error("exception occurred ",e);
			throw e;
		}
		log.info("Search obj is..." + obj.toString());*/

		return obj;
	}

	public int getTotalCountOfAcctXref(String query, Object[] params) {
		return jdbcTemplate.queryForObject(query, params, Integer.class);

	}

	private static final class InvestmentVehicleRefListMapper implements RowMapper<InvestVehicleRefVO> {

		public InvestVehicleRefVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			InvestVehicleRefVO obj = new InvestVehicleRefVO();
			obj.setTriPartyAgentId(rs.getString(3));
			obj.setCollateralAcct(rs.getString(11));
			obj.setCtpyEntityId(rs.getString(12));
			obj.setCtpyDMLNM(rs.getString(13));
			obj.setCtpyId(rs.getString(14));
			obj.setValidFromDate(rs.getString(4));
			obj.setValidToDate(rs.getString(7));
			obj.setSourceVehicleText(rs.getString(2));
			obj.setSsgaCollCode(rs.getString(5));
			obj.setSourceCode(rs.getString(6));
			obj.setSourceCtpytxt(rs.getString(8));
			obj.setActiveFlag(rs.getString(1));
			obj.setLastModifiedId(rs.getString(9));
			obj.setLastModifiedDate(rs.getString(10));
			obj.setInvVehInvestmentNM(rs.getString(15));
			obj.setCurrentRecFlag(rs.getString(16));
			obj.setRowId(rs.getString(17));
			return obj;
		}
	}

	/**
	 * To fetch data of row based on rowId
	 */

	@Override
	public InvestVehicleRefVO getInvVehicleRowDetails(InvestVehicleRefVO vo) {
		try {
			return jdbcTemplate.queryForObject(INVVEH_ROWREF_QUERY,
					new Object[] { vo.getTriPartyAgentId(), vo.getActiveFlag(), vo.getRowId(), vo.getInvVehicleId(),
							vo.getSsgaCollCode(), vo.getCtpyId(), vo.getCollateralAcct() },
					new InvVehicleRowRefDetailMapper());
		} catch (Exception e) {
			log.error("exception occurred ",e);
			throw e;
		}
	}

	private static final class InvVehicleRowRefDetailMapper implements RowMapper<InvestVehicleRefVO> {
		public InvestVehicleRefVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			InvestVehicleRefVO obj = new InvestVehicleRefVO();
			try {
				obj.setTriPartyAgentId(rs.getString(3));
				obj.setCollateralAcct(rs.getString(11));
				obj.setCtpyEntityId(rs.getString(12));
				obj.setCtpyDMLNM(rs.getString(13));
				obj.setCtpyId(rs.getString(14));
				obj.setValidFromDate(rs.getString(4));
				obj.setValidToDate(rs.getString(7));
				obj.setSsgaCollCode(rs.getString(5));
				obj.setSourceVehicleText(rs.getString(2));
				obj.setSourceCode(rs.getString(6));
				obj.setSourceCtpytxt(rs.getString(8));
				obj.setActiveFlag(rs.getString(1));
				obj.setInvVehInvestmentNM(rs.getString(15));
				obj.setLastModifiedId(rs.getString(9));
				obj.setLastModifiedDate(rs.getString(10));
				obj.setCurrentRecFlag(rs.getString(16));
				obj.setRowId(rs.getString(17));
				//log.info("getInvVehicleRowDetails obj" + obj.toString());
			} catch (Exception e) {
				log.error("exception occurred ",e);
			}
			return obj;
		}
	}

	/**
	 * To fetch data of row Input object InvestVehicleRefVO Response object
	 * InvestmentvehiclerefDetails
	 */

	@Override
	public InvestmentvehiclerefDetails saveInvVehicleDetails(InvestVehicleRefVO vo) {
		InvestmentvehiclerefDetails retObject = new InvestmentvehiclerefDetails();
		log.info("Inside save or update....");
		String errorDesc = "";
		Connection con = null;
		CallableStatement callableStatement = null;
		String userName = vo.getUserName();
		Date fromDate, toDate = null;
		try {
			if (vo.getActiveFlag().equalsIgnoreCase("Y-Active"))
				vo.setActiveFlag("Y");
			else if (vo.getActiveFlag().equalsIgnoreCase("N-inActive"))
				vo.setActiveFlag("N");

			fromDate = new Date(vo.getValidFromDate());
			toDate = new Date(vo.getValidToDate());
			
			con = jdbcTemplate.getDataSource().getConnection();
			callableStatement = con.prepareCall(
					"{call SLID.PKG_OIR_COLLATERAL_MAINTENANCE.SP_OIR_MaintInvCollAccXREF(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");

			callableStatement.setString(1, vo.getInvVehicleId());
			// System.out.println("Param 1 is vo.getInvVehicleId()" +vo.getInvVehicleId());
			callableStatement.setString(2, vo.getTriPartyAgentId());
			// System.out.println("Param 2 is vo.getTriPartyAgentId()" + vo.getTriPartyAgentId());
			callableStatement.setInt(3, new Integer(vo.getSourceCode()).intValue());
			// System.out.println("Param 3 is newInteger(vo.getSourceCode()).intValue()"+ new Integer(vo.getSourceCode()).intValue());
			callableStatement.setString(4, vo.getSourceCtpytxt());
			// System.out.println("Param 4 is vo.getCtpyId()" + vo.getCtpyId());
			callableStatement.setString(5, vo.getCollateralAcct());
			// System.out.println("Param 5 is vo.getCollateralAcct()" +vo.getCollateralAcct());
			callableStatement.setString(6, vo.getSrcCollCode());
			// System.out.println("Param 6 is vo.getSrcCollCode()" +vo.getSrcCollCode());

			callableStatement.setDate(7, new java.sql.Date(fromDate.getTime()));
			// System.out.println("Param 7 is java.sql.Date(fromDate.getTime())"+ new java.sql.Date(fromDate.getTime()));
			callableStatement.setDate(8, new java.sql.Date(toDate.getTime()));
			// System.out.println("Param 8 isnewjava.sql.Date(toDate.getTime())" + new java.sql.Date(toDate.getTime()));

			callableStatement.setString(9, vo.getActiveFlag());
			// System.out.println("Param 9 is vo.getActiveFlag()" +vo.getActiveFlag());
			java.util.Date today = new java.util.Date();
			callableStatement.setString(10, vo.getUserName());
			// System.out.println("Param 10 is vo.getUserName()" +vo.getUserName());
			callableStatement.setTimestamp(11, new Timestamp(today.getTime()));
			// System.out.println("Param 11 is new Timestamp(today.getTime())" +new Timestamp(today.getTime()));
			if (vo.getRowId() == null || "".equals(vo.getRowId())) {
				callableStatement.setString(12, "A");
				callableStatement.setString(14, "");
			} else {
				callableStatement.setString(12, vo.getiModValue());
				callableStatement.setString(14, vo.getRowId());
				// System.out.println("Param 14 is " + vo.getRowId());
			}
			// System.out.println("Param 12 is " + vo.getiModValue());
			callableStatement.setDate(13, new java.sql.Date(today.getTime()));
			// System.out.println("Param 13 is new
			// java.sql.Date(today.getTime()" + new
			// java.sql.Date(today.getTime()));

			callableStatement.registerOutParameter(15, java.sql.Types.NUMERIC);
			callableStatement.registerOutParameter(16, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(17, java.sql.Types.VARCHAR);

			callableStatement.executeUpdate();
			long errorCode = callableStatement.getLong(15);
			String errorMessage = callableStatement.getString(16);
			String errorType = callableStatement.getString(17);
			log.info("errorCode : " + errorCode);
			log.info("errorMessage : " + errorMessage);
			log.info("errorType : " + errorType);
			if (errorMessage != null) {
				retObject.setResponseType(RequestAction.RESPONSE_TYPE_FAILURE);
				List<String> errList = new ArrayList<String>();
				String[] splitErr = errorMessage.split("%");
				for (int i = 0; i < splitErr.length; i++) {
					if (splitErr[i].equals("") || splitErr[i]==null)
						continue;
					else if (props.getErrorMessage(splitErr[i]) != null)
						errList.add(props.getErrorMessage(splitErr[i]));
				}
				String [] errDesc = new String[errList.size()];
				for(int i=0;i<errList.size();i++) {
					errDesc[i] = errList.get(i);
				}
				retObject.setErrorDesc(errDesc);
			} else {
				InvestVehicleRefVO objInvestVehicleRefVO = new InvestVehicleRefVO();
				objInvestVehicleRefVO.setPageNo(1);
				objInvestVehicleRefVO.setPaginationType("next");
				objInvestVehicleRefVO.setSearchTypeFlag("1");
				retObject = getInvestmentVehiceFilterDetails(objInvestVehicleRefVO);
			}
		} catch (Exception e) {
			log.error("exception occurred ",e);
			errorDesc = "exception";
			retObject.setErrorDesc(new String[] { errorDesc });
		} finally {
			try {
				if (callableStatement != null)
					callableStatement.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				log.error("exception occurred ",e);
			}
		}
		return retObject;
	}

	/*private int checkdateto(SimpleDateFormat inDateFormat, String validToDate) {
		int valid = 0;
		try {
			inDateFormat.parse(validToDate.toString());
		} catch (Exception e) {
			valid = 1;
			log.error("exception occurred ",e);
		}
		return valid;
	}

	private int checkdateFrom(SimpleDateFormat inDateFormat, String validFromDate) {
		int valid = 0;
		try {
			inDateFormat.parse(validFromDate.toString());
		} catch (Exception e) {
			valid = 1;
			log.error("exception occurred ",e);
		}
		return valid;
	}*/

	@Override
	public InvestmentVehicleDD_Data getInvVehAllDDList() {

		InvestmentVehicleDD_Data objInvestmentVehicleDD_Data = new InvestmentVehicleDD_Data();
		InvestmentvehicleList objInvestmentvehicleList = new InvestmentvehicleList();
		try {
			objInvestmentvehicleList.setLabel("ALL");
			objInvestmentvehicleList.setValue("0");
			List<InvestmentvehicleList> sourceDD = getSourceDDList();
			List<InvestmentvehicleList> tripartyDD = getTripartyDetailsList();
			List<InvestmentvehicleList> invVehDD = getInvVehicleList();
			List<InvestmentvehicleList> srcCollDD = getSourcecollCodeList();
			sourceDD.add(objInvestmentvehicleList);
			tripartyDD.add(objInvestmentvehicleList);
			invVehDD.add(objInvestmentvehicleList);
			srcCollDD.add(objInvestmentvehicleList);
			objInvestmentVehicleDD_Data.setSourceList(sourceDD);
			objInvestmentVehicleDD_Data.setTripartyList(tripartyDD);
			objInvestmentVehicleDD_Data.setInvVehicleList(invVehDD);
			objInvestmentVehicleDD_Data.setSrcCollCode(srcCollDD);
			//log.info("GET ALL DD DATA IS :" + objInvestmentVehicleDD_Data.toString());
		} catch (Exception e) {
			log.error("exception occurred ",e);
			throw e;
		}
		return objInvestmentVehicleDD_Data;
	}
public static void main(String[] args) {
	

String d1="02/02/2019";
DateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY");
System.out.println("kfhdgkhfdlg"+(new Date(d1).getTime()));
	Date d=new Date();
	System.out.println(dateFormat.format(d));
}
}
