package com.ssc.rest.dml.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssc.rest.common.RequestAction;
import com.ssc.rest.dml.dao.CollateralDao;
import com.ssc.rest.dml.entity.AccountCrossRefVO;
import com.ssc.rest.dml.entity.CollatAccDetails;
import com.ssc.rest.dml.service.CollateralService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.log4j.Logger;

@RestController
@Api(value = "/CollateralAccountList", tags = "CollateralAccountList Api")
@RequestMapping(value = "/api/CollateralAccountList")
public class CollateralAccListController {
	
	@Autowired
	CollateralService collateralService;
	private static final Logger log = Logger.getLogger(CollateralAccListController.class);
	/**
 	 * http://localhost:8080/cloudservices/api/CollateralAccountList/list
     * Used to fetch all CollatAcc details 
     * 
     * Content-Type: application/json
     * request body object is mandatory {}
     * return list as response
     * @param bo
     * @return
     */
	@RequestMapping(value = RequestAction.LIST, method = RequestMethod.POST)
	@ApiOperation(value = "getCollatAccList", notes = " getCollatAccList ", httpMethod = "POST", response = CollatAccDetails.class, responseContainer = "List")
	public List<CollatAccDetails> getCollatAccList(@RequestBody AccountCrossRefVO vo) {
		log.info("getCollatAccList input object is:"+vo.toString());
		List<CollatAccDetails> list = collateralService.getCollatAccList(vo);
		return list;
		
	}
}
