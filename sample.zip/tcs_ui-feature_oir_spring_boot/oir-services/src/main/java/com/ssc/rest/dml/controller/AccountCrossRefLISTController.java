package com.ssc.rest.dml.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssc.rest.common.RequestAction;
import com.ssc.rest.dml.dao.CollateralDao;
import com.ssc.rest.dml.entity.AccountCrossRefDetails;
import com.ssc.rest.dml.entity.AccountCrossRefVO;
import com.ssc.rest.dml.service.CollateralService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.log4j.Logger;
@RestController
@Api(value = "/AccountCrossRefList", tags = "AccountCrossRefList Account Api")
@RequestMapping(value = "/api/AccountCrossRefList")
public class AccountCrossRefLISTController {
	@Autowired
	CollateralDao collateralDao;
	
	private static final Logger log = Logger.getLogger(AccountCrossRefLISTController.class);

	@Autowired
	CollateralService collateralService;
	/**
 	 * http://localhost:8080/cloudservices/api/AccountCrossRefList/list
     * Used to fetch details based on inputobject 
     * 
     * Content-Type: application/json
     * request body object is mandatory {}
     * return AccountCrossRefDetails obj as response
     * @param bo
     * @return
	 * @throws Exception 
     */
	@RequestMapping(value = RequestAction.LIST, method = RequestMethod.POST)
	@ApiOperation(value = "getAccountCrossRefDetails", notes = "get Collateral Account Cross Reference List", httpMethod = "POST", response = AccountCrossRefDetails.class, responseContainer = "Object")
	public AccountCrossRefDetails  getAccountCrossRefDetails(@RequestBody AccountCrossRefVO vo) throws Exception {
		log.info("getAccountCrossRefDetails based on Input : "+vo);
		return collateralService.getAccountCrossRefDetails(vo);
	}
	
}
