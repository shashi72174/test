package com.ssc.rest.dml.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssc.rest.common.RequestAction;
import com.ssc.rest.common.entity.OIRFilterDropdowndetails;
import com.ssc.rest.common.service.OIRService;
import com.ssc.rest.dml.entity.Collateral;

@RestController
@Api(value = "/DmlDDList", tags = "dml collateral dropdown list Api")
@RequestMapping(value = "/api/DmlDDList")
public class DmlCollateralFilterData {
	//private static final Logger log = Logger.getLogger(DmlCollateralFilterData.class);
	
	@Autowired
	OIRService collateralService;
		
	@RequestMapping(value = RequestAction.LIST, method = RequestMethod.POST)
	@ApiOperation(value = "getdmlDDList", notes = "get dml collateral dropdown list", httpMethod = "POST", response = Collateral.class, responseContainer = "List")
	public OIRFilterDropdowndetails getDmlCollatDDList() {
		return collateralService.getCollDDData();

	}
}
