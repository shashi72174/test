package com.ssc.rest.inv.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ssc.rest.inv.dao.InvestmentVehicleDao;
import com.ssc.rest.inv.entity.InvestVehicleRefVO;
import com.ssc.rest.inv.entity.InvestmentVehicleDD_Data;
import com.ssc.rest.inv.entity.InvestmentvehicleList;
import com.ssc.rest.inv.entity.InvestmentvehiclerefDetails;

@Component
public class InvestmentvehicleServiceImpl implements InvestmentvehicleService {
	
	@Autowired
	InvestmentVehicleDao investmentVehicleDao;
	
	public void setInvestmentVehicleDao(InvestmentVehicleDao investmentVehicleDao) {
		this.investmentVehicleDao = investmentVehicleDao;
	}

	@Override
	public InvestmentvehiclerefDetails getInvVehicleDetails(InvestVehicleRefVO vo) throws Exception {
		
		InvestmentvehiclerefDetails obj = investmentVehicleDao.getInvestmentVehiceFilterDetails(vo);
		return obj;
	}

	@Override
	public InvestmentvehiclerefDetails saveinvVehicleDetails(InvestVehicleRefVO vo) {
		InvestmentvehiclerefDetails objInvestmentvehiclerefDetails=investmentVehicleDao.saveInvVehicleDetails(vo);
		return objInvestmentvehiclerefDetails;
	}

	@Override
	public InvestmentVehicleDD_Data getInvVehAllDDList() {
		return investmentVehicleDao.getInvVehAllDDList();
	}

	@Override
	public InvestVehicleRefVO getInvVehicleRowDetails(InvestVehicleRefVO vo) {	
		return investmentVehicleDao.getInvVehicleRowDetails(vo);
	}

	@Override
	public List<InvestmentvehicleList> getCollCodeList(InvestVehicleRefVO vo) {
		List<InvestmentvehicleList> list=investmentVehicleDao.getCollCodeList(vo);
		InvestmentvehicleList objInvestmentvehicleList = new InvestmentvehicleList();
		objInvestmentvehicleList.setLabel("ALL");
		objInvestmentvehicleList.setValue("0");
		list.add(0, objInvestmentvehicleList);
		return list;
	}

	

}
