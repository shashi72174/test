package com.ssc.rest.inv.entity;

import java.io.Serializable;

public class InvestmentVehCommon  implements Serializable{
private int recordsSize;

public int getRecordsSize() {
	return recordsSize;
}

public void setRecordsSize(int recordsSize) {
	this.recordsSize = recordsSize;
}
@Override
public String toString()
{
    return "records per page"+recordsSize;
}
}
