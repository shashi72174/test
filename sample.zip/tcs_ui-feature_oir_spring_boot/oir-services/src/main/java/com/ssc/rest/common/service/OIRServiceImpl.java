package com.ssc.rest.common.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ssc.rest.common.dao.OIRDao;
import com.ssc.rest.common.entity.OIRFilterDropdowndetails;

@Component
public class OIRServiceImpl implements OIRService {

	@Autowired
	OIRDao collateralDao;

	public void setCollateralDao(OIRDao collateralDao) {
		this.collateralDao = collateralDao;
	}

	public OIRFilterDropdowndetails getCollDDData() {
		return collateralDao.getOIRFilterDropdowndetails();
	}

}
