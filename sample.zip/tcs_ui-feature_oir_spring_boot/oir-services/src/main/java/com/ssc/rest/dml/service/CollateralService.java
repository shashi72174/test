package com.ssc.rest.dml.service;

import java.util.List;

import com.ssc.rest.dml.entity.AccountCrossRefDetails;
import com.ssc.rest.dml.entity.AccountCrossRefVO;
import com.ssc.rest.dml.entity.CollatAccDetails;

public interface CollateralService
{

    public AccountCrossRefDetails getAccountCrossRefDetails(AccountCrossRefVO vo) throws Exception;   
    
    public AccountCrossRefDetails saveCrossRefDetails(AccountCrossRefVO vo);
    
    //public DmlCollateralDDdetails getCollDDData();
    
    public List<CollatAccDetails> getCollatAccList(AccountCrossRefVO vo);

	public AccountCrossRefVO getCollateralAcctXRefDetails(AccountCrossRefVO vo);
}
