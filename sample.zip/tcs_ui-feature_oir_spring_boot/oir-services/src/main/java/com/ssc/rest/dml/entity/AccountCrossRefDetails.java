package com.ssc.rest.dml.entity;

import java.io.Serializable;
import java.util.List;

public class AccountCrossRefDetails implements Serializable {

	
	private static final long serialVersionUID = 1L;
	private List<AccountCrossRefVO>   accountCrossRefVOList;
	private AccountCrossRefVO accountCrossRefVO;
	private int  pageNumber;
	private int  totalRecords;
	private int  recordsPerPage;
	
	private String responseType;
	private String errorCode;
	private String[] errorDesc;
	private int prePageNo;
	private int nextPageNo;
	private String isNextDisable;
	
	
	public String getIsNextDisable()
	{
	    return isNextDisable;
	}
	public void setIsNextDisable(String isNextDisable)
	{
	    this.isNextDisable = isNextDisable;
	}
	public int getPrePageNo()
	{
	    return prePageNo;
	}
	public void setPrePageNo(int prePageNo)
	{
	    this.prePageNo = prePageNo;
	}
	public int getNextPageNo()
	{
	    return nextPageNo;
	}
	public void setNextPageNo(int nextPageNo)
	{
	    this.nextPageNo = nextPageNo;
	}
	public List<AccountCrossRefVO> getAccountCrossRefVOList()
	{
	    return accountCrossRefVOList;
	}
	public void setAccountCrossRefVOList(List<AccountCrossRefVO> accountCrossRefVOList)
	{
	    this.accountCrossRefVOList = accountCrossRefVOList;
	}
	public int getPageNumber()
	{
	    return pageNumber;
	}
	public void setPageNumber(int pageNumber)
	{
	    this.pageNumber = pageNumber;
	}
	public int getTotalRecords()
	{
	    return totalRecords;
	}
	public void setTotalRecords(int totalRecords)
	{
	    this.totalRecords = totalRecords;
	}
	public int getRecordsPerPage()
	{
	    return recordsPerPage;
	}
	public void setRecordsPerPage(int recordsPerPage)
	{
	    this.recordsPerPage = recordsPerPage;
	}
	
	public String getErrorCode()
	{
	    return errorCode;
	}
	public void setErrorCode(String errorCode)
	{
	    this.errorCode = errorCode;
	}
	public String[] getErrorDesc()
	{
	    return errorDesc;
	}
	public void setErrorDesc(String[] errorDesc)
	{
	    this.errorDesc = errorDesc;
	}
	public String getResponseType()
	{
	    return responseType;
	}
	public void setResponseType(String responseType)
	{
	    this.responseType = responseType;
	}
	public AccountCrossRefVO getAccountCrossRefVO()
	{
	    return accountCrossRefVO;
	}
	public void setAccountCrossRefVO(AccountCrossRefVO accountCrossRefVO)
	{
	    this.accountCrossRefVO = accountCrossRefVO;
	}
	@Override
	public String toString()
	{
	    return "AccountCrossRefDetails [pageNumber=" + pageNumber + ", totalRecords=" + totalRecords + ", recordsPerPage="
		    + recordsPerPage + "]";
	}
	
	
	
		
}
