package com.ssc.rest.inv.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssc.rest.common.RequestAction;
import com.ssc.rest.inv.entity.InvestVehicleRefVO;
import com.ssc.rest.inv.entity.InvestmentvehiclerefDetails;
import com.ssc.rest.inv.service.InvestmentvehicleService;

@RestController
@Api(value = "/InvestmentVehicleFilterList", tags = "InvestmentVehicleFilterList Account Api")
@RequestMapping(value = "/api/InvestmentVehicleFilterList")
public class GetInvestmentVehicleFilterDetails {
	@Autowired
	InvestmentvehicleService investmentvehicleService;
	private static final Logger log=Logger.getLogger(GetInvestmentVehicleFilterDetails.class);
	/**
	 * http://localhost:8080/cloudservices/api/InvestmentvehicleService/list
	 * Used to fetch details based on inputobject
	 * 
	 * Content-Type: application/json request body object is mandatory {} return
	 * obj as response
	 * 
	 * @param bo
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = RequestAction.LIST, method = RequestMethod.POST)
	@ApiOperation(value = "getInvestmentVehicleFilterList", notes = "getInvestmentVehicleFilterList List", httpMethod = "POST", response = InvestmentvehiclerefDetails.class, responseContainer = "Object")
	public InvestmentvehiclerefDetails getInvVehicleFilterList(@RequestBody InvestVehicleRefVO vo) throws Exception {
		log.info("getInvVehicleFilterList obj:"+vo.toString());
		return investmentvehicleService.getInvVehicleDetails(vo);
	}
}
