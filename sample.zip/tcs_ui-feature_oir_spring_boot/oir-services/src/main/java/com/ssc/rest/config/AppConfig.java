package com.ssc.rest.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.JdbcTemplate;

import Matrix.PwMatrix;

@Configuration
@PropertySource("classpath:application-${spring.profiles.active}.properties")
public class AppConfig {
	
	@Value("${driverClass}")
	private String driverClass;
	
	@Value("${url}")
	private String URL;
	
	
	@Value("${pwMatrix}")	
	private String pwMatrix;
	
	@Value("${pageSize}")
	private int pageSize;	
	
	@Value("${spring.profiles.active}")	
	private String env;
	
	
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	
	
	@Bean
	@Primary
	public DataSource dataSource() {
		String[] serverAnduser = this.pwMatrix.split(";");
		String userName;
		String password;
		String serverName;
		if("dev".equalsIgnoreCase(this.env))  {
			userName=serverAnduser[0];
			password=serverAnduser[1];
		}else{
			serverName = serverAnduser[0];
			userName = serverAnduser[1];
			password = PwMatrix.getPassword(serverName,userName);
		}
		
		
	    return DataSourceBuilder
	        .create()
	        .username(userName)
	        .password(password)
	        .url(this.URL)
	        .driverClassName(this.driverClass)
	        .build();
	}
	
	@Bean 
	public JdbcTemplate jdbcTemplate(DataSource ds) { 
	    return new JdbcTemplate(ds); 
	}
	
}
