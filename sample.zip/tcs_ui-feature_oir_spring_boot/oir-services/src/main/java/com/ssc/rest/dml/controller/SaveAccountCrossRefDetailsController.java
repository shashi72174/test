package com.ssc.rest.dml.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssc.rest.common.RequestAction;
import com.ssc.rest.dml.dao.CollateralDao;
import com.ssc.rest.dml.entity.AccountCrossRefDetails;
import com.ssc.rest.dml.entity.AccountCrossRefVO;
import com.ssc.rest.dml.service.CollateralService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.log4j.Logger;
@RestController
@Api(value = "/SaveAccountCrossRefDetails", tags = "SaveAccountCrossRefDetails Account Api")
@RequestMapping(value = "/api/SaveAccountCrossRefDetails")
public class SaveAccountCrossRefDetailsController {
	
	        
	@Autowired
CollateralService collateralService;
	private static final Logger log = Logger.getLogger(SaveAccountCrossRefDetailsController.class);
	/**
 	 * http://localhost:8080/cloudservices/api/SaveAccountCrossRefDetails/add
     * Used to save newly created records or Modified records to table
     * 
     * Content-Type: application/json
     * request body object is mandatory {}
     * return AccountCrossRefDetails object (data as response if sucess or error data from storeproc in obj) as response
     * @param bo
     * @return
     */
	@RequestMapping(value = RequestAction.ADD, method = {  RequestMethod.POST } )
	@ApiOperation(value = "saveAccountCrossRefDetails", notes = "save Collateral Account Cross Reference List", httpMethod = "POST", response = AccountCrossRefDetails.class, responseContainer = "Object")
	public AccountCrossRefDetails  saveCrossRefDetails(@RequestBody AccountCrossRefVO  vo) {
		return collateralService.saveCrossRefDetails(vo);	    	
	}
}
