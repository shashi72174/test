package com.ssc.rest.dml.dao;

import java.util.List;

import com.ssc.rest.dml.entity.AccountCrossRefDetails;
import com.ssc.rest.dml.entity.AccountCrossRefVO;
import com.ssc.rest.dml.entity.CollatAccDetails;

public interface CollateralDao {

	public List<CollatAccDetails> getCollatAccList(AccountCrossRefVO vo);

	public AccountCrossRefDetails getAllDMLCollateralAcctXRef(AccountCrossRefVO vo) throws Exception;

	public AccountCrossRefVO getCollateralAcctXRefDetails(AccountCrossRefVO vo);

	public AccountCrossRefDetails saveCrossRefDetails(AccountCrossRefVO vo);

	//public DmlCollateralDDdetails getDmlCollatDDList();
	
	public final String COLLACC_LIST_QUERY="select t.coll_acct_id,t.coll_acct_nm from oir.triparty_coll_acct t where t.curr_rec_flg = ? and t.source_sq=? order by t.coll_acct_id";
	
	public final String ACCT_XREF_DETAIL_QUERY = "SELECT UPPER(dmlColl.ACTIVE_FLG) as p_activeInactive, smap.source_sq as p_triPartyAgentId, dmlColl.COLL_TYPE_SQ as p_collateralTypCode, dmlColl.HOUSE_ACCT_ID as p_houseId, dmlColl.CTPY_ID AS p_dmlctpyid, UPPER(dmlColl.COLL_ACCT_ID) AS p_collateralAccount, to_char(dmlColl.VALID_FROM_DT,'mm/dd/yyyy') AS p_validfrom, to_char(dmlColl.VALID_TO_DT,'mm/dd/yyyy') AS p_validto, dmlColl.Last_Mod_Signon_Id as p_userId, to_char(dmlColl.Last_Mod_Date_Time,'mm/dd/yyyy') as p_last_mod_date_time, dmlColl.curr_rec_flg as p_currRec,dmlColl.rowid FROM OIR.NON_CASH_COLL_ACCT_XREF dmlColl inner join OIR.SOURCE_MAP smap on smap.triparty_agent_id = dmlcoll.triparty_agent_id inner join SLID.REFCODE_ACTVCOLLATERALCD_V colAcct on colAcct.CODEVALUE = dmlcoll.coll_type_sq where dmlColl.rowid=? and smap.triparty_agent_id=? and dmlColl.House_Acct_Id=? and dmlColl.Ctpy_Id=? and dmlColl.COLL_ACCT_ID=? and dmlColl.ACTIVE_FLG=?";


}
