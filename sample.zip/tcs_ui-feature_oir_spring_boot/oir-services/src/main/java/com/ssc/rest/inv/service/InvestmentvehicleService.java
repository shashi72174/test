package com.ssc.rest.inv.service;

import java.util.List;

import com.ssc.rest.inv.entity.InvestVehicleRefVO;
import com.ssc.rest.inv.entity.InvestmentVehicleDD_Data;
import com.ssc.rest.inv.entity.InvestmentvehicleList;
import com.ssc.rest.inv.entity.InvestmentvehiclerefDetails;

public interface InvestmentvehicleService {
	
    public InvestmentvehiclerefDetails getInvVehicleDetails(InvestVehicleRefVO vo) throws Exception;

	public InvestmentvehiclerefDetails saveinvVehicleDetails(InvestVehicleRefVO vo);

	public InvestmentVehicleDD_Data getInvVehAllDDList();

	public InvestVehicleRefVO getInvVehicleRowDetails(InvestVehicleRefVO vo);

	public List<InvestmentvehicleList> getCollCodeList(InvestVehicleRefVO vo);   
	
}
