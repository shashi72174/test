package com.ssc.rest.dml.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssc.rest.common.RequestAction;
import com.ssc.rest.dml.dao.CollateralDao;
import com.ssc.rest.dml.entity.AccountCrossRefVO;
import com.ssc.rest.dml.service.CollateralService;
import org.apache.log4j.Logger;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
@RestController
@Api(value = "/CollateralCrossReflist", tags = "CollateralCrossReflist Account Api")
@RequestMapping(value = "/api/CollateralCrossReflist")
public class CollateralCrossRefDetailsController {
	
	@Autowired
	CollateralService collateralService;
	private static final Logger log = Logger.getLogger(CollateralCrossRefDetailsController.class);
	
	/**
 	 * http://localhost:8080/cloudservices/api/CollateralCrossReflist/list
     * Used to fetch  CollateralCrossRef details based on input params like rowId..etc
     * 
     * Content-Type: application/json
     * request body object is mandatory {}
     * return AccountCrossRefVO obj as response
     * @param bo
     * @return
     */
	@RequestMapping(value = RequestAction.LIST, method = {  RequestMethod.POST } )
	@ApiOperation(value = "getCollateralAcctXRefDetails", notes = "get Collateral Account Cross Reference Details", httpMethod = "POST", response = AccountCrossRefVO.class, responseContainer = "Object")
	public AccountCrossRefVO  getCollateralAcctXRefDetails(@RequestBody AccountCrossRefVO  vo) {
	    log.info("********getCollateralAcctXRefDetails input obj is"+vo.toString());	
		AccountCrossRefVO obj=collateralService.getCollateralAcctXRefDetails(vo);
	    	return  obj;
	}
}
