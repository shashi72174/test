package com.ssc.rest.dml.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import oracle.sql.ROWID;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.ssc.rest.common.ErrorMessageProperties;
import com.ssc.rest.common.RequestAction;
import com.ssc.rest.config.AppConfig;
import com.ssc.rest.dml.entity.AccountCrossRefDetails;
import com.ssc.rest.dml.entity.AccountCrossRefVO;
import com.ssc.rest.dml.entity.CollatAccDetails;

@Component
public class CollateralDaoImpl implements CollateralDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	ErrorMessageProperties props;
	@Autowired
	AppConfig appconfig;

	private static final Logger log = Logger.getLogger(CollateralDaoImpl.class);

	 

	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	/*
	private List<Collateral> getCollateralList() {
		try {
			return this.jdbcTemplate.query(COLLATERAL_LIST_QUERY,new CollateralCodeMapper());
		} catch (Exception ex) {
			log.error("exception occurred ",ex);
			throw ex;
		}
	}

	private static final class CollateralCodeMapper implements RowMapper<Collateral> {

		public Collateral mapRow(ResultSet rs, int rowNum) throws SQLException {
			Collateral obj = new Collateral();
			obj.setValue(rs.getString("codevalue"));
			obj.setLabel(rs.getString("codelongdescription"));
			return obj;
		}
	}

	
	private List<Collateral> getHouseDetailList() {
		try {
			return this.jdbcTemplate.query(HOUSE_LIST_QUERY,new HouseDetailsMapper());
		} catch (Exception ex) {
			log.error("exception occurred ",ex);
			throw ex;
		}
	}

	private static final class HouseDetailsMapper implements RowMapper<Collateral> {

		public Collateral mapRow(ResultSet rs, int rowNum) throws SQLException {
			Collateral obj = new Collateral();
			obj.setLabel(rs.getString("codevalue"));
			obj.setValue(rs.getString("codevalue"));
			return obj;
		}
	}

	
	private List<Collateral> getTripartyAgentFileList() {
		try {
			return this.jdbcTemplate.query(TRIPARTY_LIST_QUERY,new TripartyAgentFileMapper());
		} catch (Exception ex) {
			log.error("exception occurred ",ex);
			throw ex;
		}
	}

	private static final class TripartyAgentFileMapper implements RowMapper<Collateral> {

		public Collateral mapRow(ResultSet rs, int rowNum) throws SQLException {
			Collateral obj = new Collateral();
			obj.setValue(rs.getString("codevalue"));
			obj.setLabel(rs.getString("codelongdescription"));
			return obj;
		}
	}
*/
	@Override
	public AccountCrossRefDetails getAllDMLCollateralAcctXRef(AccountCrossRefVO vo) throws Exception {
		List<AccountCrossRefVO> accountCrossRefVOList = new ArrayList<AccountCrossRefVO>();
		AccountCrossRefDetails obj = new AccountCrossRefDetails();
		SqlOutParameter tSize = new SqlOutParameter("tSize", java.sql.Types.NUMERIC);
		SqlOutParameter errCode = new SqlOutParameter("errCode", java.sql.Types.NUMERIC);
		SqlOutParameter errMsg = new SqlOutParameter("errMsg", java.sql.Types.VARCHAR);
		SqlOutParameter errType = new SqlOutParameter("errType", java.sql.Types.VARCHAR);
		SqlOutParameter curDMLCollAcctXRef = new SqlOutParameter("curDMLCollAcctXRef", oracle.jdbc.OracleTypes.CURSOR);
		List<SqlParameter> sqlParamList = new ArrayList<SqlParameter>();
		sqlParamList.add(new SqlParameter(java.sql.Types.VARCHAR));//1
		sqlParamList.add(new SqlParameter(java.sql.Types.INTEGER));//2
		sqlParamList.add(new SqlParameter(java.sql.Types.DATE));//3
		sqlParamList.add(new SqlParameter(java.sql.Types.VARCHAR));//4
		sqlParamList.add(new SqlParameter(java.sql.Types.VARCHAR));//5
		sqlParamList.add(new SqlParameter(java.sql.Types.DATE));//6
		sqlParamList.add(new SqlParameter(java.sql.Types.VARCHAR));//7
		sqlParamList.add(new SqlParameter(java.sql.Types.VARCHAR));//8
		sqlParamList.add(new SqlParameter(java.sql.Types.VARCHAR));//9
		sqlParamList.add(new SqlParameter(java.sql.Types.INTEGER));//10
		sqlParamList.add(new SqlParameter(java.sql.Types.VARCHAR));//11
		sqlParamList.add(new SqlParameter(java.sql.Types.INTEGER));//12
		sqlParamList.add(new SqlParameter(java.sql.Types.INTEGER));//13
		sqlParamList.add(tSize);//14
		sqlParamList.add(errCode);//15
		sqlParamList.add(errMsg);//16
		sqlParamList.add(errType);//17
		sqlParamList.add(curDMLCollAcctXRef);//18
		
		Map<String,Object> resultMap = jdbcTemplate.call(new CallableStatementCreator(){

			@Override
			public CallableStatement createCallableStatement(Connection con) throws SQLException {
				// TODO Auto-generated method stub
				CallableStatement cstmt = con.prepareCall("{call SLID.PKG_OIR_COLLATERAL.SP_OIR_DMLCOLLACCT_XREF(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
				if(!StringUtils.isEmpty(vo.getCollateralCode()) && !vo.getCollateralCode().equals("0")) 
					cstmt.setString(1, vo.getCollateralCode());
				else
					cstmt.setNull(1, java.sql.Types.VARCHAR);
				
				if(!StringUtils.isEmpty(vo.getTriPartyAgentId()) &&  !vo.getTriPartyAgentId().equals("0")) 
					cstmt.setInt(2, Integer.parseInt(vo.getTriPartyAgentId()));
				else
					cstmt.setNull(2, java.sql.Types.INTEGER);
				
				if(!StringUtils.isEmpty(vo.getValidFromDate())) 
					cstmt.setDate(3, new java.sql.Date(new Date(vo.getValidFromDate()).getTime()));
				else
					cstmt.setNull(3, java.sql.Types.DATE);
				
				if(!StringUtils.isEmpty(vo.getHouseAcctId()) && !vo.getHouseAcctId().equals("0") )
					cstmt.setString(4, vo.getHouseAcctId());
				else
					cstmt.setNull(4, java.sql.Types.VARCHAR);
				
				if(!StringUtils.isEmpty(vo.getCollateralAcct()) ) 
					cstmt.setString(5, vo.getCollateralAcct());
				else
					cstmt.setNull(5, java.sql.Types.VARCHAR);
				
				if(!StringUtils.isEmpty(vo.getValidToDate())) 
					cstmt.setDate(6, new java.sql.Date(new Date(vo.getValidToDate()).getTime()));
				else
					cstmt.setNull(6, java.sql.Types.DATE);
				
				if(!StringUtils.isEmpty(vo.getCounterPartyId()) ) 
					cstmt.setString(7, vo.getCounterPartyId());
				else
					cstmt.setNull(7, java.sql.Types.VARCHAR);
				
				if(!StringUtils.isEmpty(vo.getCurrentRecFlag()) ) 
					cstmt.setString(8, vo.getCurrentRecFlag());
				else
					cstmt.setNull(8, java.sql.Types.VARCHAR);
				
				if(!StringUtils.isEmpty(vo.getActiveFlag()) &&  !vo.getActiveFlag().equals("0") ) 
					cstmt.setString(9, vo.getActiveFlag());
				else
					cstmt.setNull(9, java.sql.Types.VARCHAR);
				
				cstmt.setNull(10, java.sql.Types.INTEGER);
				cstmt.setNull(11, java.sql.Types.VARCHAR);
				cstmt.setInt(12, ((vo.getPageNo()-1)*appconfig.getPageSize())+1);
				cstmt.setInt(13, vo.getPageNo()*appconfig.getPageSize());
				cstmt.registerOutParameter(14, java.sql.Types.NUMERIC);
				cstmt.registerOutParameter(15, java.sql.Types.NUMERIC);
				cstmt.registerOutParameter(16, java.sql.Types.VARCHAR);
				cstmt.registerOutParameter(17, java.sql.Types.VARCHAR);
				cstmt.registerOutParameter(18, oracle.jdbc.OracleTypes.CURSOR);
				return cstmt;
				
				
			}
			
		},  sqlParamList);
		DateFormat inFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		DateFormat outFormat = new SimpleDateFormat("MM/dd/yyyy");
		List resultList = ((ArrayList)resultMap.get("curDMLCollAcctXRef"));
		for(int i=0;i<resultList.size();i++) {
			Map rowMap = (Map)resultList.get(i);
			//System.out.println(rowMap);
			AccountCrossRefVO accountCrossRefVO = new AccountCrossRefVO();
			accountCrossRefVO.setActiveFlag((String)rowMap.get("P_ACTIVEINACTIVE"));
			accountCrossRefVO.setHouseAcctId((String)rowMap.get("P_HOUSEID"));
			accountCrossRefVO.setCounterPartyId((String)rowMap.get("P_DMLCTPYID"));
			accountCrossRefVO.setCollateralAcct((String)rowMap.get("P_COLLATERALACCOUNT"));
			accountCrossRefVO.setLastModifiedId((String)rowMap.get("USERID"));
			accountCrossRefVO.setTriPartyAgentId(rowMap.get("P_TRIPARTYAGENTID").toString());
			accountCrossRefVO.setColTypeCode(((BigDecimal)rowMap.get("P_COLLATERALTYPCODE")).toString());
			accountCrossRefVO.setCollateralCode(rowMap.get("P_COLLATERALCODE").toString());
			accountCrossRefVO.setValidFromDate(outFormat.format(inFormat.parse(((Timestamp)rowMap.get("P_VALIDFROM")).toString())));
			accountCrossRefVO.setValidToDate(outFormat.format(inFormat.parse(((Timestamp)rowMap.get("P_VALIDTO")).toString())));
			accountCrossRefVO.setLastModifiedDate(outFormat.format(inFormat.parse(((Timestamp)rowMap.get("LASTMODIFIED")).toString())));
			accountCrossRefVO.setRowId(((ROWID)rowMap.get("ROWIDNUM")).stringValue());
			accountCrossRefVO.setCurrentRecFlag((String)rowMap.get("P_CURRREC"));
			accountCrossRefVOList.add(accountCrossRefVO);
		}
		obj.setTotalRecords(((BigDecimal)resultMap.get("tSize")).intValue());
		obj.setPageNumber(vo.getPageNo());
		obj.setPrePageNo(vo.getPageNo());
		obj.setNextPageNo(vo.getPageNo() + 1);
		if ((vo.getPaginationType().equals("pre") && vo.getPageNo() > 1)
				|| (accountCrossRefVOList.size() < appconfig.getPageSize() && vo.getPaginationType().equals("next"))) {
			obj.setPrePageNo(vo.getPageNo() - 1);
			obj.setNextPageNo(vo.getPageNo());
		}		
		obj.setRecordsPerPage(appconfig.getPageSize() * vo.getPageNo());
		obj.setIsNextDisable("N");
		if ((appconfig.getPageSize() * vo.getPageNo()) >= obj.getTotalRecords()) {
			obj.setIsNextDisable("Y");
			obj.setRecordsPerPage(obj.getTotalRecords());
		}
		log.info("filter criteria response obj is:"+obj.toString());
		obj.setAccountCrossRefVOList(accountCrossRefVOList);
		/*
		if(rs!=null) {
			while(rs.next()) {
				AccountCrossRefVO accountCrossRefVO = new AccountCrossRefVO();
				accountCrossRefVO.setActiveFlag(rs.getString(1));
				accountCrossRefVO.setTriPartyAgentId(rs.getString(2));
				accountCrossRefVO.setColTypeCode(rs.getString(3));
				accountCrossRefVO.setHouseAcctId(rs.getString(4));
				accountCrossRefVO.setCounterPartyId(rs.getString(5));
				accountCrossRefVO.setCollateralAcct(rs.getString(6));
				accountCrossRefVO.setValidFromDate(rs.getString(7));
				accountCrossRefVO.setValidToDate(rs.getString(8));
				accountCrossRefVO.setLastModifiedId(rs.getString(9));
				accountCrossRefVO.setLastModifiedDate(rs.getString(10));
				accountCrossRefVO.setCollateralCode(rs.getString(12));
				accountCrossRefVO.setRowId(rs.getString(13));
				accountCrossRefVOList.add(accountCrossRefVO);
			}
		}*/
		//obj.setAccountCrossRefVOList(accountCrossRefVOList);
		/*String ACCT_XREF_LIST_QUERY = "SELECT * FROM (SELECT UPPER(dmlColl.p_activeInactive) as p_activeInactive, dmlColl.p_triPartyAgentId as p_triPartyAgentId, dmlColl.p_collateralTypCode as p_collateralTypCode, dmlColl.p_houseId as p_houseId, dmlColl.p_dmlctpyid AS p_dmlctpyid, UPPER(dmlColl.p_collateralAccount) AS p_collateralAccount, to_char(dmlColl.p_validfrom, 'mm/dd/yyyy') AS p_validfrom, to_char(dmlColl.p_validto, 'mm/dd/yyyy') AS p_validto, UPPER(dmlColl.userID) AS userID, to_char(dmlColl.lastModified, 'mm/dd/yyyy') AS lastModified, dmlColl.p_currRec as p_currRec, dmlColl.p_collateralCode as p_collateralCode,dmlColl.p_rowIdNum as rowIdNum, rownum rn FROM (SELECT UPPER(dmlColl.ACTIVE_FLG) as p_activeInactive, dmlcoll.triparty_agent_id as p_triPartyAgentId, dmlColl.COLL_TYPE_SQ as p_collateralTypCode, dmlColl.HOUSE_ACCT_ID as p_houseId, dmlColl.CTPY_ID AS p_dmlctpyid, UPPER(dmlColl.COLL_ACCT_ID) AS p_collateralAccount, dmlColl.VALID_FROM_DT AS p_validfrom, dmlColl.VALID_TO_DT AS p_validto, UPPER(dmlColl.LAST_MOD_SIGNON_ID) AS userID, dmlColl.LAST_MOD_DATE_TIME AS lastModified, dmlColl.curr_rec_flg as p_currRec, colAcct.CODELONGDESCRIPTION as p_collateralCode,dmlColl.rowid as p_rowIdNum FROM OIR.NON_CASH_COLL_ACCT_XREF dmlColl inner join OIR.SOURCE_MAP smap on smap.triparty_agent_id = dmlcoll.triparty_agent_id inner join SLID.REFCODE_ACTVCOLLATERALCD_V colAcct on colAcct.CODEVALUE = dmlcoll.coll_type_sq where 1=1";
		String endSql = "", ACCT_XREF_TOTAL_COUNT_QUERY = "";
		AccountCrossRefDetails obj = new AccountCrossRefDetails();
		List paramList = new ArrayList();
		int limit = 0, offSet = 0;
		try {
			limit = vo.getPageNo() * appconfig.getPageSize();
			offSet = (vo.getPageNo() - 1) * appconfig.getPageSize();
			if (!StringUtils.isEmpty(vo.getSearchTypeFlag()) && vo.getSearchTypeFlag().equalsIgnoreCase("1"))
				endSql = " order by dmlColl.LAST_MOD_DATE_TIME desc  ) dmlColl WHERE rownum <= ?) WHERE rn >= ?";
			
			else
				endSql = " order by dmlColl.LAST_MOD_DATE_TIME desc  ) dmlColl WHERE rownum <= ?) WHERE rn >= ?";
			
			if (!StringUtils.isEmpty(vo.getCollateralCode()) && !vo.getCollateralCode().equalsIgnoreCase("0")) { 
				ACCT_XREF_LIST_QUERY = ACCT_XREF_LIST_QUERY + " and dmlColl.COLL_TYPE_SQ = ?";
				paramList.add(vo.getCollateralCode().toString());
			}
			if (!StringUtils.isEmpty(vo.getTriPartyAgentId()) && !vo.getTriPartyAgentId().equalsIgnoreCase("0")) { 
				ACCT_XREF_LIST_QUERY = ACCT_XREF_LIST_QUERY + " and smap.source_sq = ?";
				paramList.add(vo.getTriPartyAgentId().toString());
			}
			
			if (!StringUtils.isEmpty(vo.getHouseAcctId()) && !vo.getHouseAcctId().equalsIgnoreCase("0"))  {
				ACCT_XREF_LIST_QUERY = ACCT_XREF_LIST_QUERY + " and dmlColl.HOUSE_ACCT_ID = ?";
				paramList.add(vo.getHouseAcctId().toString());
			}

			if (!StringUtils.isEmpty(vo.getCollateralAcct())) {
				ACCT_XREF_LIST_QUERY = ACCT_XREF_LIST_QUERY + " and dmlColl.COLL_ACCT_ID = ?";
				paramList.add(vo.getCollateralAcct().toString());
			}
			if (!StringUtils.isEmpty(vo.getCounterPartyId())) {
				ACCT_XREF_LIST_QUERY = ACCT_XREF_LIST_QUERY + " and dmlColl.CTPY_ID = ?";
				paramList.add(vo.getCounterPartyId().toString());
				
			}
			if (!StringUtils.isEmpty(vo.getActiveFlag()) && !vo.getActiveFlag().equalsIgnoreCase("0")) {
				ACCT_XREF_LIST_QUERY = ACCT_XREF_LIST_QUERY + " and dmlColl.ACTIVE_FLG = ?";
				paramList.add(vo.getActiveFlag().toString());
			}
			SimpleDateFormat inDateFormat = new SimpleDateFormat("MM/dd/yyyy");
			SimpleDateFormat outDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
			if (!StringUtils.isEmpty(vo.getValidFromDate()) && !StringUtils.isEmpty(vo.getValidToDate())) {
				Date uiFromDate = inDateFormat.parse(vo.getValidFromDate().toString());
				Date uiToDate = inDateFormat.parse(vo.getValidToDate().toString());
				String sqlFromDate = outDateFormat.format(uiFromDate);
				String sqlToDate = outDateFormat.format(uiToDate);
				ACCT_XREF_LIST_QUERY = ACCT_XREF_LIST_QUERY + " and ((( '" + sqlFromDate
						+ "' BETWEEN dmlColl.VALID_FROM_DT and '" + sqlToDate + "') AND ('" + sqlToDate + "' BETWEEN '"
						+ sqlFromDate + "' and dmlColl.VALID_TO_DT))" + "or ((dmlColl.VALID_FROM_DT BETWEEN '"
						+ sqlFromDate + "' and '" + sqlToDate
						+ "') AND (dmlColl.VALID_TO_DT BETWEEN dmlColl.VALID_FROM_DT and '" + sqlToDate + "'))"
						+ "or ((dmlColl.VALID_FROM_DT BETWEEN '" + sqlFromDate + "' and '" + sqlToDate + "') AND ('"
						+ sqlToDate + "' BETWEEN dmlColl.VALID_FROM_DT and dmlColl.VALID_TO_DT))	or (('"
						+ sqlFromDate
						+ "'BETWEEN dmlColl.VALID_FROM_DT and dmlColl.VALID_TO_DT) AND (dmlColl.VALID_TO_DT BETWEEN '"
						+ sqlFromDate + "' and '" + sqlToDate + "')))";

			}
			ACCT_XREF_TOTAL_COUNT_QUERY = ACCT_XREF_LIST_QUERY.replace("*", "COUNT(*) AS totalCount ")
					+ " ) dmlColl ) ";
			ACCT_XREF_LIST_QUERY = ACCT_XREF_LIST_QUERY + endSql;
			log.info("Get filter data Query :"+ACCT_XREF_LIST_QUERY);
			obj.setTotalRecords(getTotalCountOfAcctXref(ACCT_XREF_TOTAL_COUNT_QUERY, paramList.toArray()));
			paramList.add(limit);
			paramList.add(offSet);
			List<AccountCrossRefVO> list = this.jdbcTemplate.query(ACCT_XREF_LIST_QUERY, paramList.toArray(), new CollateralAccountCrossRefListMapper());
			obj.setPageNumber(vo.getPageNo());
			obj.setPrePageNo(vo.getPageNo());
			obj.setNextPageNo(vo.getPageNo() + 1);
			if ((vo.getPaginationType().equals("pre") && vo.getPageNo() > 1)
					|| (list.size() < appconfig.getPageSize() && vo.getPaginationType().equals("next"))) {
				obj.setPrePageNo(vo.getPageNo() - 1);
				obj.setNextPageNo(vo.getPageNo());
			}

			obj.setAccountCrossRefVOList(list);
			//obj.setTotalRecords(getTotalCountOfAcctXref(ACCT_XREF_TOTAL_COUNT_QUERY));
			obj.setRecordsPerPage(appconfig.getPageSize() * vo.getPageNo());
			obj.setIsNextDisable("N");
			if ((appconfig.getPageSize() * vo.getPageNo()) >= obj.getTotalRecords()) {
				obj.setIsNextDisable("Y");
				obj.setRecordsPerPage(obj.getTotalRecords());
			}
			log.info("filter criteria response obj is:"+obj.toString());
		} catch (Exception e) {
			log.error("exception occurred ",e);
			throw e;
		}*/
		return obj;

	}

	public int getTotalCountOfAcctXref(String query, Object[] params) {
		return jdbcTemplate.queryForObject(query, params, Integer.class);

	}

	/*private static final class CollateralAccountCrossRefListMapper implements RowMapper<AccountCrossRefVO> {

		public AccountCrossRefVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			AccountCrossRefVO obj = new AccountCrossRefVO();
			obj.setActiveFlag(rs.getString(1));
			obj.setTriPartyAgentId(rs.getString(2));
			obj.setColTypeCode(rs.getString(3));
			obj.setHouseAcctId(rs.getString(4));
			obj.setCounterPartyId(rs.getString(5));
			obj.setCollateralAcct(rs.getString(6));
			obj.setValidFromDate(rs.getString(7));
			obj.setValidToDate(rs.getString(8));
			obj.setLastModifiedId(rs.getString(9));
			obj.setLastModifiedDate(rs.getString(10));
			obj.setCollateralCode(rs.getString(12));
			obj.setRowId(rs.getString(13));
			return obj;
		}
	}*/

	@Override
	public AccountCrossRefVO getCollateralAcctXRefDetails(AccountCrossRefVO vo) {
		log.info("*******************getCollateralAcctXRefDetails impl*******");
		return jdbcTemplate.queryForObject(
				ACCT_XREF_DETAIL_QUERY, new Object[] { vo.getRowId(), vo.getTriPartyAgentId(), vo.getHouseAcctId(),
						vo.getCounterPartyId(), vo.getCollateralAcct(), vo.getActiveFlag() },
				new CollateralAccountCrossRefDetailMapper());

	}

	private static final class CollateralAccountCrossRefDetailMapper implements RowMapper<AccountCrossRefVO> {
		public AccountCrossRefVO mapRow(ResultSet rs, int rowNum) throws SQLException {

			AccountCrossRefVO obj = new AccountCrossRefVO();
			obj.setActiveFlag(rs.getString(1));
			obj.setTriPartyAgentId(rs.getString(2));
			obj.setCollateralCode(rs.getString(3));
			obj.setColTypeCode(rs.getString(3));
			obj.setHouseAcctId(rs.getString(4));
			obj.setCounterPartyId(rs.getString(5));
			obj.setCollateralAcct(rs.getString(6));
			obj.setValidFromDate(rs.getString(7));
			obj.setValidToDate(rs.getString(8));
			obj.setLastModifiedId(rs.getString(9));
			obj.setLastModifiedDate(rs.getString(10));
			obj.setCurrentRecFlag(rs.getString(11));
			obj.setRowId(rs.getString(12));

			return obj;
		}
	}

	public AccountCrossRefDetails saveCrossRefDetails(AccountCrossRefVO vo) {
		log.info("*******************saveCrossRefDetails impl*******");
		String errorDesc = "";
		AccountCrossRefDetails retObject = new AccountCrossRefDetails();
		Connection con = null;
		CallableStatement callableStatement = null;
		String userName = vo.getUserName() != null ? vo.getUserName() : "ANONYMOUS";
		// String activeFlg = vo.getActiveFlag().equalsIgnoreCase("1") ? "Y" :
		// "N";
		Date fromDate, toDate = null;
		try {
			if (vo.getActiveFlag().equalsIgnoreCase("Y-Active"))
				vo.setActiveFlag("Y");
			else if (vo.getActiveFlag().equalsIgnoreCase("N-inActive"))
				vo.setActiveFlag("N");

			// System.out.println("-------date--" + vo.getIsDateUpdated());
			/**/
			
			fromDate = new Date(vo.getValidFromDate());
			toDate = new Date(vo.getValidToDate());
			
			con = jdbcTemplate.getDataSource().getConnection();
			callableStatement = con.prepareCall(
					"{call SLID.PKG_OIR_COLLATERAL_MAINTENANCE.SP_OIR_MAINT_DMLCOLACC_XREF(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
			callableStatement.setString(1, vo.getColTypeCode());
			//System.out.println("Param 1 is vo.getColTypeCode()" + vo.getColTypeCode());
			callableStatement.setString(2, vo.getCounterPartyId());
			//System.out.println("Param 2 is vo.getCounterPartyId()" + vo.getCounterPartyId());
			callableStatement.setString(3, vo.getTriPartyAgentId());
			//System.out.println("Param 3 is vo.getTriPartyAgentId()" + vo.getTriPartyAgentId());
			callableStatement.setString(4, vo.getCollateralAcct());
			//System.out.println("Param 4 is vo.getCollateralAcct()" + vo.getCollateralAcct());
			callableStatement.setString(5, vo.getHouseAcctId());
			//System.out.println("Param 5 is vo.getHouseAcctId()" + vo.getHouseAcctId());
			callableStatement.setDate(6, new java.sql.Date(fromDate.getTime()));
			//System.out.println("Param 6 is java.sql.Date(fromDate.getTime())" + new java.sql.Date(fromDate.getTime()));
			callableStatement.setDate(7, new java.sql.Date(toDate.getTime()));
			//System.out.println("Param 7 isnew java.sql.Date(toDate.getTime())" + new java.sql.Date(toDate.getTime()));

			callableStatement.setString(8, vo.getActiveFlag());
			//System.out.println("Param 8 is vo.getActiveFlag()" + vo.getActiveFlag());
			java.util.Date today = new java.util.Date();
			callableStatement.setString(9, vo.getUserName());
			//System.out.println("Param 9 is vo.getUserName()" + vo.getUserName());
			callableStatement.setTimestamp(10, new Timestamp(today.getTime()));
			//System.out.println("Param 10 is  new Timestamp(today.getTime())" + new Timestamp(today.getTime()));
			if (vo.getRowId() == null || "".equals(vo.getRowId())) {
				callableStatement.setString(11, "A");
				callableStatement.setString(13, "");
			} else {
				callableStatement.setString(11, vo.getiModValue());
				callableStatement.setString(13, vo.getRowId());
				//System.out.println("Param 13 is " + vo.getRowId());
			}
			//System.out.println("Param 11 is " + vo.getiModValue());
			callableStatement.setDate(12, new java.sql.Date(today.getTime()));
			//System.out.println("Param 12 is new java.sql.Date(today.getTime()" + new java.sql.Date(today.getTime()));

			callableStatement.registerOutParameter(14, java.sql.Types.NUMERIC);
			callableStatement.registerOutParameter(15, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(16, java.sql.Types.VARCHAR);

			callableStatement.executeUpdate();
			//long errorCode = callableStatement.getLong(14);
			String errorMessage = callableStatement.getString(15);
			//String errorType = callableStatement.getString(16);
			if (errorMessage != null) {
				retObject.setResponseType(RequestAction.RESPONSE_TYPE_FAILURE);
				List<String> errList = new ArrayList<String>();
				String[] splitErr = errorMessage.split("%");
				for (int i = 0; i < splitErr.length; i++) {
					if (splitErr[i].equals("") || splitErr[i]==null)
						continue;
					else if (props.getErrorMessage(splitErr[i]) != null)
						errList.add(props.getErrorMessage(splitErr[i]));
				}
				String [] errDesc = new String[errList.size()];
				for(int i=0;i<errList.size();i++) {
					errDesc[i] = errList.get(i);
				}
				retObject.setErrorDesc(errDesc);
			} else {
				AccountCrossRefVO objAccountCrossRefVO = new AccountCrossRefVO();
				objAccountCrossRefVO.setPageNo(1);
				objAccountCrossRefVO.setPaginationType("next");
				objAccountCrossRefVO.setSearchTypeFlag("1");
				retObject = getAllDMLCollateralAcctXRef(objAccountCrossRefVO);
			}

		} catch (Exception e) {
			log.error("exception occurred ",e);
			errorDesc = "exception";
			retObject.setErrorDesc(new String[] { errorDesc });
		} finally {
			try {
				if (callableStatement != null)
					callableStatement.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				log.error("exception occurred ",e);
			}
		}
		return retObject;

	}

	
	
	/*private List<Collateral> getDmlCtpyList() {
		try {
			return this.jdbcTemplate.query(DMLCTPY_LIST_QUERY,new DmlDetailsMapper());
		} catch (Exception e) {
			log.error("exception occurred ",e);
			throw e;
		}
	}

	private static final class DmlDetailsMapper implements RowMapper<Collateral> {

		public Collateral mapRow(ResultSet rs, int rowNum) throws SQLException {
			Collateral obj = new Collateral();
			obj.setLabel(rs.getString("codevalue") + " " + rs.getString("codelongdescription"));
			obj.setValue(rs.getString("codevalue"));
			return obj;
		}
	}*/

	@Override
	public List<CollatAccDetails> getCollatAccList(AccountCrossRefVO vo) {
		List<CollatAccDetails> collAccList = new ArrayList<CollatAccDetails>();
		if(Integer.parseInt(vo.getTriPartyAgentId())!=0) {
			try{
				collAccList = this.jdbcTemplate
					.query(COLLACC_LIST_QUERY, new Object[] {"Y",vo.getTriPartyAgentId()}, new CollAccDetailsMapper());
			}catch(Exception e){
				log.error("exception occurred ",e);
				throw e;
			}
		}
		return collAccList; 
	}

	private static final class CollAccDetailsMapper implements RowMapper<CollatAccDetails> {

		public CollatAccDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			CollatAccDetails obj = new CollatAccDetails();
			obj.setLabel(rs.getString(1) + " " + rs.getString(2));
			obj.setValue(rs.getString(1));
			return obj;
		}
	}

	/*
	@Override
	public DmlCollateralDDdetails getDmlCollatDDList() {
		DmlCollateralDDdetails objDmlCollateralDDdetails = new DmlCollateralDDdetails();
		Collateral objCollateral = new Collateral();
		try {
			objCollateral.setLabel("ALL");
			objCollateral.setValue("0");
			// Setting the dropdown data
			objDmlCollateralDDdetails.setCollCodeData(getCollateralList());
			objDmlCollateralDDdetails.setTripartyData(getTripartyAgentFileList());
			objDmlCollateralDDdetails.setHouseDetailsData(getHouseDetailList());
			objDmlCollateralDDdetails.setCtpyData(getDmlCtpyList());
			// Adding default value to all objects
			objDmlCollateralDDdetails.getCollCodeData().add(objCollateral);
			objDmlCollateralDDdetails.getTripartyData().add(objCollateral);
			objDmlCollateralDDdetails.getHouseDetailsData().add(objCollateral);
			objDmlCollateralDDdetails.getCtpyData().add(objCollateral);
			return objDmlCollateralDDdetails;
		} catch (Exception e) {
			log.error("exception occurred ",e);
			throw e;
		}
	}
	 */
}
