package com.ssc.rest.inv.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssc.rest.common.RequestAction;
import com.ssc.rest.inv.dao.InvestmentVehicleDao;
import com.ssc.rest.inv.entity.InvestVehicleRefVO;
import com.ssc.rest.inv.entity.InvestmentvehiclerefDetails;
import com.ssc.rest.inv.service.InvestmentvehicleService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(value = "/invVehicleRowDetails", tags = "InvVehicleRowDetails Account Api")
@RequestMapping(value = "/api/invVehicleRowDetails")
public class GetInvestVehicleDetailsRow {
	@Autowired
	InvestmentVehicleDao investmentVehicleDao;
	@Autowired
	InvestmentvehicleService investmentvehicleService;
	private static final Logger log=Logger.getLogger(GetInvestVehicleDetailsRow.class);

	/**
	 * http://localhost:8080/cloudservices/api/invVehicleRowDetails/list Used to
	 * fetch details based on inputobject
	 * 
	 * Content-Type: application/json request body object is mandatory {} return
	 * obj as response
	 * 
	 * @param bo
	 * @return
	 */
	@RequestMapping(value = RequestAction.LIST, method = RequestMethod.POST)
	@ApiOperation(value = "getInvVehicleRowDetails", notes = "InvVehicleRowDetails List", httpMethod = "POST", response = InvestmentvehiclerefDetails.class, responseContainer = "Object")
	public InvestVehicleRefVO getInvVehicleRowDetails(@RequestBody InvestVehicleRefVO vo) {
		log.info("getInvVehicleRowDetails obj:"+vo.toString());
		return investmentvehicleService.getInvVehicleRowDetails(vo);
	}
}
