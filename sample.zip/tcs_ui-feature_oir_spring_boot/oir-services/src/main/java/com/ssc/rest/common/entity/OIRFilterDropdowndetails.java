package com.ssc.rest.common.entity;

import java.util.List;

public class OIRFilterDropdowndetails {
	
	private List<OIRVo> collCodeData;
	private List<OIRVo> houseDetailsData;
	private List<OIRVo> tripartyData;
	private List<OIRVo> ctpyData;

	public List<OIRVo> getCollCodeData() {
		return collCodeData;
	}

	public void setCollCodeData(List<OIRVo> collCodeData) {
		this.collCodeData = collCodeData;
	}

	public List<OIRVo> getHouseDetailsData() {
		return houseDetailsData;
	}

	public void setHouseDetailsData(List<OIRVo> houseDetailsData) {
		this.houseDetailsData = houseDetailsData;
	}

	public List<OIRVo> getTripartyData() {
		return tripartyData;
	}

	public void setTripartyData(List<OIRVo> tripartyData) {
		this.tripartyData = tripartyData;
	}

	public List<OIRVo> getCtpyData() {
		return ctpyData;
	}

	public void setCtpyData(List<OIRVo> ctpyData) {
		this.ctpyData = ctpyData;
	}
}
