package com.ssc.rest.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.ssc.rest.common.ErrorMessageProperties;
import com.ssc.rest.common.entity.OIRFilterDropdowndetails;
import com.ssc.rest.common.entity.OIRVo;
import com.ssc.rest.config.AppConfig;
import com.ssc.rest.dml.dao.CollateralDaoImpl;

@Component
public class OIRDaoImpl implements OIRDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;  
	@Autowired
	ErrorMessageProperties props;
	@Autowired
	AppConfig appconfig;

	private static final Logger log = Logger.getLogger(CollateralDaoImpl.class);

	 

	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	
	private List<OIRVo> getCollateralList() {
		try {
			return this.jdbcTemplate.query(COLLATERAL_LIST_QUERY,new CollateralCodeMapper());
		} catch (Exception ex) {
			log.error("exception occurred ",ex);
			throw ex;
		}
	}

	
	private List<OIRVo> getHouseDetailList() {
		try {
			return this.jdbcTemplate.query(HOUSE_LIST_QUERY,new CollateralCodeMapper());
		} catch (Exception ex) {
			log.error("exception occurred ",ex);
			throw ex;
		}
	}
			

	
	private List<OIRVo> getTripartyAgentFileList() {
		try {
			return this.jdbcTemplate.query(TRIPARTY_LIST_QUERY,new CollateralCodeMapper());
		} catch (Exception ex) {
			log.error("exception occurred ",ex);
			throw ex;
		}
	}

	
	private static final class CollateralCodeMapper implements RowMapper<OIRVo> {

		public OIRVo mapRow(ResultSet rs, int rowNum) throws SQLException {
			OIRVo obj = new OIRVo();
			obj.setValue(rs.getString(1));
			obj.setLabel(rs.getString(2));
			return obj;
		}
	}
	
	
		
	private List<OIRVo> getDmlCtpyList() {
		try {
			return this.jdbcTemplate.query(DMLCTPY_LIST_QUERY,new DmlDetailsMapper());
		} catch (Exception e) {
			log.error("exception occurred ",e);
			throw e;
		}
	}

	private static final class DmlDetailsMapper implements RowMapper<OIRVo> {

		public OIRVo mapRow(ResultSet rs, int rowNum) throws SQLException {
			OIRVo obj = new OIRVo();
			obj.setLabel(rs.getString("codevalue") + " " + rs.getString("codelongdescription"));
			obj.setValue(rs.getString("codevalue"));
			return obj;
		}
	}

	@Override
	public OIRFilterDropdowndetails getOIRFilterDropdowndetails() {
		OIRFilterDropdowndetails objDmlCollateralDDdetails = new OIRFilterDropdowndetails();
		OIRVo objCollateral = new OIRVo();
		try {
			objCollateral.setLabel("ALL");
			objCollateral.setValue("0");
			// Setting the dropdown data
			objDmlCollateralDDdetails.setCollCodeData(getCollateralList());
			objDmlCollateralDDdetails.setTripartyData(getTripartyAgentFileList());
			objDmlCollateralDDdetails.setHouseDetailsData(getHouseDetailList());
			objDmlCollateralDDdetails.setCtpyData(getDmlCtpyList());
			// Adding default value to all objects
			objDmlCollateralDDdetails.getCollCodeData().add(objCollateral);
			objDmlCollateralDDdetails.getTripartyData().add(objCollateral);
			objDmlCollateralDDdetails.getHouseDetailsData().add(objCollateral);
			objDmlCollateralDDdetails.getCtpyData().add(objCollateral);
			return objDmlCollateralDDdetails;
		} catch (Exception e) {
			log.error("exception occurred ",e);
			throw e;
		}
	}

	

}
