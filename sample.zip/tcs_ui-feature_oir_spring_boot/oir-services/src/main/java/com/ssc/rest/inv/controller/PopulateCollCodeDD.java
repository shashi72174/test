package com.ssc.rest.inv.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssc.rest.common.RequestAction;
import com.ssc.rest.inv.dao.InvestmentVehicleDao;
import com.ssc.rest.inv.entity.InvestVehicleRefVO;
import com.ssc.rest.inv.entity.InvestmentvehicleList;
import com.ssc.rest.inv.service.InvestmentvehicleService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(value = "/populateCollatCodeList", tags = "populateCollatCode Dropdown Api")
@RequestMapping(value = "/api/populateCollatCodeList")
public class PopulateCollCodeDD {
	@Autowired
	InvestmentVehicleDao investmentVehicleDao;
	@Autowired
	InvestmentvehicleService investmentvehicleService;
	private static final Logger log=Logger.getLogger(PopulateCollCodeDD.class);
	/**
	 * http://localhost:8080/cloudservices/api/populateCollatCodeList/list Used to
	 * fetch populateCollatCodeList details
	 * 
	 * Content-Type: application/json request body object is mandatory {} return
	 * list as response
	 * 
	 * @param boO
	 * @return
	 */
	@RequestMapping(value = RequestAction.LIST, method = RequestMethod.POST)
	@ApiOperation(value = "getpopulateCollatCodeList", notes = "get populateCollatCodeList dropdown list", httpMethod = "POST", response = InvestmentvehicleList.class, responseContainer = "List")
	public List<InvestmentvehicleList> getCollCodeDDList(@RequestBody InvestVehicleRefVO vo) {
		log.info("getCollCodeDDList obj:"+vo.toString());
		List<InvestmentvehicleList> list = investmentvehicleService.getCollCodeList(vo);
		
		return list;

	}
}
