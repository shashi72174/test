package com.ssc.rest.invtest;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.gson.Gson;
import com.ssc.rest.inv.dao.InvestmentVehicleDao;
import com.ssc.rest.inv.entity.InvestVehicleRefVO;
import com.ssc.rest.inv.entity.InvestmentvehiclerefDetails;
import com.ssc.rest.inv.service.InvestmentvehicleServiceImpl;

//@RunWith(SpringJUnit4ClassRunner.class)
public class GetInvestmentVehicleFilterDetailsTest {
	private InvestmentvehicleServiceImpl investmentvehicleServiceImpl;
	private InvestmentVehicleDao investmentVehicleDao;
	InvestVehicleRefVO objInvestVehicleRefVO_next;
	InvestVehicleRefVO objInvestVehicleRefVO_pre;

	InvestmentvehiclerefDetails objInvestmentvehiclerefDetails;

	@Before
	public void setupMock() {
		investmentvehicleServiceImpl = new InvestmentvehicleServiceImpl();
		investmentVehicleDao = mock(InvestmentVehicleDao.class);
		investmentvehicleServiceImpl.setInvestmentVehicleDao(investmentVehicleDao);
		objInvestVehicleRefVO_next = new InvestVehicleRefVO();
		objInvestVehicleRefVO_next.setPageNo(1);
		objInvestVehicleRefVO_next.setPaginationType("next");
		objInvestVehicleRefVO_next.setSearchTypeFlag("1");
		objInvestVehicleRefVO_pre = new InvestVehicleRefVO();
		objInvestVehicleRefVO_pre.setPageNo(3);
		objInvestVehicleRefVO_pre.setPaginationType("prev");
		objInvestVehicleRefVO_pre.setSearchTypeFlag("1");
		String jsonOutput = "{\"investmentVehicleList\":[{\"sourceCode\":\"SSGANONUS\",\"triPartyAgentId\":\"EUROCLEAR\",\"validFromDate\":\"01/01/1980\",\"sourceInvvehicleId\":null,\"collateralAcct\":\"49905\",\"primaryDMLCtpyId\":null,\"validToDate\":\"01/31/2500\",\"ctpyId\":\"G50644\",\"ctpyEntityId\":\"006574\",\"ctpyDMLNM\":\"COMMERZBANK AG\",\"srcCollCode\":null,\"activeFlag\":\"Y\",\"lastModifiedId\":\"E416011\",\"lastModifiedDate\":\"2006-06-02 00:00:00.0\",\"currentRecFlag\":\"Y\",\"ssgaCollCode\":\"05\",\"sourceVehicleText\":\"3HG2\",\"sourceCtpytxt\":\"DRES\",\"invVehInvestmentNM\":\"TEST\",\"rowId\":\"AABQHrAAQAAADWNAAA\",\"userName\":null,\"pageNo\":0,\"paginationType\":null,\"searchTypeFlag\":null,\"isDateUpdated\":null,\"iModValue\":null,\"invVehicleId\":null},{\"sourceCode\":\"SSGANONUS\",\"triPartyAgentId\":\"EUROCLEAR\",\"validFromDate\":\"01/01/1980\",\"sourceInvvehicleId\":null,\"collateralAcct\":\"49905\",\"primaryDMLCtpyId\":null,\"validToDate\":\"01/31/2500\",\"ctpyId\":\"G50644\",\"ctpyEntityId\":\"006574\",\"ctpyDMLNM\":\"COMMERZBANK AG\",\"srcCollCode\":null,\"activeFlag\":\"Y\",\"lastModifiedId\":\"E416011\",\"lastModifiedDate\":\"2006-06-02 00:00:00.0\",\"currentRecFlag\":\"Y\",\"ssgaCollCode\":\"05\",\"sourceVehicleText\":\"3HG2\",\"sourceCtpytxt\":\"DRES\",\"invVehInvestmentNM\":\"SUOMEN PANKKI (FINLAND)\",\"rowId\":\"AABQHrAAQAAADWNAAA\",\"userName\":null,\"pageNo\":0,\"paginationType\":null,\"searchTypeFlag\":null,\"isDateUpdated\":null,\"iModValue\":null,\"invVehicleId\":null}],\"investmentVehicleData\":null,\"pageNumber\":1,\"totalRecords\":7720,\"recordsPerPage\":20,\"responseType\":null,\"errorCode\":null,\"errorDesc\":null,\"prePageNo\":1,\"nextPageNo\":2,\"isNextDisable\":\"N\"}";
		objInvestmentvehiclerefDetails = new Gson().fromJson(jsonOutput, InvestmentvehiclerefDetails.class);
	}

	// To testpagenation with next
	@Test
	public void getFilterDetails_Pagenationtest1() throws Exception {
		when(investmentVehicleDao.getInvestmentVehiceFilterDetails(objInvestVehicleRefVO_next))
				.thenReturn(objInvestmentvehiclerefDetails);
		when(investmentVehicleDao.getInvestmentVehiceFilterDetails(objInvestVehicleRefVO_next))
				.thenReturn(objInvestmentvehiclerefDetails);
		assertEquals(20,
				investmentvehicleServiceImpl.getInvVehicleDetails(objInvestVehicleRefVO_next).getRecordsPerPage());
		verify(investmentVehicleDao, Mockito.timeout(100).times(1))
				.getInvestmentVehiceFilterDetails(objInvestVehicleRefVO_next);
	}

	// To test pagenation with previous
	@Test
	public void getFilterDetails_Pagenationtest2() throws Exception {

		when(investmentVehicleDao.getInvestmentVehiceFilterDetails(objInvestVehicleRefVO_pre))
				.thenReturn(objInvestmentvehiclerefDetails);
		assertEquals(20,
				investmentVehicleDao.getInvestmentVehiceFilterDetails(objInvestVehicleRefVO_pre).getRecordsPerPage());
		assertEquals(objInvestmentvehiclerefDetails,
				investmentvehicleServiceImpl.getInvVehicleDetails(objInvestVehicleRefVO_pre));

		verify(investmentVehicleDao, atLeastOnce()).getInvestmentVehiceFilterDetails(objInvestVehicleRefVO_pre);
	}

	// To test filter criteria with values
	@Test
	public void getFilterDetails_test() throws Exception {
		InvestVehicleRefVO objInvestVehicleRefVO = new InvestVehicleRefVO();
		objInvestVehicleRefVO.setPageNo(1);
		objInvestVehicleRefVO.setPaginationType("prev");
		objInvestVehicleRefVO.setSourceInvvehicleId("01AA");
		objInvestVehicleRefVO.setValidFromDate("2019-01-23T09:00:06.806Z");
		objInvestVehicleRefVO.setValidToDate("2500-01-30T18:30:00.000Z");
		// output
		String output = "{\"investmentVehicleList\":[{\"sourceCode\":\"SSGANONUS\",\"triPartyAgentId\":\"EUROCLEAR\",\"validFromDate\":\"01/01/1980\",\"sourceInvvehicleId\":null,\"collateralAcct\":\"49905\",\"primaryDMLCtpyId\":null,\"validToDate\":\"01/31/2500\",\"ctpyId\":\"G50644\",\"ctpyEntityId\":\"006574\",\"ctpyDMLNM\":\"COMMERZBANK AG\",\"srcCollCode\":null,\"activeFlag\":\"Y\",\"lastModifiedId\":\"E416011\",\"lastModifiedDate\":\"2006-06-02 00:00:00.0\",\"currentRecFlag\":\"Y\",\"ssgaCollCode\":\"05\",\"sourceVehicleText\":\"3HG2\",\"sourceCtpytxt\":\"DRES\",\"invVehInvestmentNM\":\"TEST\",\"rowId\":\"AABQHrAAQAAADWNAAA\",\"userName\":null,\"pageNo\":0,\"paginationType\":null,\"searchTypeFlag\":null,\"isDateUpdated\":null,\"iModValue\":null,\"invVehicleId\":null},{\"sourceCode\":\"SSGANONUS\",\"triPartyAgentId\":\"EUROCLEAR\",\"validFromDate\":\"01/01/1980\",\"sourceInvvehicleId\":null,\"collateralAcct\":\"49905\",\"primaryDMLCtpyId\":null,\"validToDate\":\"01/31/2500\",\"ctpyId\":\"G50644\",\"ctpyEntityId\":\"006574\",\"ctpyDMLNM\":\"COMMERZBANK AG\",\"srcCollCode\":null,\"activeFlag\":\"Y\",\"lastModifiedId\":\"E416011\",\"lastModifiedDate\":\"2006-06-02 00:00:00.0\",\"currentRecFlag\":\"Y\",\"ssgaCollCode\":\"05\",\"sourceVehicleText\":\"3HG2\",\"sourceCtpytxt\":\"DRES\",\"invVehInvestmentNM\":\"SUOMEN PANKKI (FINLAND)\",\"rowId\":\"AABQHrAAQAAADWNAAA\",\"userName\":null,\"pageNo\":0,\"paginationType\":null,\"searchTypeFlag\":null,\"isDateUpdated\":null,\"iModValue\":null,\"invVehicleId\":null}],\"investmentVehicleData\":null,\"pageNumber\":1,\"totalRecords\":7720,\"recordsPerPage\":20,\"responseType\":null,\"errorCode\":null,\"errorDesc\":null,\"prePageNo\":1,\"nextPageNo\":2,\"isNextDisable\":\"N\"}";
		InvestmentvehiclerefDetails objInvestmentvehiclerefDetails = new Gson().fromJson(output,
				InvestmentvehiclerefDetails.class);
		when(investmentVehicleDao.getInvestmentVehiceFilterDetails(objInvestVehicleRefVO))
				.thenReturn(objInvestmentvehiclerefDetails);
		assertEquals(objInvestmentvehiclerefDetails,
				investmentvehicleServiceImpl.getInvVehicleDetails(objInvestVehicleRefVO));
		verify(investmentVehicleDao, atLeastOnce()).getInvestmentVehiceFilterDetails(objInvestVehicleRefVO);
	}

}
