package com.ssc.test.dmltest;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.gson.Gson;
import com.ssc.rest.dml.dao.CollateralDao;
import com.ssc.rest.dml.entity.AccountCrossRefDetails;
import com.ssc.rest.dml.entity.AccountCrossRefVO;
import com.ssc.rest.dml.service.CollateralServiceImpl;

//@RunWith(SpringJUnit4ClassRunner.class)
public class AccountCrossRefLISTControllerTest {
	private CollateralServiceImpl collateralServiceImpl;
	private CollateralDao collateralDao;
	private AccountCrossRefDetails objAccountCrossRefDetails;
	AccountCrossRefVO obj_next;
	AccountCrossRefVO obj_pre;

	@Before
	public void setupMock() {
		collateralServiceImpl = new CollateralServiceImpl();
		collateralDao = mock(CollateralDao.class);
		collateralServiceImpl.setCollateralDao(collateralDao);
		obj_next = new AccountCrossRefVO();
		obj_next.setPageNo(1);
		obj_next.setPaginationType("next");
		obj_next.setSearchTypeFlag("1");
		obj_pre = new AccountCrossRefVO();
		obj_pre.setPageNo(3);
		obj_pre.setPaginationType("prev");
		obj_pre.setSearchTypeFlag("1");
		String jsonOutput = "{\"accountCrossRefVOList\":[{\"colTypeCode\":\"128\",\"collateralCode\":\"AU10-TP ASX 200 EQUITIES\",\"houseAcctId\":\"02000000SL27\",\"counterPartyId\":\"S00299\",\"triPartyAgentId\":\"CHASEGLOBAL\",\"collateralAcct\":\"AE003\",\"validFromDate\":\"01/23/2019\",\"validToDate\":\"01/25/2500\",\"activeFlag\":\"N\",\"lastModifiedId\":\"ANONYMOUS\",\"lastModifiedDate\":\"01/23/2019\",\"currentRecFlag\":null,\"rowId\":\"AACYAiAAQAAABspAAB\",\"userName\":null,\"pageNo\":0,\"paginationType\":null,\"searchTypeFlag\":null,\"isDateUpdated\":null,\"iModValue\":null}],\"accountCrossRefVO\":null,\"pageNumber\":1,\"totalRecords\":870,\"recordsPerPage\":20,\"responseType\":null,\"errorCode\":null,\"errorDesc\":null,\"prePageNo\":1,\"nextPageNo\":2,\"isNextDisable\":\"N\"}";
		objAccountCrossRefDetails = new Gson().fromJson(jsonOutput, AccountCrossRefDetails.class);

	}

	// To testpagenation with next
	@Test
	public void getFilterDetails_Pagenationtest1() throws Exception {
		when(collateralDao.getAllDMLCollateralAcctXRef(obj_next)).thenReturn(objAccountCrossRefDetails);
		assertEquals(20, collateralServiceImpl.getAccountCrossRefDetails(obj_next).getRecordsPerPage());
		verify(collateralDao, Mockito.timeout(100).times(1)).getAllDMLCollateralAcctXRef(obj_next);
	}

	// To test pagenation with previous
	@Test
	public void getFilterDetails_Pagenationtest2() throws Exception {

		when(collateralDao.getAllDMLCollateralAcctXRef(obj_pre)).thenReturn(objAccountCrossRefDetails);
		assertEquals(20, collateralDao.getAllDMLCollateralAcctXRef(obj_pre).getRecordsPerPage());
		assertEquals(objAccountCrossRefDetails, collateralServiceImpl.getAccountCrossRefDetails(obj_pre));

		verify(collateralDao, atLeastOnce()).getAllDMLCollateralAcctXRef(obj_pre);
	}

	// To test filter criteria with values
	@Test
	public void getFilterDetails_test() throws Exception {
		AccountCrossRefVO objAccountCrossRefVO = new AccountCrossRefVO();
		objAccountCrossRefVO.setPageNo(1);
		objAccountCrossRefVO.setPaginationType("next");
		objAccountCrossRefVO.setCollateralCode("128");
		objAccountCrossRefVO.setValidFromDate("2019-01-23T09:00:06.806Z");
		objAccountCrossRefVO.setValidToDate("2500-01-30T18:30:00.000Z");
		// output
		String output = "{\"accountCrossRefVOList\":[{\"colTypeCode\":\"128\",\"collateralCode\":\"AU10-TP ASX 200 EQUITIES\",\"houseAcctId\":\"02000000SL27\",\"counterPartyId\":\"S00299\",\"triPartyAgentId\":\"CHASEGLOBAL\",\"collateralAcct\":\"AE003\",\"validFromDate\":\"01/23/2019\",\"validToDate\":\"01/25/2500\",\"activeFlag\":\"N\",\"lastModifiedId\":\"ANONYMOUS\",\"lastModifiedDate\":\"01/23/2019\",\"currentRecFlag\":null,\"rowId\":\"AACYAiAAQAAABspAAB\",\"userName\":null,\"pageNo\":0,\"paginationType\":null,\"searchTypeFlag\":null,\"isDateUpdated\":null,\"iModValue\":null},{\"colTypeCode\":\"128\",\"collateralCode\":\"AU10-TP ASX 200 EQUITIES\",\"houseAcctId\":\"02000000SL10\",\"counterPartyId\":\"S02299\",\"triPartyAgentId\":\"CHASEGLOBAL\",\"collateralAcct\":\"AE003\",\"validFromDate\":\"12/02/2010\",\"validToDate\":\"01/31/2500\",\"activeFlag\":\"Y\",\"lastModifiedId\":\"E460633\",\"lastModifiedDate\":\"12/03/2010\",\"currentRecFlag\":null,\"rowId\":\"AACYAiAAQAAABtDAAY\",\"userName\":null,\"pageNo\":0,\"paginationType\":null,\"searchTypeFlag\":null,\"isDateUpdated\":null,\"iModValue\":null}],\"accountCrossRefVO\":null,\"pageNumber\":1,\"totalRecords\":2,\"recordsPerPage\":2,\"responseType\":null,\"errorCode\":null,\"errorDesc\":null,\"prePageNo\":0,\"nextPageNo\":1,\"isNextDisable\":\"Y\"}";
		objAccountCrossRefDetails = new Gson().fromJson(output, AccountCrossRefDetails.class);
		when(collateralDao.getAllDMLCollateralAcctXRef(objAccountCrossRefVO)).thenReturn(objAccountCrossRefDetails);
		assertEquals(objAccountCrossRefDetails, collateralServiceImpl.getAccountCrossRefDetails(objAccountCrossRefVO));
		verify(collateralDao, atLeastOnce()).getAllDMLCollateralAcctXRef(objAccountCrossRefVO);
	}

}
