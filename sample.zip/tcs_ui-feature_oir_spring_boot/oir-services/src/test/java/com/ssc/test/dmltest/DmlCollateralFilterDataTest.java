package com.ssc.test.dmltest;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.google.gson.Gson;
import com.ssc.rest.common.dao.OIRDao;
import com.ssc.rest.common.entity.OIRFilterDropdowndetails;
import com.ssc.rest.common.service.OIRServiceImpl;

//@RunWith(SpringJUnit4ClassRunner.class)
public class DmlCollateralFilterDataTest {
	private OIRServiceImpl collateralServiceImpl;
	private OIRDao collateralDao;
	OIRFilterDropdowndetails objDmlCollateralDDdetails = new OIRFilterDropdowndetails();

	@Before
	public void setupMock() {
		collateralServiceImpl = new OIRServiceImpl();
		collateralDao = mock(OIRDao.class);
		collateralServiceImpl.setCollateralDao(collateralDao);
		String output = "{\"collCodeData\":[{\"value\":\"-9\",\"label\":\"9999-TP GOVT & CORP BONDS    A-FLR\"}],\"houseDetailsData\":[{\"value\":\"010000000161\"}],\"tripartyData\":[{\"value\":\"101\",\"label\":\"BONYUS\"}],\"ctpyData\":[{\"value\":\"000002\",\"label\":\"000002 Inactive-TIGER     \"}]}";
		objDmlCollateralDDdetails = new Gson().fromJson(output, OIRFilterDropdowndetails.class);

	}

	@Test
	public void getDDDetails_test() throws Exception {

		when(collateralDao.getOIRFilterDropdowndetails()).thenReturn(objDmlCollateralDDdetails);
		assertEquals(objDmlCollateralDDdetails, collateralServiceImpl.getCollDDData());
		verify(collateralDao, Mockito.timeout(100).times(1)).getOIRFilterDropdowndetails();

	}
}
