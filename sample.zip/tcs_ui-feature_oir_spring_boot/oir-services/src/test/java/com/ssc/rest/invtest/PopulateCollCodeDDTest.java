package com.ssc.rest.invtest;

import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ssc.rest.inv.dao.InvestmentVehicleDao;
import com.ssc.rest.inv.entity.InvestVehicleRefVO;
import com.ssc.rest.inv.entity.InvestmentvehicleList;
import com.ssc.rest.inv.service.InvestmentvehicleServiceImpl;

//@RunWith(SpringJUnit4ClassRunner.class)
public class PopulateCollCodeDDTest {
	private InvestmentvehicleServiceImpl investmentvehicleServiceImpl;
	private InvestmentVehicleDao investmentVehicleDao;
	InvestVehicleRefVO objInvestVehicleRefVO;
	List<InvestmentvehicleList> list;

	@Before
	public void setupMock() {
		investmentvehicleServiceImpl = new InvestmentvehicleServiceImpl();
		investmentVehicleDao = mock(InvestmentVehicleDao.class);
		investmentvehicleServiceImpl.setInvestmentVehicleDao(investmentVehicleDao);
		objInvestVehicleRefVO = new InvestVehicleRefVO();
		objInvestVehicleRefVO.setTriPartyAgentId("102");
		list = new ArrayList<InvestmentvehicleList>();
		InvestmentvehicleList objInvestmentvehicleList = new InvestmentvehicleList();
		objInvestmentvehicleList.setLabel("test");
		objInvestmentvehicleList.setLabel("test");
		list.add(objInvestmentvehicleList);
	}

	// test coll code dd based on tripart selection
	@Test
	public void invCollCodeDropdown_test() throws Exception {
		List<InvestmentvehicleList> list1 = investmentvehicleServiceImpl.getCollCodeList(objInvestVehicleRefVO);
		Assert.assertNotNull(list1);
		when(investmentVehicleDao.getCollCodeList(objInvestVehicleRefVO)).thenReturn(list);
		Assert.assertNotNull(investmentvehicleServiceImpl.getCollCodeList(objInvestVehicleRefVO));
		verify(investmentVehicleDao, atLeastOnce()).getCollCodeList(objInvestVehicleRefVO);
	}
}
