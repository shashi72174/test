package com.ssc.rest.invtest;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.gson.Gson;
import com.ssc.rest.inv.dao.InvestmentVehicleDao;
import com.ssc.rest.inv.entity.InvestmentVehicleDD_Data;
import com.ssc.rest.inv.service.InvestmentvehicleServiceImpl;

//@RunWith(SpringJUnit4ClassRunner.class)
public class GetInvestVehicleAllDDTest {
	private InvestmentvehicleServiceImpl investmentvehicleServiceImpl;
	private InvestmentVehicleDao investmentVehicleDao;
	InvestmentVehicleDD_Data objInvestmentVehicleDD_Data;

	@Before
	public void setupMock() {
		investmentvehicleServiceImpl = new InvestmentvehicleServiceImpl();
		investmentVehicleDao = mock(InvestmentVehicleDao.class);
		investmentvehicleServiceImpl.setInvestmentVehicleDao(investmentVehicleDao);
		String jsondata = "{\"sourceList\":[{\"value\":\"105\",\"label\":\"SSGAUS\"}],\"invVehicleList\":[{\"value\":\"$EV1\",\"label\":\"$EV1-null\"}],\"srcCollCode\":[{\"value\":\"00\",\"label\":\"00-EUROCLEAR SET 00\"}],\"tripartyList\":[{\"value\":\"101\",\"label\":\"BONYUS\"}]}";
		objInvestmentVehicleDD_Data = new Gson().fromJson(jsondata, InvestmentVehicleDD_Data.class);
	}

	// test dropdown services..
	@Test
	public void invAllDropdown_test() throws Exception {
		when(investmentVehicleDao.getInvVehAllDDList()).thenReturn(objInvestmentVehicleDD_Data);
		assertEquals(investmentvehicleServiceImpl.getInvVehAllDDList(), objInvestmentVehicleDD_Data);
		verify(investmentVehicleDao, Mockito.timeout(100).times(1)).getInvVehAllDDList();
	}
}
