package com.ssc.rest.invtest;

import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.gson.Gson;
import com.ssc.rest.inv.dao.InvestmentVehicleDao;
import com.ssc.rest.inv.entity.InvestVehicleRefVO;
import com.ssc.rest.inv.entity.InvestmentvehiclerefDetails;
import com.ssc.rest.inv.service.InvestmentvehicleServiceImpl;

//@RunWith(SpringJUnit4ClassRunner.class)
public class SaveInvVehicleDetailsControllerTest {
	private InvestmentvehicleServiceImpl investmentvehicleServiceImpl;
	private InvestmentVehicleDao investmentVehicleDao;

	@Before
	public void setupMock() {
		investmentvehicleServiceImpl = new InvestmentvehicleServiceImpl();
		investmentVehicleDao = mock(InvestmentVehicleDao.class);
		investmentvehicleServiceImpl.setInvestmentVehicleDao(investmentVehicleDao);
	}

	// To test save with dummy data
	@Test
	public void inv_Savetest() throws Exception {
		// Input
		String input = "{\"activeFlag\":\"Y\",\"collateralAcct\":\"000027-006550727 R STATE STREET GSIEQ PROF 8\",\"ctpyDMLNM\":\"423\",\"ctpyEntityId\":\"2424\",\"ctpyId\":\"234\",\"invVehInvestmentNM\":\"4234\",\"isDateUpdated\":\"N\",\"sourceCode\":105,\"sourceCtpytxt\":432,\"sourceInvvehicleId\":\"$EV2\",\"srcCollCode\":\"01\",\"triPartyAgentId\":\"102\",\"userName\":\"\"	,\"validFromDate\":\"1/23/2019\",\"validToDate\":\"1/31/2500\"}";
		InvestVehicleRefVO objInput = new Gson().fromJson(input, InvestVehicleRefVO.class);
		String output = "{\"investmentVehicleList\":null,\"investmentVehicleData\":null,\"pageNumber\":0,\"totalRecords\":0,\"recordsPerPage\":0,\"responseType\":null,\"errorCode\":null,\"errorDesc\":[null,\"Src Ctpy does not exist\",\"Triparty Collateral Account does not exist\"],\"prePageNo\":0,\"nextPageNo\":0,\"isNextDisable\":null}";
		InvestmentvehiclerefDetails objOutput = new Gson().fromJson(output, InvestmentvehiclerefDetails.class);

			when(investmentVehicleDao.saveInvVehicleDetails(objInput)).thenReturn(objOutput);
			Assert.assertEquals(objOutput, investmentvehicleServiceImpl.saveinvVehicleDetails(objInput));
			Assert.assertNotNull(investmentvehicleServiceImpl.saveinvVehicleDetails(objInput).getErrorDesc());
			Mockito.verify(investmentVehicleDao,atLeastOnce()).saveInvVehicleDetails(objInput);
		}

		// to test update functionality
		@Test
		public void inv_Updatetest() throws Exception {
			// Input
			String input = "{\"activeFlag\":\"Y\",\"collateralAcct\":\"000027-006550727 R STATE STREET GSIEQ PROF 8\",\"ctpyDMLNM\":\"COMMERZBANKAG\",\"ctpyEntityId\":\"006574\",\"ctpyId\":\"G50644\",\"iModValue\":\"C\",\"invVehInvestmentNM\":\"NATIONAL BANK OF KAZAKHSTAN\",\"rowId\":\"AABQHrAAQAAADWNAAE\",\"sourceCode\":\"106\",\"sourceCtpytxt\":\"DRES\",\"sourceInvvehicleId\":\"3HG6\",\"srcCollCode\":\"05\",\"triPartyAgentId\":\"102\",\"userName\":\"\",\"validFromDate\":\"2019-01-22T12:14:22.648Z\",\"validToDate\":\"1/31/2500\"}";
			InvestVehicleRefVO objInput = new Gson().fromJson(input, InvestVehicleRefVO.class);
			String output = "{\"investmentVehicleList\":null,\"investmentVehicleData\":null,\"pageNumber\":0,\"totalRecords\":0,\"recordsPerPage\":0,\"responseType\":null,\"errorCode\":null,\"errorDesc\":[null,\"Src Ctpy does not exist\",\"Triparty Collateral Account does not exist\"],\"prePageNo\":0,\"nextPageNo\":0,\"isNextDisable\":null}";
			InvestmentvehiclerefDetails objOutput = new Gson().fromJson(output, InvestmentvehiclerefDetails.class);

			when(investmentVehicleDao.saveInvVehicleDetails(objInput)).thenReturn(objOutput);
			Assert.assertEquals(objOutput, investmentvehicleServiceImpl.saveinvVehicleDetails(objInput));
			Assert.assertNotNull(investmentvehicleServiceImpl.saveinvVehicleDetails(objInput).getErrorDesc());
			Mockito.verify(investmentVehicleDao,atLeastOnce()).saveInvVehicleDetails(objInput);
		}
}
