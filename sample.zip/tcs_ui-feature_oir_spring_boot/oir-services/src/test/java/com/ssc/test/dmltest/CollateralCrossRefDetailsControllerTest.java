package com.ssc.test.dmltest;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ssc.rest.dml.dao.CollateralDao;
import com.ssc.rest.dml.entity.AccountCrossRefVO;
import com.ssc.rest.dml.service.CollateralServiceImpl;

//@RunWith(SpringJUnit4ClassRunner.class)
public class CollateralCrossRefDetailsControllerTest {

	private CollateralServiceImpl collateralServiceImpl;
	private CollateralDao collateralDao;

	@Before
	public void setupMock() {
		collateralServiceImpl = new CollateralServiceImpl();
		collateralDao = mock(CollateralDao.class);
		collateralServiceImpl.setCollateralDao(collateralDao);

	}

	@Test
	public void getCollatRowDetails_test() throws Exception {
		// Input data
		AccountCrossRefVO objAccountCrossRefVOin = new AccountCrossRefVO();
		objAccountCrossRefVOin.setActiveFlag("N");
		objAccountCrossRefVOin.setCollateralAcct("AE003");
		objAccountCrossRefVOin.setCounterPartyId("S00299");
		objAccountCrossRefVOin.setHouseAcctId("02000000SL27");
		objAccountCrossRefVOin.setTriPartyAgentId("AACYAiAAQAAABs");
		objAccountCrossRefVOin.setRowId("CHASEGLOBAL");
		// Output
		AccountCrossRefVO objAccountCrossRefVOout = new AccountCrossRefVO();
		objAccountCrossRefVOout.setColTypeCode("128");
		objAccountCrossRefVOout.setActiveFlag("N");
		objAccountCrossRefVOout.setCollateralAcct("AE003");
		objAccountCrossRefVOout.setCounterPartyId("S00299");
		objAccountCrossRefVOout.setHouseAcctId("02000000SL27");
		objAccountCrossRefVOout.setTriPartyAgentId("104");
		objAccountCrossRefVOout.setRowId("CHASEGLOBAL");
		objAccountCrossRefVOout.setValidFromDate("01/22/2019");
		objAccountCrossRefVOout.setLastModifiedDate("01/22/2019");

		when(collateralDao.getCollateralAcctXRefDetails(objAccountCrossRefVOin)).thenReturn(objAccountCrossRefVOout);
		assertEquals(objAccountCrossRefVOout,
				collateralServiceImpl.getCollateralAcctXRefDetails(objAccountCrossRefVOin));
		Assert.assertNull(collateralServiceImpl.getCollateralAcctXRefDetails(objAccountCrossRefVOout));

		verify(collateralDao, Mockito.timeout(100).times(1)).getCollateralAcctXRefDetails(objAccountCrossRefVOin);
	}
}
