package com.ssc.test.dmltest;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ssc.rest.dml.dao.CollateralDao;
import com.ssc.rest.dml.entity.AccountCrossRefVO;
import com.ssc.rest.dml.entity.CollatAccDetails;
import com.ssc.rest.dml.service.CollateralServiceImpl;

//@RunWith(SpringJUnit4ClassRunner.class)
public class CollateralAccListControllerTest {
	private CollateralServiceImpl collateralServiceImpl;
	private CollateralDao collateralDao;
	CollatAccDetails objCollatAccDetails;
	List<CollatAccDetails> objCollatAccDetailsList;

	@Before
	public void setupMock() {
		collateralServiceImpl = new CollateralServiceImpl();
		collateralDao = mock(CollateralDao.class);
		collateralServiceImpl.setCollateralDao(collateralDao);
		objCollatAccDetails = new CollatAccDetails();
		objCollatAccDetails.setLabel("000027");
		objCollatAccDetails.setValue("000027 006550727 R STATE STREET GSIEQ PROF 8");
		objCollatAccDetailsList = new ArrayList<CollatAccDetails>();
		objCollatAccDetailsList.add(objCollatAccDetails);

	}

	@Test
	public void collCodeDD_test() throws Exception {
		// Input data
		AccountCrossRefVO objAccountCrossRefVO = new AccountCrossRefVO();
		objAccountCrossRefVO.setTriPartyAgentId("102");
		when(collateralDao.getCollatAccList(objAccountCrossRefVO)).thenReturn(objCollatAccDetailsList);
		assertEquals(objCollatAccDetailsList, collateralServiceImpl.getCollatAccList(objAccountCrossRefVO));
		verify(collateralDao, Mockito.timeout(100).times(1)).getCollatAccList(objAccountCrossRefVO);
	}
}
