package com.ssc.test.dmltest;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.google.gson.Gson;
import com.ssc.rest.dml.dao.CollateralDao;
import com.ssc.rest.dml.entity.AccountCrossRefDetails;
import com.ssc.rest.dml.entity.AccountCrossRefVO;
import com.ssc.rest.dml.service.CollateralServiceImpl;

//@RunWith(MockitoJUnitRunner.class)
public class SaveAccountCrossRefDetailsControllerTest {
	private CollateralServiceImpl collateralServiceImpl;
	private CollateralDao collateralDao;
	AccountCrossRefDetails objAccountCrossRefDetails;
	AccountCrossRefVO objAccountCrossRefVO;

	@Before
	public void setupMock() {
		collateralServiceImpl = new CollateralServiceImpl();
		collateralDao = mock(CollateralDao.class);
		collateralServiceImpl.setCollateralDao(collateralDao);

	}

	@Test(expected = RuntimeException.class)
	public void SaveDetails_Check() throws Exception {
		AccountCrossRefVO objAccountCrossRefVO = new AccountCrossRefVO();
		objAccountCrossRefVO.setiModValue("A");

		when(collateralDao.saveCrossRefDetails(objAccountCrossRefVO))
				.thenThrow(new RuntimeException("Object is not set properly"));
		assertEquals(0, collateralServiceImpl.saveCrossRefDetails(objAccountCrossRefVO).toString().length());
	}

	@Test
	public void inv_Savetest() throws Exception {
		String input = "{\"activeFlag\":\"Y\",\"collateralAcct\":\"0F0425\",\"collateralCode\":\"216\",\"colTypeCode\":\"216\",\"counterPartyId\":\"000005\",\"houseAcctId\":\"010000000443\",\"isDateUpdated\":\"N\",\"triPartyAgentId\":\"104\",\"validFromDate\":\"1/23/2019\",\"validToDate\":\"1/31/2500\"}";
		String output = "{\"accountCrossRefVOList\":[{\"colTypeCode\":\"128\",\"collateralCode\":\"AU10-TP ASX 200 EQUITIES\",\"houseAcctId\":\"02000000SL27\",\"counterPartyId\":\"S00299\",\"triPartyAgentId\":\"CHASEGLOBAL\",\"collateralAcct\":\"AE003\",\"validFromDate\":\"01/23/2019\",\"validToDate\":\"01/25/2500\",\"activeFlag\":\"N\",\"lastModifiedId\":\"ANONYMOUS\",\"lastModifiedDate\":\"01/23/2019\",\"currentRecFlag\":null,\"rowId\":\"AACYAiAAQAAABspAAB\",\"userName\":null,\"pageNo\":0,\"paginationType\":null,\"searchTypeFlag\":null,\"isDateUpdated\":null,\"iModValue\":null}],\"accountCrossRefVO\":null,\"pageNumber\":1,\"totalRecords\":870,\"recordsPerPage\":20,\"responseType\":null,\"errorCode\":null,\"errorDesc\":null,\"prePageNo\":1,\"nextPageNo\":2,\"isNextDisable\":\"N\"}";
		objAccountCrossRefDetails = new Gson().fromJson(output, AccountCrossRefDetails.class);
		objAccountCrossRefVO = new Gson().fromJson(input, AccountCrossRefVO.class);
		when(collateralDao.saveCrossRefDetails(objAccountCrossRefVO)).thenReturn(objAccountCrossRefDetails);
		Assert.assertEquals(objAccountCrossRefDetails, collateralServiceImpl.saveCrossRefDetails(objAccountCrossRefVO));
		Assert.assertNull(collateralServiceImpl.saveCrossRefDetails(objAccountCrossRefVO).getErrorDesc());
		Mockito.verify(collateralDao, Mockito.atLeastOnce()).saveCrossRefDetails(objAccountCrossRefVO);
	}

	@Test
	public void inv_Updatetest() throws Exception {
		String input = "{\"activeFlag\":\"N\",\"collateralAcct\":\"AE003\",\"collateralCode\":\"128\",\"colTypeCode\":\"128\",\"counterPartyId\":\"S00299\",\"houseAcctId\":\"02000000SL27\",\"isDateUpdated\":\"N\",\"triPartyAgentId\":\"104\",\"validFromDate\":\"1/23/2019\",\"validToDate\":\"1/31/2500\",\"iModValue\":\"IC\",\"isDateUpdated\":\"N\",\"rowId\":\"AACYAiAAQAAABspAAB\"}";
		String output = "{\"accountCrossRefVOList\":null,\"accountCrossRefVO\":null,\"pageNumber\":0,\"totalRecords\":0,\"recordsPerPage\":0,\"responseType\":null,\"errorCode\":null,\"errorDesc\":[null,\"The same day change is not allowed, choose correction option.\"],\"prePageNo\":0,\"nextPageNo\":0,\"isNextDisable\":null}";
		objAccountCrossRefDetails = new Gson().fromJson(output, AccountCrossRefDetails.class);
		objAccountCrossRefVO = new Gson().fromJson(input, AccountCrossRefVO.class);
		when(collateralDao.saveCrossRefDetails(objAccountCrossRefVO)).thenReturn(objAccountCrossRefDetails);
		Assert.assertEquals(objAccountCrossRefDetails, collateralServiceImpl.saveCrossRefDetails(objAccountCrossRefVO));
		Assert.assertNotNull(collateralServiceImpl.saveCrossRefDetails(objAccountCrossRefVO).getErrorDesc());
		Mockito.verify(collateralDao, Mockito.atLeastOnce()).saveCrossRefDetails(objAccountCrossRefVO);
	}
}
